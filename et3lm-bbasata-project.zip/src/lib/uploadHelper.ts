/**
 * File & Media Upload Helper for اتعلم ببساطة
 * Supports course thumbnails, lesson videos, homework files, lesson images, and backgrounds.
 */

import { auth } from "./firebase";

export interface UploadOptions {
  file: File;
  category:
    | "course-thumbnail"
    | "lesson-video"
    | "homework-file"
    | "lesson-image"
    | "platform-background"
    | "wallet-background"
    | "payment-receipt"
    | "general";
  userEmail?: string;
  userRole?: string;
  onProgress?: (percent: number) => void;
}

export interface UploadResult {
  success: boolean;
  url: string;
  fileName: string;
  fileType: string;
  size: number;
  error?: string;
}

/**
 * Format bytes to readable string (e.g. 1.2 MB, 450 KB)
 */
export function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

/**
 * Upload a file safely to the platform backend
 */
export async function uploadFileToPlatform(options: UploadOptions): Promise<UploadResult> {
  const { file, category, userEmail, userRole, onProgress } = options;

  if (!file) {
    throw new Error("لم يتم تحديد أي ملف للرفع");
  }

  // Client-side size checks
  let maxSizeBytes = 50 * 1024 * 1024; // 50MB
  if (category.includes("image") || category.includes("thumbnail") || category.includes("background")) {
    maxSizeBytes = 15 * 1024 * 1024; // 15MB
  } else if (category.includes("homework")) {
    maxSizeBytes = 35 * 1024 * 1024; // 35MB
  } else if (category.includes("video")) {
    maxSizeBytes = 50 * 1024 * 1024; // 50MB
  }

  if (file.size > maxSizeBytes) {
    const limitMB = Math.round(maxSizeBytes / (1024 * 1024));
    throw new Error(`حجم الملف (${formatFileSize(file.size)}) يتجاوز الحد الأقصى المسموح (${limitMB} ميجابايت)`);
  }

  onProgress?.(10);

  // Convert to Base64 data URL
  const fileData = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("فشل قراءة الملف من الجهاز"));
    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.round((event.loaded / event.total) * 40) + 10;
        onProgress?.(percent);
      }
    };
    reader.readAsDataURL(file);
  });

  onProgress?.(55);

  let idToken = "";
  try {
    if (auth.currentUser) {
      idToken = await auth.currentUser.getIdToken();
    }
  } catch (tokenErr) {
    console.warn("Could not obtain auth ID token:", tokenErr);
  }

  const reqHeaders: Record<string, string> = {
    "Content-Type": "application/json",
  };
  if (idToken) {
    reqHeaders["Authorization"] = `Bearer ${idToken}`;
  }

  const response = await fetch("/api/upload", {
    method: "POST",
    headers: reqHeaders,
    body: JSON.stringify({
      fileData,
      fileName: file.name,
      fileType: file.type || "application/octet-stream",
      category,
    }),
  });

  onProgress?.(85);

  if (!response.ok) {
    let errorMsg = `فشل الرفع (خطأ ${response.status})`;
    try {
      const errJson = await response.json();
      if (errJson?.error) errorMsg = errJson.error;
    } catch {
      // ignore
    }
    throw new Error(errorMsg);
  }

  const result = await response.json();
  if (!result.success) {
    throw new Error(result.error || "فشل معالجة الرفع");
  }

  onProgress?.(100);

  return {
    success: true,
    url: result.url,
    fileName: result.fileName || file.name,
    fileType: result.fileType || file.type,
    size: result.size || file.size,
  };
}
