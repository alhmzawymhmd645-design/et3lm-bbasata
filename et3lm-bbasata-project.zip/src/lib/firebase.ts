import { initializeApp, getApps } from "firebase/app";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  query,
  where,
  orderBy,
  deleteDoc,
  onSnapshot,
} from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";
import { UserProfile, UserRole } from "../types";

export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

// Initialize Firebase safely
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];

// CRITICAL: Export Firestore with configured DatabaseId as required by AI Studio
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      providerInfo:
        auth.currentUser?.providerData?.map((p) => ({
          providerId: p.providerId,
          email: p.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection on boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.warn("Please check your Firebase configuration or connectivity.");
    }
    return false;
  }
}

// Primary Admin Email
export const SUPER_ADMIN_EMAIL = "alhmzawymhmd645@gmail.com";

export function isSuperAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  return email.trim().toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
}

// User Profile sync helper
export async function syncUserProfile(
  firebaseUser: FirebaseUser,
  additionalData?: Partial<UserProfile>
): Promise<UserProfile> {
  const userRef = doc(db, "users", firebaseUser.uid);
  try {
    const userSnap = await getDoc(userRef);
    const isAdminEmail = isSuperAdminEmail(firebaseUser.email);
    
    if (userSnap.exists()) {
      const existingData = userSnap.data() as UserProfile;
      let needsUpdate = false;
      const updates: Partial<UserProfile> = {};

      // Ensure super admin retains admin role
      if (isAdminEmail && existingData.role !== "admin") {
        updates.role = "admin";
        existingData.role = "admin";
        needsUpdate = true;
      }

      if (additionalData?.displayName && additionalData.displayName !== existingData.displayName) {
        updates.displayName = additionalData.displayName;
        existingData.displayName = additionalData.displayName;
        needsUpdate = true;
      }

      if (additionalData?.phone && additionalData.phone !== existingData.phone) {
        updates.phone = additionalData.phone;
        existingData.phone = additionalData.phone;
        needsUpdate = true;
      }

      if (needsUpdate) {
        updates.updatedAt = new Date().toISOString();
        await updateDoc(userRef, updates);
      }

      return existingData;
    } else {
      const newProfile: UserProfile = {
        uid: firebaseUser.uid,
        email: firebaseUser.email || "",
        displayName:
          additionalData?.displayName ||
          firebaseUser.displayName ||
          firebaseUser.email?.split("@")[0] ||
          "طالب جديد",
        phone: additionalData?.phone || "",
        photoURL: firebaseUser.photoURL || undefined,
        role: isAdminEmail ? "admin" : (additionalData?.role || "student"),
        createdAt: new Date().toISOString(),
      };
      await setDoc(userRef, newProfile);
      
      // If admin, record in /admins collection as well
      if (isAdminEmail) {
        await setDoc(doc(db, "admins", firebaseUser.uid), {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          role: "admin",
          createdAt: new Date().toISOString(),
        });
      }
      
      return newProfile;
    }
  } catch (error) {
    console.error("syncUserProfile Firestore error:", error);
    const isAdminEmail = isSuperAdminEmail(firebaseUser.email);
    return {
      uid: firebaseUser.uid,
      email: firebaseUser.email || "",
      displayName:
        additionalData?.displayName ||
        firebaseUser.displayName ||
        firebaseUser.email?.split("@")[0] ||
        "طالب جديد",
      phone: additionalData?.phone || "",
      role: isAdminEmail ? "admin" : "student",
      createdAt: new Date().toISOString(),
    };
  }
}
