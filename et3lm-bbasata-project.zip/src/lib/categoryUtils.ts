import { CourseCategory, HierarchicalCategoryNode, Course } from "../types";

/**
 * Builds a hierarchical tree structure from a flat array of categories.
 * Fully resilient against null/undefined, missing IDs, and circular parent references.
 */
export function buildCategoryTree(
  categories: CourseCategory[] = [],
  courses: Course[] = []
): HierarchicalCategoryNode[] {
  if (!Array.isArray(categories) || categories.length === 0) return [];

  const safeCourses = Array.isArray(courses) ? courses : [];
  const catMap = new Map<string, HierarchicalCategoryNode>();

  // Filter valid categories with non-empty ID
  const validCategories = categories.filter((c) => c && typeof c.id === "string" && c.id.trim() !== "");

  // Initialize all nodes
  validCategories.forEach((cat) => {
    catMap.set(cat.id, {
      ...cat,
      children: [],
      courseCount: 0,
      path: [cat.name || ""],
      depth: 0,
    });
  });

  const rootNodes: HierarchicalCategoryNode[] = [];

  // Helper to detect cycle: check if target is an ancestor of potential parent
  const isAncestor = (ancestorId: string, childId: string, visited = new Set<string>()): boolean => {
    if (!childId || visited.has(childId)) return false;
    visited.add(childId);
    const node = catMap.get(childId);
    if (!node || !node.parentId) return false;
    if (node.parentId === ancestorId) return true;
    return isAncestor(ancestorId, node.parentId, visited);
  };

  // Link children to parents with cycle prevention
  validCategories.forEach((cat) => {
    const node = catMap.get(cat.id);
    if (!node) return;

    if (
      cat.parentId &&
      cat.parentId !== cat.id &&
      catMap.has(cat.parentId) &&
      !isAncestor(cat.id, cat.parentId)
    ) {
      const parent = catMap.get(cat.parentId)!;
      parent.children = parent.children || [];
      parent.children.push(node);
      node.depth = (parent.depth ?? 0) + 1;
      node.path = [...(parent.path || [parent.name || ""]), cat.name || ""];
    } else {
      node.depth = 0;
      node.path = [cat.name || ""];
      rootNodes.push(node);
    }
  });

  // Sort nodes at each level by order with cycle guard
  const sortNodes = (nodes: HierarchicalCategoryNode[], visited = new Set<string>()) => {
    nodes.sort((a, b) => (a.order || 0) - (b.order || 0));
    nodes.forEach((node) => {
      if (node && !visited.has(node.id)) {
        visited.add(node.id);
        if (node.children && node.children.length > 0) {
          sortNodes(node.children, visited);
        }
      }
    });
  };

  sortNodes(rootNodes);

  // Calculate course counts safely
  const calculateCourseCounts = (node: HierarchicalCategoryNode): number => {
    if (!node || !node.id) return 0;
    const descendantIds = getDescendantCategoryIds(node.id, validCategories);
    const descendantNames = new Set(
      validCategories
        .filter((c) => c && descendantIds.includes(c.id) && c.name)
        .map((c) => (c.name || "").toLowerCase())
    );

    const directAndDescendantCourses = safeCourses.filter((c) => {
      if (!c || !c.published) return false;
      // Match by categoryId
      if (c.categoryId && descendantIds.includes(c.categoryId)) return true;
      // Match by hierarchical categoryIds array
      if (Array.isArray(c.categoryIds) && c.categoryIds.some((id) => descendantIds.includes(id))) return true;
      // Match by legacy category name string
      if (c.category && typeof c.category === "string" && descendantNames.has(c.category.toLowerCase())) return true;
      // Match by categoryPath array
      if (
        Array.isArray(c.categoryPath) &&
        c.categoryPath.some((p) => typeof p === "string" && descendantNames.has(p.toLowerCase()))
      ) {
        return true;
      }
      return false;
    });

    node.courseCount = directAndDescendantCourses.length;
    return node.courseCount;
  };

  const visitedCounts = new Set<string>();
  const populateCounts = (n: HierarchicalCategoryNode) => {
    if (!n || visitedCounts.has(n.id)) return;
    visitedCounts.add(n.id);
    calculateCourseCounts(n);
    if (Array.isArray(n.children)) {
      n.children.forEach(populateCounts);
    }
  };

  rootNodes.forEach(populateCounts);

  return rootNodes;
}

/**
 * Returns an array containing the category ID and all of its descendant IDs.
 * Implements BFS with cycle detection.
 */
export function getDescendantCategoryIds(
  categoryId: string,
  categories: CourseCategory[] = []
): string[] {
  if (!categoryId || !Array.isArray(categories)) return [];

  const result: string[] = [categoryId];
  const queue: string[] = [categoryId];
  const visited = new Set<string>([categoryId]);

  while (queue.length > 0) {
    const currentId = queue.shift()!;
    const children = categories.filter((c) => c && c.parentId === currentId && !visited.has(c.id));
    children.forEach((child) => {
      if (child && child.id) {
        visited.add(child.id);
        result.push(child.id);
        queue.push(child.id);
      }
    });
  }

  return result;
}

/**
 * Returns the path of category items from root to the specified category.
 * Guarded against circular references.
 */
export function getCategoryAncestry(
  categoryIdOrName: string,
  categories: CourseCategory[] = []
): CourseCategory[] {
  if (!categoryIdOrName || !Array.isArray(categories) || categories.length === 0) return [];

  const target = categories.find(
    (c) => c && (c.id === categoryIdOrName || (c.name && c.name.toLowerCase() === categoryIdOrName.toLowerCase()))
  );
  if (!target) return [];

  const path: CourseCategory[] = [target];
  const visited = new Set<string>([target.id]);
  let current: CourseCategory = target;

  while (current && current.parentId && !visited.has(current.parentId)) {
    visited.add(current.parentId);
    const parent = categories.find((c) => c && c.id === current.parentId);
    if (parent) {
      path.unshift(parent);
      current = parent;
    } else {
      break;
    }
  }

  return path;
}

/**
 * Returns human-readable breadcrumb items for a given course.
 */
export function getCourseBreadcrumbs(
  course: Course | null | undefined,
  categories: CourseCategory[] = []
): string[] {
  if (!course) return [];

  if (Array.isArray(course.categoryPath) && course.categoryPath.length > 0) {
    return course.categoryPath;
  }

  if (course.categoryId) {
    const ancestry = getCategoryAncestry(course.categoryId, categories);
    if (ancestry.length > 0) {
      return ancestry.map((c) => c.name);
    }
  }

  if (course.category && typeof course.category === "string") {
    const ancestry = getCategoryAncestry(course.category, categories);
    if (ancestry.length > 0) {
      return ancestry.map((c) => c.name);
    }
    return [course.category];
  }

  return [];
}

/**
 * Checks whether a course belongs to a category or any of its children.
 * Works seamlessly with both new hierarchical fields and legacy flat course objects.
 */
export function isCourseInSelectedCategory(
  course: Course | null | undefined,
  selectedCategoryIdentifier: string, // could be 'all', an ID, or a Name
  categories: CourseCategory[] = []
): boolean {
  if (!selectedCategoryIdentifier || selectedCategoryIdentifier === "all") {
    return true;
  }
  if (!course) return false;

  const safeCategories = Array.isArray(categories) ? categories : [];
  const category = safeCategories.find(
    (c) =>
      c &&
      (c.id === selectedCategoryIdentifier ||
        (c.name && c.name.toLowerCase() === selectedCategoryIdentifier.toLowerCase()))
  );

  if (!category) {
    // Fallback: direct name match
    return (
      (typeof course.category === "string" &&
        course.category.toLowerCase() === selectedCategoryIdentifier.toLowerCase()) ||
      (Array.isArray(course.categoryPath) &&
        course.categoryPath.some(
          (p) => typeof p === "string" && p.toLowerCase() === selectedCategoryIdentifier.toLowerCase()
        ))
    );
  }

  const descendantIds = getDescendantCategoryIds(category.id, safeCategories);
  const descendantNames = new Set(
    safeCategories
      .filter((c) => c && descendantIds.includes(c.id) && c.name)
      .map((c) => (c.name || "").toLowerCase())
  );

  if (course.categoryId && descendantIds.includes(course.categoryId)) return true;
  if (Array.isArray(course.categoryIds) && course.categoryIds.some((id) => descendantIds.includes(id))) return true;
  if (typeof course.category === "string" && descendantNames.has(course.category.toLowerCase())) return true;
  if (
    Array.isArray(course.categoryPath) &&
    course.categoryPath.some((p) => typeof p === "string" && descendantNames.has(p.toLowerCase()))
  ) {
    return true;
  }

  return false;
}

/**
 * Human readable label for hierarchy depth.
 */
export function getDepthBadgeInfo(depth: number, isAr: boolean) {
  switch (depth) {
    case 0:
      return {
        label: isAr ? "قسم رئيسي" : "Main Category",
        colorClass: "bg-amber-500/15 text-[#D4AF37] border-amber-500/30",
        level: 1,
      };
    case 1:
      return {
        label: isAr ? "قسم فرعي" : "Sub Category",
        colorClass: "bg-blue-500/15 text-blue-400 border-blue-500/30",
        level: 2,
      };
    case 2:
    default:
      return {
        label: isAr ? "تصنيف / مادة" : "Subject / Track",
        colorClass: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
        level: 3,
      };
  }
}
