import { doc, getDoc, setDoc, collection, getDocs } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "./firebase";
import {
  Course,
  Lesson,
  PlatformSettings,
  Testimonial,
  CourseCategory,
  CourseLevelItem,
} from "../types";

export const DEFAULT_SETTINGS: PlatformSettings = {
  platformName: "اتعلم ببساطة",
  platformNameEn: "Learn Simply",
  logoUrl: "",
  etisalatCashNumber: "01157783934", // Official Etisalat Cash number
  description: "المنصة التعليمية الأولى لتبسيط البرمجة والتقنيات الحديثة للشباب العربي بأسلوب سلس وتطبيقي.",
  descriptionEn: "The leading Arabic learning platform for practical coding, AI, and modern tech skills.",
  contactEmail: "alhmzawymhmd645@gmail.com",
  contactPhone: "+20 115 778 3934",
  primaryColor: "#F59E0B",
  announcement: "خصم خاص 40% بمناسبة إطلاق المنصة عند الدفع عبر محفظة Etisalat Cash!",
  aiAutoReplyEnabled: true,
  updatedAt: new Date().toISOString(),
};

export const INITIAL_CATEGORIES: CourseCategory[] = [
  // 1. Root Main Category: الطلاب والتعليم المدرسي (Students)
  {
    id: "cat-students",
    name: "طلاب",
    nameEn: "Students & Schooling",
    description: "المناهج الدراسية والدروس التعليمية التأسيسية والمتقدمة للمراحل المختلفة.",
    icon: "GraduationCap",
    active: true,
    order: 1,
    parentId: null,
    depth: 0,
    createdAt: new Date().toISOString(),
  },
  // Subcategories under "طلاب"
  {
    id: "cat-primary",
    name: "ابتدائي",
    nameEn: "Primary School",
    description: "المرحلة الابتدائية وتأسيس المواد العلمية واللغوية.",
    icon: "BookOpen",
    active: true,
    order: 1,
    parentId: "cat-students",
    depth: 1,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-prep",
    name: "إعدادي",
    nameEn: "Preparatory School",
    description: "المرحلة الإعدادية والتحضير للمفاهيم المتقدمة.",
    icon: "BookOpen",
    active: true,
    order: 2,
    parentId: "cat-students",
    depth: 1,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-secondary",
    name: "ثانوي",
    nameEn: "Secondary School",
    description: "المرحلة الثانوية والتأهيل للجامعة واختبارات الثانوية العامة.",
    icon: "Sparkles",
    active: true,
    order: 3,
    parentId: "cat-students",
    depth: 1,
    createdAt: new Date().toISOString(),
  },
  // Subjects under "ابتدائي"
  {
    id: "cat-prim-math",
    name: "رياضيات ابتدائي",
    nameEn: "Primary Math",
    description: "تأسيس الحساب والعمليات الرياضية والأشكال الهندسية.",
    icon: "BookMarked",
    active: true,
    order: 1,
    parentId: "cat-primary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-prim-science",
    name: "علوم ابتدائي",
    nameEn: "Primary Science",
    description: "استكشاف الطبيعة والظواهر العلمية الأساسية.",
    icon: "Flame",
    active: true,
    order: 2,
    parentId: "cat-primary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-prim-arabic",
    name: "لغة عربية ابتدائي",
    nameEn: "Primary Arabic",
    description: "القراءة والنحو والتعبير الإملائي السليم.",
    icon: "BookOpen",
    active: true,
    order: 3,
    parentId: "cat-primary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-prim-english",
    name: "لغة إنجليزية ابتدائي",
    nameEn: "Primary English",
    description: "المفردات وتكوين الجمل والمحادثات البسيطة.",
    icon: "Globe",
    active: true,
    order: 4,
    parentId: "cat-primary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  // Subjects under "إعدادي"
  {
    id: "cat-prep-math",
    name: "رياضيات إعدادي",
    nameEn: "Preparatory Math",
    description: "الجبر والهندسة وحساب المثلثات للمرحلة الإعدادية.",
    icon: "BookMarked",
    active: true,
    order: 1,
    parentId: "cat-prep",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-prep-science",
    name: "علوم إعدادي",
    nameEn: "Preparatory Science",
    description: "الفيزياء والكيمياء والأحياء المبسطة للشهادة الإعدادية.",
    icon: "Flame",
    active: true,
    order: 2,
    parentId: "cat-prep",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  // Subjects under "ثانوي"
  {
    id: "cat-sec-chemistry",
    name: "كيمياء",
    nameEn: "Chemistry",
    description: "الكيمياء العضوية، الاتزان الكيميائي، والجدول الدوري للثانوية العامة.",
    icon: "Flame",
    active: true,
    order: 1,
    parentId: "cat-secondary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-sec-physics",
    name: "فيزياء",
    nameEn: "Physics",
    description: "الفيزياء الكهربية، الكهرومغناطيسية، والفيزياء الحديثة للثانوية العامة.",
    icon: "Cpu",
    active: true,
    order: 2,
    parentId: "cat-secondary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-sec-math",
    name: "رياضيات ثانوي",
    nameEn: "Secondary Math",
    description: "التفاضل والتكامل، الجبر والهندسة الفراغية، والاستاتيكا والديناميكا.",
    icon: "BookMarked",
    active: true,
    order: 3,
    parentId: "cat-secondary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-sec-biology",
    name: "أحياء",
    nameEn: "Biology",
    description: "البيولوجيا الجزيئية، الوراثة، ودعامات الكائنات الحية.",
    icon: "Sparkles",
    active: true,
    order: 4,
    parentId: "cat-secondary",
    depth: 2,
    createdAt: new Date().toISOString(),
  },

  // 2. Root Main Category: مبرمجين ومطورين (Developers)
  {
    id: "cat-dev",
    name: "مبرمجين",
    nameEn: "Developers & Software",
    description: "مسارات البرمجة وهندسة البرمجيات وتطوير الحلول السحابية والويب.",
    icon: "Code",
    active: true,
    order: 2,
    parentId: null,
    depth: 0,
    createdAt: new Date().toISOString(),
  },
  // Subcategories under "مبرمجين"
  {
    id: "cat-web",
    name: "برمجة الويب",
    nameEn: "Web Development",
    description: "بناء تطبيقات الويب الحديثة، الواجهات الأمامية والأنظمة الخلفية وقواعد البيانات.",
    icon: "Globe",
    active: true,
    order: 1,
    parentId: "cat-dev",
    depth: 1,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-python",
    name: "بايثون والبيانات",
    nameEn: "Python & Data",
    description: "لغة بايثون من الصفر للأتمتة ومعالجة الملفات والبيانات والذكاء الاصطناعي.",
    icon: "Terminal",
    active: true,
    order: 2,
    parentId: "cat-dev",
    depth: 1,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-ai",
    name: "الذكاء الاصطناعي",
    nameEn: "AI & Machine Learning",
    description: "نماذج الذكاء الاصطناعي التوليدي، Gemini API، هندسة الأوامر، والوكلاء الأذكياء.",
    icon: "Bot",
    active: true,
    order: 3,
    parentId: "cat-dev",
    depth: 1,
    createdAt: new Date().toISOString(),
  },

  // 3. Root Main Category: مصممون ومبدعون (Designers)
  {
    id: "cat-designers",
    name: "مصممين",
    nameEn: "Designers & UI/UX",
    description: "تصميم تجربة المستخدم، الواجهات التفاعلية، والهوية البصرية.",
    icon: "Palette",
    active: true,
    order: 3,
    parentId: null,
    depth: 0,
    createdAt: new Date().toISOString(),
  },
  {
    id: "cat-design",
    name: "التصميم الرقمي",
    nameEn: "UI/UX Design",
    description: "تصميم واجهات وتجربة المستخدم باحترافية، بناء النماذج التفاعلية وأنظمة التصميم على Figma.",
    icon: "Palette",
    active: true,
    order: 1,
    parentId: "cat-designers",
    depth: 1,
    createdAt: new Date().toISOString(),
  },
];

export const INITIAL_LEVELS: CourseLevelItem[] = [
  {
    id: "lvl-beginner",
    name: "مبتدئ",
    nameEn: "Beginner",
    description: "مناسب تماماً للطلاب والمبتدئين بدون أي خبرة سابقة.",
    active: true,
    order: 1,
    createdAt: new Date().toISOString(),
  },
  {
    id: "lvl-intermediate",
    name: "متوسط",
    nameEn: "Intermediate",
    description: "يتطلب معرفة بالمبادئ والأساسيات البرمجية وبناء المشاريع المتوسطة.",
    active: true,
    order: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: "lvl-advanced",
    name: "متقدم",
    nameEn: "Advanced",
    description: "للمحترفين لإتقان المعماريات المتقدمة، تحسين الأداء والأمان العالي.",
    active: true,
    order: 3,
    createdAt: new Date().toISOString(),
  },
];

export const INITIAL_COURSES: Omit<Course, "id">[] = [
  {
    title: "دبلومة تطوير الويب الشاملة Full-Stack من الصفر",
    titleEn: "Complete Full-Stack Web Development Bootcamp",
    description: "تعلم بناء تطبيقات الويب الحديثة والاحترافية خطوة بخطوة باستخدام React, Node.js, Express, و Firebase مع مشاريع تخرج واقعية.",
    descriptionEn: "Master modern web development from scratch using React, Node.js, and Cloud Firestore with production-ready capstone projects.",
    thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80",
    price: 450,
    originalPrice: 850,
    level: "مبتدئ",
    category: "برمجة الويب",
    categoryId: "cat-web",
    categoryIds: ["cat-dev", "cat-web"],
    categoryPath: ["مبرمجين", "برمجة الويب"],
    duration: "28 ساعة",
    lessonCount: 6,
    published: true,
    featured: true,
    rating: 4.9,
    studentsCount: 1420,
    whatYouWillLearn: [
      "أساسيات JavaScript الحديثة (ES6+) والمفاهيم المتقدمة",
      "بناء واجهات تفاعلية متجاوبة باستخدام React و Tailwind CSS",
      "إنشاء خوادم RESTful APIs وقواعد بيانات سريعة",
      "ربط وتأمين المدفوعات والأنظمة السحابية"
    ],
    requirements: ["حاسوب متصل بالإنترنت", "شغف التعلم والتطبيق العملي"],
    createdAt: new Date().toISOString(),
  },
  {
    title: "احترف الكيمياء للثانوية العامة: المفاهيم والتطبيقات والمسائل",
    titleEn: "Secondary Chemistry Masterclass",
    description: "شرح شامل ومبسط لمنهج الكيمياء للثانوية العامة مع تجارب تفاعلية وحل أكثر من 500 مسألة نموذجية من الامتحانات السابقة.",
    descriptionEn: "Comprehensive and simplified secondary chemistry curriculum with interactive problem-solving.",
    thumbnail: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800&auto=format&fit=crop&q=80",
    price: 320,
    originalPrice: 550,
    level: "متوسط",
    category: "كيمياء",
    categoryId: "cat-sec-chemistry",
    categoryIds: ["cat-students", "cat-secondary", "cat-sec-chemistry"],
    categoryPath: ["طلاب", "ثانوي", "كيمياء"],
    duration: "22 ساعة",
    lessonCount: 5,
    published: true,
    featured: true,
    rating: 4.96,
    studentsCount: 940,
    whatYouWillLearn: [
      "العناصر الانتقالية والخواص الكيميائية والفيزيائية",
      "الاتزان الأيوني والكيميائي وقوانين لوشاتيليه",
      "الكيمياء العضوية من الصفر حتى التسمية والتفاعلات",
      "استراتيجيات حل أسئلة الاختيار من متعدد بسهولة"
    ],
    requirements: ["كتاب الوزارة", "آلة حاسبة علمية"],
    createdAt: new Date().toISOString(),
  },
  {
    title: "الفيزياء الكهربية والحديثة للثانوية العامة ببساطة",
    titleEn: "Secondary Physics Simplified",
    description: "كورس متكامل في الفيزياء يغطي قوانين كيرشوف، الحث الكهرومغناطيسي، وأسرار الفيزياء الحديثة مع تدريبات عملية مستمرة.",
    descriptionEn: "Complete physics course covering electrical circuits, electromagnetism, and modern physics.",
    thumbnail: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800&auto=format&fit=crop&q=80",
    price: 350,
    originalPrice: 600,
    level: "متقدم",
    category: "فيزياء",
    categoryId: "cat-sec-physics",
    categoryIds: ["cat-students", "cat-secondary", "cat-sec-physics"],
    categoryPath: ["طلاب", "ثانوي", "فيزياء"],
    duration: "24 ساعة",
    lessonCount: 4,
    published: true,
    featured: true,
    rating: 4.92,
    studentsCount: 1080,
    whatYouWillLearn: [
      "قانون أوم وقوانين كيرشوف للدوائر المعقدة",
      "أجهزة القياس الكهربي وتطبيقاتها",
      "ظاهرة كومتون والتأثير الكهروضوئي",
      "حل بنك الأسئلة الشامل خطوة بخطوة"
    ],
    requirements: ["فهم الرياضيات الأساسية"],
    createdAt: new Date().toISOString(),
  },
  {
    title: "احترف الذكاء الاصطناعي وهندسة الأوامر وبناء وكلاء AI",
    titleEn: "Master AI, Prompt Engineering & Autonomous Agents",
    description: "اكتشف أسرار نماذج Gemini و ChatGPT، وتعلم كيفية دمج الذكاء الاصطناعي في مشاريعك وبناء وكلاء أذكياء يوفرون وقتك وجهدك.",
    descriptionEn: "Unlock generative AI models, Gemini API integration, and build autonomous agents for real business use.",
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&auto=format&fit=crop&q=80",
    price: 550,
    originalPrice: 990,
    level: "متوسط",
    category: "الذكاء الاصطناعي",
    categoryId: "cat-ai",
    categoryIds: ["cat-dev", "cat-ai"],
    categoryPath: ["مبرمجين", "الذكاء الاصطناعي"],
    duration: "18 ساعة",
    lessonCount: 5,
    published: true,
    featured: true,
    rating: 4.95,
    studentsCount: 890,
    whatYouWillLearn: [
      "إتقان هندسة الأوامر (Prompt Engineering) المتقدمة",
      "التعامل مع واجهات Gemini API وبناء تطبيقات ذكية",
      "إنشاء Chatbots تفاعلية قادرة على معالجة ملفات وصور",
      "بناء وكلاء أذكياء (AI Agents) لتنفيذ المهام الآلية"
    ],
    requirements: ["معرفة بسيطة بمبادئ البرمجة"],
    createdAt: new Date().toISOString(),
  },
  {
    title: "بايثون الشامل: من الأساسيات إلى الأتمتة وتحليل البيانات",
    titleEn: "Python Masterclass: Automation & Data Analysis",
    description: "كورس عملي مكثف لتعلم لغة بايثون وتطبيقها في أتمتة المهام اليومية، قراءة الملفات، وتحليل البيانات بطريقة مبسطة وشيقة.",
    descriptionEn: "Learn Python through practical hands-on mini projects, task automation, and data insights.",
    thumbnail: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
    price: 350,
    originalPrice: 600,
    level: "مبتدئ",
    category: "بايثون والبيانات",
    categoryId: "cat-python",
    categoryIds: ["cat-dev", "cat-python"],
    categoryPath: ["مبرمجين", "بايثون والبيانات"],
    duration: "16 ساعة",
    lessonCount: 4,
    published: true,
    featured: false,
    rating: 4.85,
    studentsCount: 1150,
    whatYouWillLearn: [
      "مفاهيم البرمجة الكائنية OOP في بايثون",
      "أتمتة الأعمال الروتينية ومعالجة ملفات Excel و PDF",
      "استخراج البيانات من الويب (Web Scraping)",
      "تحليل وتصوير البيانات الرسومية"
    ],
    requirements: ["لا يشترط أي خبرة سابقة في البرمجة"],
    createdAt: new Date().toISOString(),
  },
  {
    title: "تصميم واجهات وتجربة المستخدم UI/UX باحترافية على Figma",
    titleEn: "Professional UI/UX Design & Prototyping in Figma",
    description: "تعلم تصميم تطبيقات ومواقع جذابة وسهلة الاستخدام من الصفر حتى إنشاء نماذج أولية تفاعلية قابلة للاختبار والتسليم للمبرمجين.",
    descriptionEn: "Master UI/UX design thinking, design systems, and advanced prototyping with Figma.",
    thumbnail: "https://images.unsplash.com/photo-1581291518655-9523c932edcf?w=800&auto=format&fit=crop&q=80",
    price: 400,
    originalPrice: 750,
    level: "مبتدئ",
    category: "التصميم الرقمي",
    categoryId: "cat-design",
    categoryIds: ["cat-designers", "cat-design"],
    categoryPath: ["مصممين", "التصميم الرقمي"],
    duration: "14 ساعة",
    lessonCount: 4,
    published: true,
    featured: true,
    rating: 4.88,
    studentsCount: 760,
    whatYouWillLearn: [
      "قواعد التناسق اللوني واختيار الخطوط والتباعد الرياضي",
      "بناء أنظمة التصميم (Design Systems) القابلة للتوسع",
      "تصميم واجهات الهواتف ومواقع الويب المتجاوبة",
      "إنشاء نماذج حركية تفاعلية (Interactive Prototypes)"
    ],
    requirements: ["جهاز كمبيوتر وبرنامج Figma المجاني"],
    createdAt: new Date().toISOString(),
  }
];

export const INITIAL_LESSONS_DATA: Record<number, Omit<Lesson, "id" | "courseId">[]> = {
  0: [
    {
      title: "1. مقدمة الكورس وخارطة الطريق لعالم الويب",
      description: "نظرة شاملة على كيفية عمل الإنترنت، الفرق بين Frontend و Backend، وتهيئة بيئة العمل التفاعلية.",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Safe fallback embed / sample
      duration: "12:45",
      order: 1,
      isFreePreview: true,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "2. بناء الهيكل الأساسي بـ HTML5 الدلالي والتنسيقات الحديثة",
      description: "تعلم تنظيم عناصر الصفحة بمعايير الوصولية SEO و Semantic Tags.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      duration: "24:10",
      order: 2,
      isFreePreview: true,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "3. احتراف Tailwind CSS وتصميم واجهات متجاوبة مذهلة",
      description: "كيفية استغلال Tailwind لبناء مكونات جميلة بسرعة فائقة وتجاوب تام مع الشاشات.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      duration: "32:15",
      order: 3,
      isFreePreview: false,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "4. أساسيات JavaScript التفاعلية وإدارة الحالة",
      description: "التعامل مع DOM، الأحداث، الدوال غير المتزامنة Async/Await، وجلب البيانات من APIs.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      duration: "45:00",
      order: 4,
      isFreePreview: false,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "5. مقدمة React ومكونات واجهة المستخدم التفاعلية",
      description: "فهم الـ Hooks (useState, useEffect)، وتمرير Props وبناء تطبيق عملي.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      duration: "38:20",
      order: 5,
      isFreePreview: false,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "6. ربط قاعدة البيانات Firebase وإطلاق المشروع على الويب",
      description: "تخزين البيانات الحية، المصادقة وتأمين التطبيق ونشره للجمهور.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      duration: "52:10",
      order: 6,
      isFreePreview: false,
      published: true,
      createdAt: new Date().toISOString(),
    },
  ],
  1: [
    {
      title: "1. ثورة نماذج الذكاء الاصطناعي وكيف تغير العالم",
      description: "فهم كيفية عمل النماذج اللغوية الكبيرة LLMs وأحدث تقنيات الـ Generative AI.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
      duration: "18:30",
      order: 1,
      isFreePreview: true,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "2. تقنيات هندسة الأوامر (Prompt Engineering) المتقدمة",
      description: "أسرار صياغة التعليمات للحصول على مخرجات دقيقة وتنسيق JSON مثالي.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
      duration: "28:40",
      order: 2,
      isFreePreview: false,
      published: true,
      createdAt: new Date().toISOString(),
    },
    {
      title: "3. دمج Gemini API في تطبيقات الويب وتوليد المحتوى",
      description: "طريقة استخدام @google/genai SDK وربط النماذج الذكية بالخادم والواجهة.",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
      duration: "35:10",
      order: 3,
      isFreePreview: false,
      published: true,
      createdAt: new Date().toISOString(),
    },
  ]
};

export const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: "test-1",
    name: "مروان طارق",
    role: "مطور ويب واجهات أمامية",
    comment: "«اتعلم ببساطة» غيرت نظرتي للبرمجة تماماً. الشرح واضح جداً، والدفع عبر اتصالات كاش كان سريع وسهل والإدمن فعل الكورس في دقايق!",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
    courseTitle: "دبلومة تطوير الويب الشاملة Full-Stack",
    createdAt: new Date().toISOString(),
  },
  {
    id: "test-2",
    name: "سارة عبد الرحمن",
    role: "طالبة هندسة حاسبات",
    comment: "مساعد الذكاء الاصطناعي داخل الكورس رهيب! بيلخصلي الدروس ويجاوب على أي نقطة مش واضحة فوراً ويختبرني فيها.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    courseTitle: "احترف الذكاء الاصطناعي وبناء وكلاء AI",
    createdAt: new Date().toISOString(),
  },
  {
    id: "test-3",
    name: "أحمد حسام",
    role: "مصمم ومبرمج حر",
    comment: "المحتوى غني جداً وأفضل من كورسات بمئات الدولارات. شكراً لفريق اتعلم ببساطة على هذا الإتقان والاهتمام بالتفاصيل.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
    courseTitle: "تصميم واجهات وتجربة المستخدم UI/UX",
    createdAt: new Date().toISOString(),
  },
];

export async function initializePlatformData(): Promise<void> {
  try {
    // 1. Check or initialize settings
    const settingsRef = doc(db, "settings", "general");
    const settingsSnap = await getDoc(settingsRef);
    if (!settingsSnap.exists()) {
      await setDoc(settingsRef, DEFAULT_SETTINGS);
      console.log("Initialized platform settings");
    } else {
      const existingData = settingsSnap.data() as PlatformSettings;
      const needsUpdate =
        existingData.etisalatCashNumber === "01145678901" ||
        !existingData.etisalatCashNumber ||
        existingData.contactEmail === "support@bebasata.edu.eg" ||
        !existingData.contactEmail;

      if (needsUpdate) {
        await setDoc(
          settingsRef,
          {
            ...existingData,
            etisalatCashNumber: "01157783934",
            contactPhone: "+20 115 778 3934",
            contactEmail: "alhmzawymhmd645@gmail.com",
            updatedAt: new Date().toISOString(),
          },
          { merge: true }
        );
        console.log("Updated settings in Firestore");
      }
    }

    // 2. Check if courses exist; if not, seed courses & lessons
    const coursesCol = collection(db, "courses");
    const coursesSnap = await getDocs(coursesCol);
    if (coursesSnap.empty) {
      console.log("Seeding initial courses and lessons...");
      for (let i = 0; i < INITIAL_COURSES.length; i++) {
        const courseId = `course-${i + 1}`;
        const courseData: Course = {
          ...INITIAL_COURSES[i],
          id: courseId,
        };
        await setDoc(doc(db, "courses", courseId), courseData);

        // Seed lessons for this course
        const lessons = INITIAL_LESSONS_DATA[i] || [];
        for (let j = 0; j < lessons.length; j++) {
          const lessonId = `lesson-${courseId}-${j + 1}`;
          const lessonData: Lesson = {
            ...lessons[j],
            id: lessonId,
            courseId,
          };
          await setDoc(doc(db, "lessons", lessonId), lessonData);
        }
      }
      console.log("Courses and lessons seeded successfully");
    }

    // 3. Check and seed testimonials
    const testCol = collection(db, "testimonials");
    const testSnap = await getDocs(testCol);
    if (testSnap.empty) {
      for (const t of INITIAL_TESTIMONIALS) {
        await setDoc(doc(db, "testimonials", t.id), t);
      }
    }

    // 4. Check and seed categories
    const categoriesCol = collection(db, "categories");
    const categoriesSnap = await getDocs(categoriesCol);
    if (categoriesSnap.empty) {
      console.log("Seeding initial categories...");
      for (const cat of INITIAL_CATEGORIES) {
        await setDoc(doc(db, "categories", cat.id), cat);
      }
      console.log("Categories seeded successfully");
    }

    // 5. Check and seed course levels
    const levelsCol = collection(db, "course_levels");
    const levelsSnap = await getDocs(levelsCol);
    if (levelsSnap.empty) {
      console.log("Seeding initial course levels...");
      for (const lvl of INITIAL_LEVELS) {
        await setDoc(doc(db, "course_levels", lvl.id), lvl);
      }
      console.log("Course levels seeded successfully");
    }
  } catch (error) {
    console.error("Data seed error:", error);
  }
}
