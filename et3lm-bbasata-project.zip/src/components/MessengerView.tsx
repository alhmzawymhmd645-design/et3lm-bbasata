import React, { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import {
  MessageSquare,
  Search,
  Send,
  Bot,
  User,
  ShieldCheck,
  GraduationCap,
  Sparkles,
  Paperclip,
  Image as ImageIcon,
  Check,
  CheckCheck,
  Clock,
  ArrowRight,
  MoreVertical,
  X,
  Plus,
  RefreshCw,
  Phone,
  Info,
  Circle,
  Smile,
  AlertCircle,
  SlidersHorizontal,
} from "lucide-react";
import {
  MessengerConversation,
  MessengerMessage,
  MessengerUserSummary,
} from "../types";

export const MessengerView: React.FC = () => {
  const {
    user,
    isAdmin,
    language,
    activeMessengerTargetUser,
    setActiveMessengerTargetUser,
    setUnreadMessengerCount,
  } = useApp();

  const isAr = language === "ar";

  // Current active user identity (authenticated user or student demo user)
  const currentUserId = user?.uid || "guest_student_" + (typeof window !== "undefined" ? window.sessionStorage?.getItem("guest_chat_id") || (() => {
    const id = "student_" + Math.random().toString(36).substring(2, 7);
    window.sessionStorage?.setItem("guest_chat_id", id);
    return id;
  })() : "guest_user");

  const currentUserName = user?.displayName || (isAr ? "طالب منصة اتعلم ببساطة" : "Platform Student");
  const currentUserRole = isAdmin ? "admin" : (user?.role || "student");
  const currentUserPhoto = user?.photoURL || "";

  // State
  const [conversations, setConversations] = useState<MessengerConversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [activeConversation, setActiveConversation] = useState<MessengerConversation | null>(null);
  const [messages, setMessages] = useState<MessengerMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTab, setFilterTab] = useState<"all" | "unread" | "ai_support">("all");
  
  // User Search Modal / Dropdown
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [userSearchTerm, setUserSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<MessengerUserSummary[]>([]);
  const [isSearchingUsers, setIsSearchingUsers] = useState(false);
  
  // Attachment state
  const [selectedAttachment, setSelectedAttachment] = useState<{ url: string; type: "image" | "file"; name: string } | null>(null);
  const [isUploadingAttachment, setIsUploadingAttachment] = useState(false);

  // Info sidebar toggle on desktop
  const [showParticipantInfo, setShowParticipantInfo] = useState(false);

  // Mobile View state (toggle between list & chat)
  const [mobileActiveView, setMobileActiveView] = useState<"list" | "chat">("list");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatScrollContainerRef = useRef<HTMLDivElement>(null);
  const isInitialLoadRef = useRef(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  // Fetch Conversations List
  const fetchConversations = async (keepSelection = true) => {
    try {
      const res = await fetch(`/api/messenger/conversations?userId=${encodeURIComponent(currentUserId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.conversations)) {
          setConversations(data.conversations);

          // Update total unread badge
          const totalUnread = data.conversations.reduce(
            (sum: number, c: MessengerConversation) => sum + (c.unreadCount || 0),
            0
          );
          setUnreadMessengerCount(totalUnread);

          if (keepSelection && activeConvId) {
            const found = data.conversations.find((c: MessengerConversation) => c.id === activeConvId);
            if (found) {
              setActiveConversation(found);
            }
          }
        }
      }
    } catch (err) {
      console.warn("Failed to fetch conversations:", err);
    }
  };

  // Fetch Messages for Selected Conversation
  const fetchMessagesForActiveConv = async (convId: string) => {
    try {
      const res = await fetch(`/api/messenger/conversations/${encodeURIComponent(convId)}/messages?userId=${encodeURIComponent(currentUserId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.messages)) {
          setMessages(data.messages);
          if (data.conversation) {
            setActiveConversation(data.conversation);
          }
        }
      }
    } catch (err) {
      console.warn("Failed to fetch messages for conversation:", err);
    }
  };

  // Initial Load & Target User Handling
  useEffect(() => {
    fetchConversations(false);
  }, [currentUserId]);

  // Handle direct chat initiation when requested from another component (e.g. teacher card, student dashboard)
  useEffect(() => {
    if (activeMessengerTargetUser) {
      startChatWithUser(activeMessengerTargetUser);
      setActiveMessengerTargetUser(null);
    }
  }, [activeMessengerTargetUser]);

  // Auto-select first conversation if none selected on desktop
  useEffect(() => {
    if (!activeConvId && conversations.length > 0 && typeof window !== "undefined" && window.innerWidth >= 768) {
      selectConversation(conversations[0].id);
    }
  }, [conversations, activeConvId]);

  // Polling for live real-time sync
  useEffect(() => {
    const interval = setInterval(() => {
      fetchConversations(true);
      if (activeConvId) {
        fetchMessagesForActiveConv(activeConvId);
      }
    }, 2500);

    return () => clearInterval(interval);
  }, [activeConvId]);

  // Scroll to bottom cleanly inside chat container only (prevents window jumping)
  useEffect(() => {
    if (chatScrollContainerRef.current) {
      const container = chatScrollContainerRef.current;
      const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 150;
      if (isInitialLoadRef.current || isNearBottom || isSending) {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: isInitialLoadRef.current ? "auto" : "smooth",
        });
        isInitialLoadRef.current = false;
      }
    }
  }, [messages, isSending]);

  // Select a Conversation
  const selectConversation = async (convId: string) => {
    isInitialLoadRef.current = true;
    setPermissionError(null);
    setActiveConvId(convId);
    setMobileActiveView("chat");
    await fetchMessagesForActiveConv(convId);

    // Mark conversation as read
    try {
      await fetch(`/api/messenger/conversations/${encodeURIComponent(convId)}/read`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUserId }),
      });
      fetchConversations(true);
    } catch (err) {
      console.warn("Could not mark conversation as read:", err);
    }
  };

  // Start a Chat with a Specific User
  const startChatWithUser = async (target: {
    uid: string;
    displayName: string;
    role?: string;
    photoURL?: string;
    email?: string;
  }) => {
    try {
      const res = await fetch("/api/messenger/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentUserId,
          targetUserId: target.uid,
          currentUserName,
          targetUserName: target.displayName,
          targetUserRole: target.role || "student",
          targetUserPhoto: target.photoURL || "",
          currentUserRole,
          currentUserPhoto,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.conversation) {
          setIsNewChatModalOpen(false);
          await fetchConversations(false);
          selectConversation(data.conversation.id);
        }
      }
    } catch (err) {
      console.error("Error starting chat with user:", err);
    }
  };

  // Search Platform Users
  const handleSearchUsers = async (term: string) => {
    setUserSearchTerm(term);
    setIsSearchingUsers(true);
    try {
      const res = await fetch(`/api/messenger/users/search?q=${encodeURIComponent(term)}&currentUserId=${encodeURIComponent(currentUserId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.users)) {
          setSearchResults(data.users);
        }
      }
    } catch (err) {
      console.error("Error searching users:", err);
    } finally {
      setIsSearchingUsers(false);
    }
  };

  // Send Message
  const handleSendMessage = async () => {
    if ((!inputText.trim() && !selectedAttachment) || isSending || !activeConvId) return;

    const messageText = inputText.trim();
    const attachment = selectedAttachment;
    setInputText("");
    setSelectedAttachment(null);
    setIsSending(true);

    // Optimistic UI update
    const tempMsg: MessengerMessage = {
      id: `temp_${Date.now()}`,
      conversationId: activeConvId,
      senderId: currentUserId,
      senderName: currentUserName,
      senderPhotoURL: currentUserPhoto,
      role: (currentUserRole === "admin" ? "admin" : currentUserRole === "instructor" ? "instructor" : "student") as any,
      source: "messenger",
      text: messageText,
      attachmentUrl: attachment?.url,
      attachmentType: attachment?.type,
      createdAt: new Date().toISOString(),
      status: "sending",
      readBy: [currentUserId],
    };

    setMessages((prev) => [...prev, tempMsg]);

    // Determine target recipient ID
    let recipientId = "";
    if (activeConversation?.participantIds) {
      recipientId = activeConversation.participantIds.find((id) => id !== currentUserId) || "";
    } else if (activeConversation?.senderId && activeConversation.senderId !== currentUserId) {
      recipientId = activeConversation.senderId;
    }

    try {
      const res = await fetch(`/api/messenger/conversations/${encodeURIComponent(activeConvId)}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: currentUserId,
          senderName: currentUserName,
          senderRole: currentUserRole,
          senderPhotoURL: currentUserPhoto,
          text: messageText,
          attachmentUrl: attachment?.url || "",
          attachmentType: attachment?.type || "image",
          recipientId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          // Replace temp message with server confirmed message
          setMessages((prev) =>
            prev.map((m) => (m.id === tempMsg.id ? data.messageRecord : m))
          );
          if (data.aiReply) {
            setMessages((prev) => [...prev, data.aiReply]);
          }
          fetchConversations(true);
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        if (res.status === 403 || errData.isPermissionBlocked) {
          setPermissionError(errData.error || "تم حظر إرسال الرسائل في هذه المحادثة وفقاً لإعدادات الصلاحيات.");
        }
        setMessages((prev) =>
          prev.map((m) => (m.id === tempMsg.id ? { ...m, status: "failed" } : m))
        );
      }
    } catch (err) {
      console.error("Error sending message:", err);
      setMessages((prev) =>
        prev.map((m) => (m.id === tempMsg.id ? { ...m, status: "failed" } : m))
      );
    } finally {
      setIsSending(false);
    }
  };

  // Handle File Upload for Attachment
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      alert(isAr ? "حجم الملف يتجاوز الحد الأقصى المسموح به (8 ميجابايت)" : "File size exceeds 8MB limit");
      return;
    }

    setIsUploadingAttachment(true);
    const reader = new FileReader();
    reader.onload = () => {
      const isImg = file.type.startsWith("image/");
      setSelectedAttachment({
        url: reader.result as string,
        type: isImg ? "image" : "file",
        name: file.name,
      });
      setIsUploadingAttachment(false);
    };
    reader.readAsDataURL(file);
  };

  // Get Other Participant Info
  const getOtherParticipant = (conv: MessengerConversation) => {
    if (conv.mode === "ai" || conv.senderId === "ai_bot" || conv.participantIds?.includes("ai_bot")) {
      return {
        displayName: isAr ? "المساعد الذكي (Gemini AI)" : "AI Smart Tutor",
        role: "support",
        photoURL: "",
        isOnline: true,
      };
    }

    if (conv.participants && conv.participantIds) {
      const otherId = conv.participantIds.find((id) => id !== currentUserId);
      if (otherId && conv.participants[otherId]) {
        return conv.participants[otherId];
      }
    }

    return {
      displayName: conv.senderName || (isAr ? "مستخدم المنصة" : "Platform User"),
      role: conv.userRole || "student",
      photoURL: conv.profilePic || "",
      isOnline: true,
    };
  };

  // Filtered Conversations
  const filteredConversations = conversations.filter((conv) => {
    const other = getOtherParticipant(conv);
    const matchSearch =
      other.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (conv.lastMessageText && conv.lastMessageText.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchSearch) return false;

    if (filterTab === "unread") {
      return (conv.unreadCount || 0) > 0;
    }
    if (filterTab === "ai_support") {
      return conv.mode === "ai" || other.role === "support" || other.role === "admin";
    }
    return true;
  });

  const activeOtherParticipant = activeConversation ? getOtherParticipant(activeConversation) : null;

  return (
    <div className="w-full max-w-7xl mx-auto px-2 sm:px-6 py-4 sm:py-8 font-sans">
      {/* Title & Quick Actions Header */}
      <div className="flex items-center justify-between mb-4 sm:mb-6">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] flex items-center justify-center text-black font-black shadow-lg shadow-[#D4AF37]/20">
              <MessageSquare className="w-5 h-5 text-black" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {isAr ? "نظام المراسلة الداخلي" : "Internal Messenger Hub"}
              </h1>
              <p className="text-xs text-gray-400">
                {isAr
                  ? "مراسلة مباشرة 100% بين الطلاب والمدرسين والمشرفين والمساعد الذكي"
                  : "Direct peer-to-peer messaging with students, instructors, and AI"}
              </p>
            </div>
          </div>
        </div>

        {/* Start New Chat Button */}
        <button
          onClick={() => {
            setIsNewChatModalOpen(true);
            handleSearchUsers("");
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-bold text-xs sm:text-sm shadow-md shadow-[#D4AF37]/20 transition-all cursor-pointer hover:scale-105 active:scale-95"
        >
          <Plus className="w-4 h-4 text-black" />
          <span>{isAr ? "محادثة جديدة" : "New Chat"}</span>
        </button>
      </div>

      {/* Main Container */}
      <div className="h-[750px] max-h-[82vh] bg-[#111111] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-row relative">
        
        {/* ========================================================================= */}
        {/* LEFT / SIDEBAR: CONVERSATION LIST */}
        {/* ========================================================================= */}
        <div
          className={`w-full md:w-80 lg:w-96 bg-[#141414] border-l md:border-l border-white/10 flex flex-col flex-shrink-0 transition-all duration-300 ${
            mobileActiveView === "chat" ? "hidden md:flex" : "flex"
          }`}
        >
          {/* Sidebar Top: Search & Filters */}
          <div className="p-3.5 sm:p-4 border-b border-white/10 space-y-3 bg-[#161616]">
            <div className="relative">
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={isAr ? "بحث في المحادثات..." : "Search conversations..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-3 pr-10 py-2 rounded-xl bg-[#1F1F1F] border border-white/10 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-[#D4AF37] transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-[#101010] rounded-xl border border-white/5 text-[11px] font-bold">
              <button
                onClick={() => setFilterTab("all")}
                className={`flex-1 py-1.5 rounded-lg transition ${
                  filterTab === "all"
                    ? "bg-[#222222] text-[#D4AF37] shadow-sm"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                {isAr ? "الكل" : "All"}
              </button>
              <button
                onClick={() => setFilterTab("unread")}
                className={`flex-1 py-1.5 rounded-lg transition ${
                  filterTab === "unread"
                    ? "bg-[#222222] text-[#D4AF37] shadow-sm"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                {isAr ? "غير مقروءة" : "Unread"}
              </button>
              <button
                onClick={() => setFilterTab("ai_support")}
                className={`flex-1 py-1.5 rounded-lg transition ${
                  filterTab === "ai_support"
                    ? "bg-[#222222] text-[#D4AF37] shadow-sm"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                {isAr ? "المساعد والإدارة" : "Support"}
              </button>
            </div>
          </div>

          {/* Conversations Scrollable List */}
          <div className="flex-1 overflow-y-auto divide-y divide-white/5 no-scrollbar">
            {filteredConversations.length === 0 ? (
              <div className="p-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 mx-auto flex items-center justify-center text-gray-500">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <p className="text-xs text-gray-400 font-medium">
                  {isAr ? "لا توجد محادثات تطابق بحثك" : "No conversations found"}
                </p>
                <button
                  onClick={() => {
                    setIsNewChatModalOpen(true);
                    handleSearchUsers("");
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#D4AF37] text-xs font-bold transition"
                >
                  {isAr ? "ابحث عن مستخدم للبدء" : "Find users to chat"}
                </button>
              </div>
            ) : (
              filteredConversations.map((conv) => {
                const other = getOtherParticipant(conv);
                const isSelected = activeConvId === conv.id;
                const isAi = conv.mode === "ai" || other.role === "support";
                const isInstructor = other.role === "instructor";
                const isAdminUser = other.role === "admin";
                const unread = conv.unreadCount || 0;

                const lastTime = new Date(conv.lastMessageAt || conv.createdAt).toLocaleTimeString(
                  "ar-EG",
                  { hour: "2-digit", minute: "2-digit" }
                );

                return (
                  <button
                    key={conv.id}
                    onClick={() => selectConversation(conv.id)}
                    className={`w-full p-3.5 text-right flex items-center gap-3 transition-colors cursor-pointer group ${
                      isSelected
                        ? "bg-[#202020] border-r-4 border-r-[#D4AF37]"
                        : "hover:bg-[#1A1A1A]"
                    }`}
                  >
                    {/* User Avatar */}
                    <div className="relative flex-shrink-0">
                      <div className="w-11 h-11 rounded-2xl overflow-hidden bg-[#242424] border border-white/10 flex items-center justify-center text-white font-black text-sm">
                        {isAi ? (
                          <div className="w-full h-full bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white">
                            <Bot className="w-6 h-6" />
                          </div>
                        ) : other.photoURL ? (
                          <img
                            src={other.photoURL}
                            alt={other.displayName}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <span>{other.displayName ? other.displayName[0].toUpperCase() : "U"}</span>
                        )}
                      </div>
                      {/* Online Status Dot */}
                      <span className="absolute -bottom-0.5 -left-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#141414]" />
                    </div>

                    {/* Meta */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5 truncate">
                          <h4 className={`text-xs font-black truncate ${isSelected ? "text-white" : "text-gray-200"}`}>
                            {other.displayName}
                          </h4>
                          {isAi ? (
                            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              AI
                            </span>
                          ) : isInstructor ? (
                            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                              {isAr ? "مدرس" : "Tutor"}
                            </span>
                          ) : isAdminUser ? (
                            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                              {isAr ? "إدارة" : "Admin"}
                            </span>
                          ) : null}
                        </div>
                        <span className="text-[10px] text-gray-500 font-mono flex-shrink-0">
                          {lastTime}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[11px] text-gray-400 truncate leading-relaxed">
                          {conv.lastSender === "student" && currentUserId === conv.senderId && (
                            <span className="text-gray-500 font-normal">{isAr ? "أنت: " : "You: "}</span>
                          )}
                          {conv.lastMessageText || (isAr ? "بدء المحادثة..." : "Started chat...")}
                        </p>
                        {unread > 0 && (
                          <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-[#D4AF37] text-black font-black text-[10px] flex items-center justify-center flex-shrink-0">
                            {unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* RIGHT / MAIN CHAT WINDOW */}
        {/* ========================================================================= */}
        <div
          className={`flex-1 flex flex-col bg-[#0E0E0E] min-w-0 transition-all duration-300 ${
            mobileActiveView === "list" ? "hidden md:flex" : "flex"
          }`}
        >
          {activeConversation && activeOtherParticipant ? (
            <>
              {/* Chat Top Header */}
              <div className="p-3.5 sm:p-4 bg-[#141414] border-b border-white/10 flex items-center justify-between flex-shrink-0 z-10">
                <div className="flex items-center gap-3 min-w-0">
                  {/* Mobile Back Button */}
                  <button
                    onClick={() => setMobileActiveView("list")}
                    className="md:hidden p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition cursor-pointer"
                    title={isAr ? "الرجوع للقائمة" : "Back to list"}
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="relative flex-shrink-0">
                    <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl overflow-hidden bg-[#242424] border border-[#D4AF37]/30 flex items-center justify-center text-white font-black text-sm">
                      {activeOtherParticipant.role === "support" || activeConversation.mode === "ai" ? (
                        <div className="w-full h-full bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white">
                          <Bot className="w-6 h-6" />
                        </div>
                      ) : activeOtherParticipant.photoURL ? (
                        <img
                          src={activeOtherParticipant.photoURL}
                          alt={activeOtherParticipant.displayName}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span>{activeOtherParticipant.displayName ? activeOtherParticipant.displayName[0].toUpperCase() : "U"}</span>
                      )}
                    </div>
                    <span className="absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#141414]" />
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xs sm:text-sm font-black text-white truncate">
                        {activeOtherParticipant.displayName}
                      </h3>
                      {activeOtherParticipant.role === "admin" && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                          {isAr ? "مشرف المنصة" : "Admin"}
                        </span>
                      )}
                      {activeOtherParticipant.role === "instructor" && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                          {isAr ? "مدرس معتمد" : "Instructor"}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>{isAr ? "متصل الآن • مراسلة داخلية آمنة" : "Active now • Secure internal chat"}</span>
                    </p>
                  </div>
                </div>

                {/* Right Action Tools */}
                <div className="flex items-center gap-1 sm:gap-2">
                  <button
                    onClick={() => setShowParticipantInfo(!showParticipantInfo)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
                    title={isAr ? "معلومات المستخدم" : "User info"}
                  >
                    <Info className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Chat Messages Body */}
              <div ref={chatScrollContainerRef} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-[#0A0A0A] no-scrollbar">
                {/* Security & Independent Messenger Banner */}
                <div className="py-2 px-3 rounded-2xl bg-[#141414] border border-white/5 text-center text-[10px] text-gray-400 flex items-center justify-center gap-2 max-w-md mx-auto">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>
                    {isAr
                      ? "المحادثة مشفرة ومحمية بالكامل داخل منصة «اتعلم ببساطة»"
                      : "Messages are securely hosted on Learn Simply platform"}
                  </span>
                </div>

                {messages.map((msg, idx) => {
                  const isMe = msg.senderId === currentUserId;
                  const isAi = msg.role === "ai" || msg.senderId === "ai_bot";
                  const isAdminSender = msg.role === "admin";
                  const isInstructorSender = msg.role === "instructor";

                  const timeStr = new Date(msg.createdAt).toLocaleTimeString("ar-EG", {
                    hour: "2-digit",
                    minute: "2-digit",
                  });

                  return (
                    <div
                      key={msg.id || idx}
                      className={`flex flex-col ${isMe ? "items-start" : "items-end"}`}
                    >
                      {/* Sender Info Tag */}
                      <div className="flex items-center gap-1.5 mb-1 px-1 text-[10px] text-gray-400">
                        <span className="font-bold">
                          {isMe
                            ? (isAr ? "أنت" : "You")
                            : isAi
                            ? (isAr ? "المساعد الذكي (Gemini)" : "AI Assistant")
                            : msg.senderName || activeOtherParticipant.displayName}
                        </span>
                        <span className="text-[9px] text-gray-500 font-mono">{timeStr}</span>
                      </div>

                      {/* Bubble */}
                      <div
                        className={`max-w-[85%] sm:max-w-[70%] rounded-3xl px-4 py-3 text-xs leading-relaxed shadow-lg ${
                          isMe
                            ? "bg-[#242424] text-white border border-white/10 rounded-tr-none"
                            : isAi
                            ? "bg-gradient-to-r from-emerald-950/90 to-[#12241b] text-emerald-100 border border-emerald-500/30 rounded-tl-none"
                            : isAdminSender
                            ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-black font-semibold border border-[#D4AF37]/50 rounded-tl-none"
                            : isInstructorSender
                            ? "bg-gradient-to-r from-blue-950 to-indigo-950 text-blue-100 border border-blue-500/30 rounded-tl-none"
                            : "bg-[#181818] text-white border border-white/10 rounded-tl-none"
                        }`}
                      >
                        {/* Image Attachment */}
                        {msg.attachmentUrl && (
                          <div className="mb-2.5 rounded-2xl overflow-hidden border border-white/10 bg-black max-w-sm">
                            <img
                              src={msg.attachmentUrl}
                              alt="Attachment"
                              referrerPolicy="no-referrer"
                              className="w-full max-h-60 object-contain"
                            />
                          </div>
                        )}

                        <p className="whitespace-pre-wrap">{msg.text}</p>

                        {/* Status Checkmark */}
                        <div className="flex items-center justify-end gap-1 mt-1 text-[9px] text-gray-400">
                          {msg.status === "sending" && <Clock className="w-2.5 h-2.5 animate-spin" />}
                          {msg.status === "delivered" && <Check className="w-3 h-3 text-gray-400" />}
                          {msg.status === "read" && <CheckCheck className="w-3.5 h-3.5 text-[#D4AF37]" />}
                          {msg.status === "failed" && (
                            <span className="text-red-400 font-bold">{isAr ? "فشل الإرسال" : "Failed"}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {isSending && (
                  <div className="flex items-center gap-2 text-xs text-gray-400 py-1">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
                    <span>{isAr ? "جاري إرسال الرسالة ومعالجتها..." : "Sending message..."}</span>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input & Attachment Area */}
              <div className="p-3 sm:p-4 bg-[#141414] border-t border-white/10 flex-shrink-0 space-y-2">
                {/* Permission Warning / Block Banner */}
                {permissionError && (
                  <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0 animate-ping" />
                      <span>{permissionError}</span>
                    </div>
                    <button
                      onClick={() => setPermissionError(null)}
                      className="text-gray-400 hover:text-white text-xs font-bold"
                    >
                      ✕
                    </button>
                  </div>
                )}

                {/* Selected Attachment Preview */}
                {selectedAttachment && (
                  <div className="flex items-center justify-between p-2 rounded-2xl bg-[#202020] border border-white/10 text-xs">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
                      <span className="text-white truncate max-w-xs">{selectedAttachment.name}</span>
                    </div>
                    <button
                      onClick={() => setSelectedAttachment(null)}
                      className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Main Input Row */}
                <div className="flex items-end gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/*,.pdf,.doc,.docx"
                    className="hidden"
                  />

                  {/* Attachment Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingAttachment}
                    className="p-3 rounded-2xl bg-[#1E1E1E] hover:bg-[#282828] text-gray-400 hover:text-[#D4AF37] border border-white/10 transition cursor-pointer flex-shrink-0"
                    title={isAr ? "إرفاق صورة أو مستند" : "Attach image/file"}
                  >
                    <Paperclip className="w-4 h-4" />
                  </button>

                  {/* Textarea Input */}
                  <div className="flex-1 relative">
                    <textarea
                      rows={1}
                      placeholder={isAr ? "اكتب رسالتك هنا... (اضغط Enter للإرسال)" : "Type your message here..."}
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      className="w-full px-4 py-3 rounded-2xl bg-[#1D1D1D] border border-white/10 text-white placeholder-gray-500 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37] transition resize-none max-h-28"
                    />
                  </div>

                  {/* Send Button */}
                  <button
                    onClick={handleSendMessage}
                    disabled={(!inputText.trim() && !selectedAttachment) || isSending}
                    className="p-3 rounded-2xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-[#D4AF37]/20 flex-shrink-0"
                    title={isAr ? "إرسال الرسالة" : "Send"}
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* Empty State: No active conversation selected */
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/5 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shadow-xl">
                <MessageSquare className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-black text-white">
                  {isAr ? "اختر محادثة للبدء أو ابحث عن مستخدم" : "Select a conversation or find a user"}
                </h3>
                <p className="text-xs text-gray-400 max-w-sm">
                  {isAr
                    ? "يمكنك التواصل فوراً مع المدرسين، الطلاب، إدارة المنصة، أو سؤال المساعد الذكي"
                    : "Directly chat with tutors, students, admins, or get instant AI support"}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsNewChatModalOpen(true);
                  handleSearchUsers("");
                }}
                className="px-5 py-2.5 rounded-2xl bg-[#D4AF37] text-black font-bold text-xs sm:text-sm hover:scale-105 transition"
              >
                {isAr ? "بدء محادثة جديدة الآن" : "Start New Chat"}
              </button>
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* OPTIONAL USER DETAILS DRAWER (DESKTOP) */}
        {/* ========================================================================= */}
        {showParticipantInfo && activeOtherParticipant && (
          <div className="hidden lg:flex w-72 bg-[#141414] border-r border-white/10 p-5 flex-col space-y-5 animate-in slide-in-from-left duration-200">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-white">{isAr ? "الملف التعريفي" : "User Profile"}</h4>
              <button
                onClick={() => setShowParticipantInfo(false)}
                className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center space-y-2">
              <div className="w-20 h-20 rounded-3xl overflow-hidden mx-auto bg-[#242424] border-2 border-[#D4AF37]/40 flex items-center justify-center text-white font-black text-xl shadow-lg">
                {activeOtherParticipant.photoURL ? (
                  <img
                    src={activeOtherParticipant.photoURL}
                    alt={activeOtherParticipant.displayName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>{activeOtherParticipant.displayName[0]}</span>
                )}
              </div>
              <h3 className="text-sm font-black text-white">{activeOtherParticipant.displayName}</h3>
              <p className="text-xs text-[#D4AF37] font-bold">
                {activeOtherParticipant.role === "admin"
                  ? (isAr ? "مشرف عام" : "Admin")
                  : activeOtherParticipant.role === "instructor"
                  ? (isAr ? "مدرس معتمد" : "Instructor")
                  : activeOtherParticipant.role === "support"
                  ? (isAr ? "المساعد الذكي" : "AI Support")
                  : (isAr ? "طالب مسجل" : "Student")}
              </p>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-2.5 text-xs text-gray-300">
              <div className="flex items-center justify-between">
                <span className="text-gray-500">{isAr ? "حالة الاتصال" : "Status"}</span>
                <span className="text-emerald-400 font-bold">{isAr ? "متصل الآن" : "Online"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">{isAr ? "نوع المحادثة" : "Chat Type"}</span>
                <span className="text-white font-semibold">{isAr ? "مباشرة ومشفرة" : "Direct & Secure"}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* NEW CHAT / USER SEARCH MODAL */}
      {/* ========================================================================= */}
      {isNewChatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-[#141414] border border-[#D4AF37]/40 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                  <Search className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-white">
                  {isAr ? "بدء محادثة مع مستخدم" : "Start Chat with User"}
                </h3>
              </div>
              <button
                onClick={() => setIsNewChatModalOpen(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Input Box */}
            <div className="relative">
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={isAr ? "ابحث بالاسم، المسمى الوظيفي، أو الرقم..." : "Search by name or role..."}
                value={userSearchTerm}
                onChange={(e) => handleSearchUsers(e.target.value)}
                autoFocus
                className="w-full pl-3 pr-10 py-3 rounded-2xl bg-[#1E1E1E] border border-white/10 text-white placeholder-gray-500 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37] transition"
              />
            </div>

            {/* Results List */}
            <div className="max-h-72 overflow-y-auto space-y-2 divide-y divide-white/5 no-scrollbar">
              {isSearchingUsers ? (
                <div className="p-8 text-center text-xs text-gray-400 flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#D4AF37]" />
                  <span>{isAr ? "جاري البحث..." : "Searching..."}</span>
                </div>
              ) : searchResults.length === 0 ? (
                <div className="p-8 text-center text-xs text-gray-500">
                  {isAr ? "لا يوجد مستخدمين يطابقون هذا البحث" : "No users matched your query"}
                </div>
              ) : (
                searchResults.map((u) => (
                  <div
                    key={u.uid}
                    onClick={() => startChatWithUser(u)}
                    className="p-3 rounded-2xl hover:bg-[#1F1F1F] transition flex items-center justify-between cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-[#242424] border border-white/10 overflow-hidden flex items-center justify-center text-white font-bold text-xs">
                        {u.uid === "ai_bot" ? (
                          <div className="w-full h-full bg-emerald-700 flex items-center justify-center">
                            <Bot className="w-5 h-5" />
                          </div>
                        ) : u.photoURL ? (
                          <img
                            src={u.photoURL}
                            alt={u.displayName}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <span>{u.displayName[0]}</span>
                        )}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white group-hover:text-[#D4AF37] transition">
                          {u.displayName}
                        </h4>
                        <span className="text-[10px] text-gray-400">
                          {u.role === "admin"
                            ? (isAr ? "مشرف المنصة" : "Admin")
                            : u.role === "instructor"
                            ? (isAr ? "مدرس" : "Instructor")
                            : u.role === "support"
                            ? (isAr ? "ذكاء اصطناعي" : "AI Support")
                            : (isAr ? "طالب" : "Student")}
                        </span>
                      </div>
                    </div>

                    <button className="px-3 py-1.5 rounded-xl bg-[#D4AF37]/15 text-[#D4AF37] text-xs font-bold border border-[#D4AF37]/30 group-hover:bg-[#D4AF37] group-hover:text-black transition">
                      {isAr ? "مراسلة" : "Chat"}
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
