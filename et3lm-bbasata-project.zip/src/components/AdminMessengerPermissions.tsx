import React, { useState, useEffect } from "react";
import {
  Shield,
  Users,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Unlock,
  Search,
  Save,
  RefreshCw,
  Sliders,
  Paperclip,
  UserX,
  UserCheck,
  Info,
  Layers,
  ArrowRight,
  Sparkles,
  Ban,
} from "lucide-react";
import { MessengerPermissionsConfig, UserMessengerPermissions, MessengerUserSummary } from "../types";

export const AdminMessengerPermissions: React.FC = () => {
  // Global permissions state
  const [permissions, setPermissions] = useState<MessengerPermissionsConfig>({
    globalMessengerEnabled: true,
    studentToStudentEnabled: true,
    studentToAdminEnabled: true,
    studentToInstructorEnabled: true,
    instructorToStudentEnabled: true,
    instructorToInstructorEnabled: true,
    allowAttachments: true,
    maxAttachmentSizeBytes: 10 * 1024 * 1024,
    updatedAt: new Date().toISOString(),
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // User search & individual permissions state
  const [userSearchTerm, setUserSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<MessengerUserSummary[]>([]);
  const [searchingUsers, setSearchingUsers] = useState(false);
  const [selectedUser, setSelectedUser] = useState<MessengerUserSummary | null>(null);
  const [selectedUserPerms, setSelectedUserPerms] = useState<UserMessengerPermissions | null>(null);
  const [savingUserPerms, setSavingUserPerms] = useState(false);
  const [userPermsSavedMsg, setUserPermsSavedMsg] = useState(false);

  // Fetch global permissions
  const fetchGlobalPermissions = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/messenger/permissions");
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.permissions) {
          setPermissions(data.permissions);
        }
      }
    } catch (err) {
      console.error("Error fetching messenger permissions:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGlobalPermissions();
  }, []);

  // Save global permissions
  const handleSaveGlobalPermissions = async () => {
    try {
      setSaving(true);
      setSaveError(null);
      const res = await fetch("/api/messenger/permissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(permissions),
      });

      if (res.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3500);
      } else {
        setSaveError("حدث خطأ أثناء حفظ الإعدادات");
      }
    } catch (err) {
      console.error("Error saving permissions:", err);
      setSaveError("فشل الاتصال بالخادم لحفظ الصلاحيات");
    } finally {
      setSaving(false);
    }
  };

  // Search users for individual overrides
  const handleSearchUsers = async (query: string) => {
    setUserSearchTerm(query);
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      setSearchingUsers(true);
      const res = await fetch(`/api/messenger/users?search=${encodeURIComponent(query.trim())}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.users)) {
          setSearchResults(data.users);
        }
      }
    } catch (err) {
      console.error("Error searching users:", err);
    } finally {
      setSearchingUsers(false);
    }
  };

  // Load individual user permissions
  const handleSelectUser = async (user: MessengerUserSummary) => {
    setSelectedUser(user);
    setUserPermsSavedMsg(false);
    const userId = user.uid || user.id || "";
    try {
      const res = await fetch(`/api/messenger/user-permissions/${encodeURIComponent(userId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.permissions) {
          setSelectedUserPerms(data.permissions);
        }
      }
    } catch (err) {
      console.error("Error loading user permissions:", err);
    }
  };

  // Save individual user permissions
  const handleSaveUserPermissions = async () => {
    if (!selectedUser || !selectedUserPerms) return;
    const userId = selectedUser.uid || selectedUser.id || "";
    try {
      setSavingUserPerms(true);
      const res = await fetch(`/api/messenger/user-permissions/${encodeURIComponent(userId)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(selectedUserPerms),
      });

      if (res.ok) {
        setUserPermsSavedMsg(true);
        setTimeout(() => setUserPermsSavedMsg(false), 3500);
      }
    } catch (err) {
      console.error("Error saving user permissions:", err);
    } finally {
      setSavingUserPerms(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-[#181818] via-[#141414] to-[#1C1808] border border-[#D4AF37]/30 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shadow">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <span>إدارة صلاحيات وتراخيص المراسلة الداخلية</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                تحكم كامل
              </span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              تحكم كامل في تفعيل وتعطيل المراسلة للمنصة بأكملها، مصفوفة صلاحيات الأدوار، واستثناءات المستخدمين الفردية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <button
            onClick={fetchGlobalPermissions}
            disabled={loading}
            className="p-2.5 rounded-xl bg-[#202020] hover:bg-[#2A2A2A] text-gray-300 hover:text-white border border-white/10 transition cursor-pointer"
            title="تحديث البيانات"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin text-[#D4AF37]" : ""}`} />
          </button>

          <button
            onClick={handleSaveGlobalPermissions}
            disabled={saving}
            className="flex-1 md:flex-none px-5 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-lg shadow-[#D4AF37]/20 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? "جاري الحفظ..." : "حفظ التغييرات"}</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-400" />
          <span>تم حفظ وتطبيق جميع إعدادات الصلاحيات بنجاح على المنصة بأكملها.</span>
        </div>
      )}

      {saveError && (
        <div className="p-4 rounded-2xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs sm:text-sm flex items-center gap-2 animate-in fade-in">
          <AlertTriangle className="w-5 h-5 flex-shrink-0 text-red-400" />
          <span>{saveError}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* SECTION 1: GLOBAL MASTER & ROLE MATRIX (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Master Global Switch */}
          <div className="p-5 rounded-3xl bg-[#141414] border border-white/10 shadow-lg space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${permissions.globalMessengerEnabled ? "bg-emerald-950/80 text-emerald-400 border border-emerald-500/30" : "bg-red-950/80 text-red-400 border border-red-500/30"}`}>
                  {permissions.globalMessengerEnabled ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">المفتاح الرئيسي لنظام المراسلة (Master Switch)</h4>
                  <p className="text-[11px] text-gray-400">
                    {permissions.globalMessengerEnabled ? "النظام مفعّل ومتاح لجميع الحسابات المصرح لها" : "النظام معطل بالكامل لجميع المستخدمين"}
                  </p>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.globalMessengerEnabled}
                  onChange={(e) => setPermissions({ ...permissions, globalMessengerEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-13 h-7 bg-[#252525] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-emerald-500"></div>
              </label>
            </div>

            {/* Attachments Permission */}
            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#1E1E1E] text-[#D4AF37] border border-white/10 flex items-center justify-center">
                  <Paperclip className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="text-xs font-bold text-white">السماح برفع وإرسال المرفقات والصور</h5>
                  <p className="text-[10px] text-gray-400">إمكانية إرفاق الصور والمستندات داخل شاشة المحادثة</p>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.allowAttachments}
                  onChange={(e) => setPermissions({ ...permissions, allowAttachments: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#252525] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D4AF37]"></div>
              </label>
            </div>
          </div>

          {/* Role-to-Role Matrix */}
          <div className="p-5 rounded-3xl bg-[#141414] border border-white/10 shadow-lg space-y-4">
            <div className="flex items-center gap-2.5 border-b border-white/5 pb-3">
              <Layers className="w-5 h-5 text-[#D4AF37]" />
              <h4 className="text-sm font-black text-white">مصفوفة صلاحيات المراسلة بين الأدوار (Role Matrix)</h4>
            </div>

            <div className="space-y-3">
              {/* Student to Admin */}
              <div className="p-3.5 rounded-2xl bg-[#1A1A1A] border border-white/5 flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-400" />
                    <span>مراسلة الطلاب للإدارة والمشرفين (Student → Admin)</span>
                  </h5>
                  <p className="text-[10px] text-gray-400 mt-0.5">السماح للطلاب بفتح تذاكر ومحادثات مع فريق الإدارة</p>
                </div>
                <input
                  type="checkbox"
                  checked={permissions.studentToAdminEnabled}
                  onChange={(e) => setPermissions({ ...permissions, studentToAdminEnabled: e.target.checked })}
                  className="w-5 h-5 accent-[#D4AF37] rounded cursor-pointer"
                />
              </div>

              {/* Student to Instructor */}
              <div className="p-3.5 rounded-2xl bg-[#1A1A1A] border border-white/5 flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>مراسلة الطلاب للمحاضرين (Student → Instructor)</span>
                  </h5>
                  <p className="text-[10px] text-gray-400 mt-0.5">السماح للطلاب بطرح استفسارات برمجية على محاضري الكورسات</p>
                </div>
                <input
                  type="checkbox"
                  checked={permissions.studentToInstructorEnabled}
                  onChange={(e) => setPermissions({ ...permissions, studentToInstructorEnabled: e.target.checked })}
                  className="w-5 h-5 accent-[#D4AF37] rounded cursor-pointer"
                />
              </div>

              {/* Instructor to Student */}
              <div className="p-3.5 rounded-2xl bg-[#1A1A1A] border border-white/5 flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span>مراسلة المحاضرين للطلاب (Instructor → Student)</span>
                  </h5>
                  <p className="text-[10px] text-gray-400 mt-0.5">السماح للمحاضرين بالرد ومتابعة الطلاب داخل المحادثات</p>
                </div>
                <input
                  type="checkbox"
                  checked={permissions.instructorToStudentEnabled}
                  onChange={(e) => setPermissions({ ...permissions, instructorToStudentEnabled: e.target.checked })}
                  className="w-5 h-5 accent-[#D4AF37] rounded cursor-pointer"
                />
              </div>

              {/* Student to Student */}
              <div className="p-3.5 rounded-2xl bg-[#1A1A1A] border border-white/5 flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-purple-400" />
                    <span>المراسلة بين الطلاب وبعضهم (Student ↔ Student)</span>
                  </h5>
                  <p className="text-[10px] text-gray-400 mt-0.5">إتاحة التعارف والمناقشات البرمجية المباشرة بين الزملاء</p>
                </div>
                <input
                  type="checkbox"
                  checked={permissions.studentToStudentEnabled}
                  onChange={(e) => setPermissions({ ...permissions, studentToStudentEnabled: e.target.checked })}
                  className="w-5 h-5 accent-[#D4AF37] rounded cursor-pointer"
                />
              </div>

              {/* Instructor to Instructor */}
              <div className="p-3.5 rounded-2xl bg-[#1A1A1A] border border-white/5 flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    <span>المراسلة بين المحاضرين وزملائهم (Instructor ↔ Instructor)</span>
                  </h5>
                  <p className="text-[10px] text-gray-400 mt-0.5">تنسيق المناهج والواجبات بين المدرسين داخل المنصة</p>
                </div>
                <input
                  type="checkbox"
                  checked={permissions.instructorToInstructorEnabled}
                  onChange={(e) => setPermissions({ ...permissions, instructorToInstructorEnabled: e.target.checked })}
                  className="w-5 h-5 accent-[#D4AF37] rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2: INDIVIDUAL USER PERMISSION OVERRIDES (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="p-5 rounded-3xl bg-[#141414] border border-white/10 shadow-lg space-y-4">
            <div className="flex items-center gap-2.5 border-b border-white/5 pb-3">
              <Users className="w-5 h-5 text-[#D4AF37]" />
              <h4 className="text-sm font-black text-white">التحكم في مستخدم محدد (User Overrides)</h4>
            </div>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                placeholder="ابحث عن طالب أو محاضر بالاسم أو البريد..."
                value={userSearchTerm}
                onChange={(e) => handleSearchUsers(e.target.value)}
                className="w-full pl-4 pr-10 py-2.5 rounded-xl bg-[#1D1D1D] border border-white/10 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
            </div>

            {/* Search Results Dropdown List */}
            {searchResults.length > 0 && (
              <div className="max-h-48 overflow-y-auto space-y-1.5 p-1 rounded-2xl bg-[#181818] border border-white/10 no-scrollbar">
                {searchResults.map((usr) => {
                  const uid = usr.uid || usr.id || "";
                  const isSelected = (selectedUser?.uid || selectedUser?.id) === uid;
                  return (
                    <button
                      key={uid}
                      onClick={() => handleSelectUser(usr)}
                      className={`w-full p-2.5 rounded-xl flex items-center justify-between text-right transition cursor-pointer ${
                        isSelected ? "bg-[#D4AF37]/20 border border-[#D4AF37]/40" : "bg-[#202020] hover:bg-[#282828]"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-700 to-yellow-900 flex items-center justify-center text-white text-xs font-bold">
                          {usr.displayName?.charAt(0) || "U"}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">{usr.displayName}</p>
                          <p className="text-[9px] text-gray-400 font-mono">{usr.email || uid}</p>
                        </div>
                      </div>

                      <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-white/5 text-gray-300">
                        {usr.role === "instructor" ? "محاضر" : usr.role === "admin" ? "أدمن" : "طالب"}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Selected User Editor Box */}
            {selectedUser && selectedUserPerms ? (
              <div className="p-4 rounded-2xl bg-[#181818] border border-[#D4AF37]/30 space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center font-bold text-sm">
                      {selectedUser.displayName.charAt(0)}
                    </div>
                    <div>
                      <h5 className="text-xs font-black text-white">{selectedUser.displayName}</h5>
                      <p className="text-[10px] text-gray-400 font-mono">{selectedUser.uid || selectedUser.id}</p>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    selectedUserPerms.messengerAccess ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-red-500/20 text-red-400 border border-red-500/30"
                  }`}>
                    {selectedUserPerms.messengerAccess ? "مصرح له" : "محظور من المراسلة"}
                  </span>
                </div>

                {/* Individual Toggles */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#222222]">
                    <span className="text-xs font-semibold text-white">إتاحة استخدام الماسنجر</span>
                    <input
                      type="checkbox"
                      checked={selectedUserPerms.messengerAccess}
                      onChange={(e) => setSelectedUserPerms({ ...selectedUserPerms, messengerAccess: e.target.checked })}
                      className="w-4 h-4 accent-[#D4AF37] rounded cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#222222]">
                    <span className="text-xs font-semibold text-white">السماح بإرسال الرسائل (Can Send)</span>
                    <input
                      type="checkbox"
                      checked={selectedUserPerms.canSend}
                      onChange={(e) => setSelectedUserPerms({ ...selectedUserPerms, canSend: e.target.checked })}
                      className="w-4 h-4 accent-[#D4AF37] rounded cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#222222]">
                    <span className="text-xs font-semibold text-white">السماح باستقبال الرسائل (Can Receive)</span>
                    <input
                      type="checkbox"
                      checked={selectedUserPerms.canReceive}
                      onChange={(e) => setSelectedUserPerms({ ...selectedUserPerms, canReceive: e.target.checked })}
                      className="w-4 h-4 accent-[#D4AF37] rounded cursor-pointer"
                    />
                  </div>
                </div>

                {/* Admin Note for User */}
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 mb-1">ملاحظة إدارية بخصوص هذا الحساب:</label>
                  <input
                    type="text"
                    placeholder="مثال: تم إيقاف المراسلة مؤقتاً بسبب مخالفة قواعد المنصة..."
                    value={selectedUserPerms.customNote || ""}
                    onChange={(e) => setSelectedUserPerms({ ...selectedUserPerms, customNote: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#222222] border border-white/10 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                {/* Save User Permissions Button */}
                <button
                  onClick={handleSaveUserPermissions}
                  disabled={savingUserPerms}
                  className="w-full py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{savingUserPerms ? "جاري حفظ التعديل..." : "حفظ صلاحيات المستخدم"}</span>
                </button>

                {userPermsSavedMsg && (
                  <p className="text-center text-[10px] text-emerald-400 font-bold flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تم تحديث صلاحيات الحساب بنجاح</span>
                  </p>
                )}
              </div>
            ) : (
              <div className="p-6 rounded-2xl bg-[#181818] border border-dashed border-white/10 text-center space-y-2">
                <Info className="w-6 h-6 text-gray-500 mx-auto" />
                <p className="text-xs text-gray-400">ابحث عن مستخدم وحدده لتخصيص صلاحياته الفردية وحظر/إتاحة المراسلة له.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
