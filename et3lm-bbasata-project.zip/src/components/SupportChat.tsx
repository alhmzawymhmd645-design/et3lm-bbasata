import React, { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import {
  LifeBuoy,
  Send,
  Bot,
  User,
  ShieldCheck,
  Clock,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  Sparkles,
  HelpCircle,
  CreditCard,
  BookOpen,
  Settings,
  MessageSquare,
  RefreshCw,
  Zap,
  Mail,
  Paperclip,
  Image as ImageIcon,
  X,
  ArrowRight,
  Eye,
  CheckCircle,
  Lock,
} from "lucide-react";
import { TicketCategory, TicketStatus, SupportTicket } from "../types";

const CATEGORIES: { id: TicketCategory; label: string; icon: any; desc: string }[] = [
  {
    id: "payment",
    label: "مشكلة في الدفع والاشتراك (Etisalat Cash)",
    icon: CreditCard,
    desc: "استفسارات المحافظ، تأكيد الإيصالات وتفعيل الكورسات",
  },
  {
    id: "courses",
    label: "مشكلة في الكورسات والمحتوى والشهادات",
    icon: BookOpen,
    desc: "المناهج، مشغل الفيديو، والشهادات المعتمدة",
  },
  {
    id: "account",
    label: "مشكلة في الحساب وتسجيل الدخول",
    icon: User,
    desc: "تعديل البيانات، استرجاع الحساب أو كلمة المرور",
  },
  {
    id: "technical",
    label: "مشكلة تقنية بالموقع",
    icon: Settings,
    desc: "أخطاء في المتصفح أو مشغل الدروس التفاعلية",
  },
  {
    id: "general",
    label: "استفسارات عامة أخرى",
    icon: HelpCircle,
    desc: "أي سؤال أو اقتراح لمنصة اتعلم ببساطة",
  },
];

interface SupportCategoryOption {
  id: string;
  label: string;
  emoji: string;
  icon: string;
  cat: TicketCategory;
  questions: string[];
}

const SUPPORT_CATEGORIES: SupportCategoryOption[] = [
  {
    id: "courses",
    label: "الكورسات والدروس",
    emoji: "📚✨",
    icon: "📚✨",
    cat: "courses",
    questions: [
      "🎓▶️ مشكلة في مشاهدة الدورة",
      "📚🔎 أين أجد دوراتي؟",
      "▶️🎬 الفيديو لا يعمل",
    ],
  },
  {
    id: "payment",
    label: "المحفظة والدفع",
    emoji: "💳💰",
    icon: "💳💰",
    cat: "payment",
    questions: [
      "💰✨ كيف أشحن المحفظة؟",
      "💳🔎 مشكلة في الدفع",
      "💸📤 مشكلة في السحب",
    ],
  },
  {
    id: "account",
    label: "الحساب وتسجيل الدخول",
    emoji: "🔐👤",
    icon: "🔐👤",
    cat: "account",
    questions: [
      "🔑🔒 نسيت كلمة المرور",
      "👤🚪 مشكلة في تسجيل الدخول",
      "📧⚠️ مشكلة في البريد الإلكتروني",
    ],
  },
  {
    id: "technical",
    label: "مشكلة تقنية",
    emoji: "🛠️⚡",
    icon: "🛠️⚡",
    cat: "technical",
    questions: [
      "⚙️🔧 الموقع لا يعمل بشكل صحيح",
      "🐛🔎 وجدت خطأ في الموقع",
      "📱💻 مشكلة في الهاتف أو المتصفح",
    ],
  },
];

const GMAIL_COMPOSE_URL = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent("alhmzawymhmd645@gmail.com")}&su=${encodeURIComponent("طلب دعم - منصة اتعلم ببساطة")}&body=${encodeURIComponent("مرحبًا فريق دعم منصة اتعلم ببساطة 👋\n\nأحتاج إلى المساعدة بخصوص:\n[اكتب مشكلتك هنا]\n\nشكرًا لكم ❤️")}`;

export const SupportChat: React.FC = () => {
  const {
    user,
    settings,
    myTickets,
    createSupportTicket,
    sendTicketMessage,
    closeTicket,
    setIsAuthModalOpen,
  } = useApp();

  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [selectedSection, setSelectedSection] = useState<string | null>("courses");
  const [selectedQuestion, setSelectedQuestion] = useState<string | null>(null);
  const [isRequestPrepared, setIsRequestPrepared] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<TicketCategory>("courses");
  const [subject, setSubject] = useState("");
  const [initialMessage, setInitialMessage] = useState("");
  const [ticketAttachment, setTicketAttachment] = useState<string | null>(null);
  const [ticketAttachmentName, setTicketAttachmentName] = useState<string>("");

  const [replyMessage, setReplyMessage] = useState("");
  const [replyAttachment, setReplyAttachment] = useState<string | null>(null);
  const [replyAttachmentName, setReplyAttachmentName] = useState<string>("");

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const subjectInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const replyFileInputRef = useRef<HTMLInputElement>(null);
  const createFormRef = useRef<HTMLDivElement>(null);

  // Auto-select latest ticket if available and none selected
  useEffect(() => {
    if (myTickets.length > 0 && !activeTicketId && !isCreatingNew) {
      setActiveTicketId(myTickets[0].id);
    }
  }, [myTickets, activeTicketId, isCreatingNew]);

  const activeTicket = myTickets.find((t) => t.id === activeTicketId);

  // Scroll to bottom of message thread
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeTicket?.messages, isSendingReply]);

  const handleStartFirstTicket = () => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    setIsCreatingNew(true);
    setActiveTicketId(null);
    setSelectedSection("courses");
    setSelectedQuestion(null);
    setTimeout(() => {
      createFormRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      subjectInputRef.current?.focus();
    }, 100);
  };

  const handleToggleSection = (secId: string, cat: TicketCategory) => {
    setSelectedSection((prev) => (prev === secId ? null : secId));
    setSelectedCategory(cat);
  };

  const handleSelectPresetQuestion = (question: string, cat: TicketCategory) => {
    setSelectedCategory(cat);
    setSelectedQuestion(question);
    setSubject(question);
    setInitialMessage(question);
    setErrorMsg("");
    setTimeout(() => {
      const msgInput = document.getElementById("input-ticket-message") as HTMLTextAreaElement | null;
      if (msgInput) {
        msgInput.focus();
        msgInput.setSelectionRange(msgInput.value.length, msgInput.value.length);
      }
    }, 50);
  };

  const handleSelectThreadPresetQuestion = (question: string) => {
    setSelectedQuestion(question);
    setReplyMessage(question);
    setTimeout(() => {
      const replyInput = document.getElementById("input-reply-message") as HTMLInputElement | null;
      if (replyInput) {
        replyInput.focus();
        replyInput.setSelectionRange(replyInput.value.length, replyInput.value.length);
      }
    }, 50);
  };

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "ticket" | "reply"
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setErrorMsg("حجم الملف كبير جداً، الحد الأقصى 5 ميجابايت.");
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (type === "ticket") {
          setTicketAttachment(reader.result as string);
          setTicketAttachmentName(file.name);
        } else {
          setReplyAttachment(reader.result as string);
          setReplyAttachmentName(file.name);
        }
        setErrorMsg("");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    if (!subject.trim()) {
      setErrorMsg("يرجى إدخال عنوان المشكلة أو الاستفسار.");
      subjectInputRef.current?.focus();
      return;
    }
    if (!initialMessage.trim()) {
      setErrorMsg("يرجى كتابة تفاصيل ووصف المشكلة.");
      return;
    }

    setIsSubmitting(true);
    setErrorMsg("");
    try {
      const ticketId = await createSupportTicket(
        selectedCategory,
        subject.trim(),
        initialMessage.trim(),
        ticketAttachment || undefined
      );
      setSubject("");
      setInitialMessage("");
      setTicketAttachment(null);
      setTicketAttachmentName("");
      setIsCreatingNew(false);
      setActiveTicketId(ticketId);
    } catch (err: any) {
      setErrorMsg(err.message || "حدث خطأ أثناء إرسال التذكرة.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTicket || (!replyMessage.trim() && !replyAttachment)) return;

    const msg = replyMessage;
    const att = replyAttachment;
    setReplyMessage("");
    setReplyAttachment(null);
    setReplyAttachmentName("");
    setIsSendingReply(true);
    try {
      await sendTicketMessage(activeTicket.id, msg, att || undefined);
    } catch (err) {
      console.error("Error sending reply:", err);
    } finally {
      setIsSendingReply(false);
    }
  };

  const handleCloseTicket = async () => {
    if (!activeTicket) return;
    try {
      await closeTicket(activeTicket.id);
    } catch (e) {
      console.error("Failed to close ticket:", e);
    }
  };

  const getStatusBadge = (status: TicketStatus, needsAdmin: boolean) => {
    if (status === "closed") {
      return (
        <span
          id="badge-status-closed"
          className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-gray-800 text-gray-400 border border-gray-700"
        >
          <Lock className="w-3 h-3" />
          مغلقة
        </span>
      );
    }
    if (status === "resolved") {
      return (
        <span
          id="badge-status-resolved"
          className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/40"
        >
          <CheckCircle2 className="w-3 h-3" />
          تم الحل
        </span>
      );
    }
    if (needsAdmin || status === "needs_admin") {
      return (
        <span
          id="badge-status-needs-admin"
          className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/40 animate-pulse"
        >
          <AlertCircle className="w-3 h-3" />
          تحتاج متابعة الإدارة
        </span>
      );
    }
    if (status === "in_progress") {
      return (
        <span
          id="badge-status-inprogress"
          className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/15 text-blue-300 border border-blue-500/40"
        >
          <Clock className="w-3 h-3" />
          قيد المراجعة
        </span>
      );
    }
    return (
      <span
        id="badge-status-open"
        className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40"
      >
        <Bot className="w-3 h-3" />
        مفتوحة
      </span>
    );
  };

  const getCategoryLabel = (cat: TicketCategory) => {
    return CATEGORIES.find((c) => c.id === cat)?.label || cat;
  };

  const supportEmail = settings.contactEmail || "alhmzawymhmd645@gmail.com";

  return (
    <div className="min-h-[85vh] bg-[#0A0A0A] text-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Header Card */}
        <div
          id="support-header-card"
          className="relative overflow-hidden bg-[#151515] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl"
        >
          <div className="absolute top-0 left-0 -translate-x-12 -translate-y-12 w-64 h-64 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                دعم فني وتذاكر مساعدة 24/7
              </div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
                <LifeBuoy className="w-8 h-8 text-[#D4AF37]" />
                تواصل معنا والدعم الفني
              </h1>
              <p className="text-gray-400 text-sm sm:text-base max-w-2xl leading-relaxed">
                أنشئ تذكرة دعم جديدة وسيتولى فريق الدعم الفني والمساعد الذكي الرد عليك ومتابعة حالتها حتى حل مشكلتك بالكامل.
              </p>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <a
                id="btn-support-gmail-compose-top"
                href={GMAIL_COMPOSE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] border border-[#D4AF37]/40 hover:border-[#D4AF37] text-[#D4AF37] hover:text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
                title="فتح Gmail لإنشاء رسالة جديدة للدعم"
              >
                <Mail className="w-4 h-4 text-[#D4AF37]" />
                <span>✉️ التواصل عبر البريد الإلكتروني</span>
              </a>

              <button
                id="btn-new-ticket-main"
                onClick={handleStartFirstTicket}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white font-bold text-sm shadow-lg shadow-[#D4AF37]/20 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                إنشاء تذكرة دعم جديدة
              </button>
            </div>
          </div>
        </div>

        {/* Not Logged In Prompt */}
        {!user && (
          <div
            id="support-auth-notice"
            className="p-6 rounded-2xl bg-[#151515] border border-[#D4AF37]/30 text-gray-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl"
          >
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-[#D4AF37] shrink-0" />
              <p className="text-sm">
                يرجى تسجيل الدخول بحسابك لتتمكن من إنشاء تذاكر الدعم وحفظ سجل محادثاتك مع المساعد وفريق الدعم.
              </p>
            </div>
            <button
              id="btn-support-login"
              onClick={() => setIsAuthModalOpen(true)}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white font-bold text-sm hover:brightness-110 transition shadow-md shadow-[#D4AF37]/20 whitespace-nowrap cursor-pointer"
            >
              تسجيل الدخول الآن
            </button>
          </div>
        )}

        {/* Top Interactive Support Hub: 4 Categories + 3 Questions Each + Interactive Response & Confirmation + Gmail Button */}
        <div
          id="support-interactive-welcome-card"
          className="relative overflow-hidden p-6 sm:p-7 rounded-3xl bg-gradient-to-br from-[#1C180A] via-[#151515] to-[#0A0A0A] border border-[#D4AF37]/50 shadow-2xl space-y-6"
        >
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] text-white flex items-center justify-center shrink-0 shadow-xl shadow-[#D4AF37]/30 border border-white/20">
              <Bot className="w-7 h-7" />
            </div>
            <div className="space-y-2 text-sm text-gray-200 leading-relaxed flex-1">
              <div className="font-black text-white text-xl sm:text-2xl flex items-center gap-2">
                <span>👋 أهلاً بك في دعم «اتعلم ببساطة»</span>
              </div>
              <div className="font-bold text-[#D4AF37] text-base sm:text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#D4AF37] shrink-0 animate-pulse" />
                <span>كيف يمكننا مساعدتك اليوم؟</span>
              </div>
              <p className="text-gray-400 text-xs sm:text-sm">
                اختر أحد الأقسام أدناه لعرض الأسئلة الشائعة والبدء في حل مشكلتك فورًا، أو تواصل معنا مباشرة عبر البريد الإلكتروني.
              </p>
            </div>
          </div>

          {/* 4 Interactive Category Cards */}
          <div className="space-y-4 pt-4 border-t border-[#D4AF37]/20">
            <div className="text-xs font-bold text-gray-300 flex items-center justify-between">
              <span>الأقسام الرئيسية للدعم:</span>
              <span className="text-[11px] text-gray-400">اضغط على القسم لعرض أسئلته</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {SUPPORT_CATEGORIES.map((cat) => {
                const isSelected = selectedSection === cat.id;
                return (
                  <button
                    key={cat.id}
                    id={`btn-welcome-${cat.id}`}
                    type="button"
                    onClick={() => {
                      handleToggleSection(cat.id, cat.cat);
                      setSelectedQuestion(null);
                      setIsRequestPrepared(false);
                    }}
                    className={`p-4 rounded-2xl border text-right transition-all duration-200 flex flex-col justify-between gap-3 cursor-pointer group focus:outline-none focus:ring-2 focus:ring-[#D4AF37] active:scale-95 ${
                      isSelected
                        ? "bg-[#D4AF37]/20 border-[#D4AF37] text-white shadow-xl shadow-[#D4AF37]/15 ring-2 ring-[#D4AF37]/60 scale-[1.02]"
                        : "bg-[#0A0A0A] hover:bg-[#1A1A1A] border-[#D4AF37]/30 hover:border-[#D4AF37] text-gray-200 hover:scale-[1.01]"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-2xl filter drop-shadow">{cat.emoji}</span>
                      <span
                        className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold ${
                          isSelected
                            ? "bg-[#D4AF37] text-black"
                            : "bg-white/5 text-gray-400 group-hover:text-[#D4AF37]"
                        }`}
                      >
                        3 أسئلة
                      </span>
                    </div>
                    <span
                      className={`text-sm font-black block ${
                        isSelected ? "text-[#D4AF37]" : "text-white group-hover:text-[#D4AF37]"
                      }`}
                    >
                      {cat.emoji} {cat.label}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* 3 Preset Questions for Selected Category */}
            {selectedSection && !selectedQuestion && !isRequestPrepared && (() => {
              const activeCat = SUPPORT_CATEGORIES.find((c) => c.id === selectedSection);
              if (!activeCat) return null;
              return (
                <div className="mt-4 p-5 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/40 space-y-3 animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xs sm:text-sm font-bold text-[#D4AF37] flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-[#D4AF37]" />
                      <span>الأسئلة الجاهزة لقسم ({activeCat.emoji} {activeCat.label}):</span>
                    </span>
                    <span className="text-xs text-gray-400">اختر السؤال لعرض الرد التفاعلي</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {activeCat.questions.map((q, idx) => {
                      return (
                        <button
                          key={idx}
                          id={`btn-preset-q-${activeCat.id}-${idx}`}
                          type="button"
                          onClick={() => {
                            handleSelectPresetQuestion(q, activeCat.cat);
                            setIsRequestPrepared(false);
                          }}
                          className="p-3.5 rounded-xl border border-white/10 hover:border-[#D4AF37] bg-[#151515] hover:bg-[#1E1E1E] active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] text-gray-200 hover:text-white text-right transition-all text-xs sm:text-sm font-semibold flex items-center justify-between gap-2 cursor-pointer group shadow-sm"
                        >
                          <span className="leading-snug">{q}</span>
                          <ArrowRight
                            className="w-4 h-4 text-[#D4AF37] shrink-0 opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-transform"
                          />
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })()}

            {/* 3. Interactive Response Card after selecting a question */}
            {selectedQuestion && !isRequestPrepared && (
              <div
                id="interactive-response-card"
                className="mt-4 p-5 sm:p-6 rounded-2xl bg-[#0E0E0E] border-2 border-[#D4AF37]/60 shadow-2xl space-y-4 animate-in fade-in zoom-in-95"
              >
                <div className="flex items-center justify-between pb-3 border-b border-white/10 flex-wrap gap-2">
                  <div className="flex items-center gap-2 text-sm sm:text-base font-black text-white">
                    <span className="text-xl">🤖💬</span>
                    <span>مساعد الدعم</span>
                  </div>
                  <button
                    type="button"
                    id="btn-selected-question-badge"
                    onClick={() => {
                      setIsRequestPrepared(true);
                      if (!isCreatingNew) {
                        setIsCreatingNew(true);
                        setActiveTicketId(null);
                      }
                    }}
                    className="text-xs px-3.5 py-1.5 rounded-full bg-[#D4AF37]/20 hover:bg-[#D4AF37] border border-[#D4AF37]/50 text-[#D4AF37] hover:text-black font-bold transition-all duration-200 cursor-pointer active:scale-95 shadow-sm flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                    title="اضغط لتأكيد السؤال ومتابعة طلب الدعم"
                  >
                    <span>✓</span>
                    <span>تم تحديد السؤال بنجاح</span>
                  </button>
                </div>

                {/* Selected Question / Order */}
                <div className="p-4 rounded-xl bg-[#161616] border border-[#D4AF37]/30 space-y-1.5">
                  <div className="text-xs font-bold text-[#D4AF37] flex items-center gap-1.5">
                    <span>📌</span>
                    <span>طلبك:</span>
                  </div>
                  <div className="text-sm sm:text-base font-bold text-white pr-2 leading-relaxed">
                    {selectedQuestion}
                  </div>
                </div>

                {/* Problem Details editable textarea */}
                <div className="space-y-2">
                  <label
                    htmlFor="input-interactive-details"
                    className="text-xs sm:text-sm font-bold text-gray-200 flex items-center gap-1.5"
                  >
                    <span>📝</span>
                    <span>تفاصيل المشكلة</span>
                  </label>
                  <textarea
                    id="input-interactive-details"
                    rows={3}
                    value={initialMessage}
                    onChange={(e) => setInitialMessage(e.target.value)}
                    placeholder="اكتب هنا أي تفاصيل إضافية أو ملاحظات لمساعدتنا في معالجة طلبك بدقة..."
                    className="w-full px-4 py-3 rounded-xl bg-[#141414] border border-white/15 focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/40 text-white placeholder-gray-500 text-xs sm:text-sm outline-none transition resize-none"
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-2.5 pt-2">
                  <button
                    type="button"
                    id="btn-interactive-proceed"
                    onClick={() => {
                      setIsRequestPrepared(true);
                      if (!isCreatingNew) {
                        setIsCreatingNew(true);
                        setActiveTicketId(null);
                      }
                    }}
                    className="flex-1 min-w-[170px] py-3 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 active:scale-95 text-black font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/20 transition cursor-pointer"
                  >
                    <span>🚀</span>
                    <span>متابعة طلب الدعم</span>
                  </button>

                  <button
                    type="button"
                    id="btn-interactive-edit"
                    onClick={() => {
                      const detInput = document.getElementById("input-interactive-details") as HTMLTextAreaElement | null;
                      if (detInput) {
                        detInput.focus();
                        detInput.setSelectionRange(detInput.value.length, detInput.value.length);
                      }
                    }}
                    className="py-3 px-4 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] active:scale-95 border border-white/10 hover:border-[#D4AF37] text-gray-200 hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <span>✏️</span>
                    <span>تعديل المشكلة</span>
                  </button>

                  <button
                    type="button"
                    id="btn-interactive-change-sec"
                    onClick={() => {
                      setSelectedQuestion(null);
                      setIsRequestPrepared(false);
                    }}
                    className="py-3 px-4 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] active:scale-95 border border-white/10 hover:border-[#D4AF37] text-gray-200 hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <span>🔄</span>
                    <span>اختيار قسم آخر</span>
                  </button>
                </div>
              </div>
            )}

            {/* 4. Confirmation Message Card */}
            {isRequestPrepared && (
              <div
                id="interactive-confirmation-card"
                className="mt-4 p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-[#122416] via-[#141414] to-[#0A0A0A] border-2 border-emerald-500/50 shadow-2xl space-y-4 animate-in fade-in zoom-in-95"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/10">
                    <CheckCircle className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <div className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                      <span>✅ تم تجهيز طلب الدعم</span>
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                      <span>💙 فريق «اتعلم ببساطة» جاهز لمساعدتك.</span>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-black/50 border border-white/10 text-xs sm:text-sm text-gray-200 space-y-1">
                  <div className="flex items-center gap-2">
                    <strong className="text-[#D4AF37]">📌 الطلب: </strong>
                    <span className="font-semibold text-white">{subject || selectedQuestion}</span>
                  </div>
                  {initialMessage && initialMessage !== subject && (
                    <div className="text-gray-400 text-xs truncate">
                      <strong>📝 التفاصيل: </strong> {initialMessage}
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    type="button"
                    id="btn-interactive-followup"
                    onClick={() => {
                      if (!isCreatingNew) {
                        setIsCreatingNew(true);
                        setActiveTicketId(null);
                      }
                      setTimeout(() => {
                        createFormRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
                        const msgInput = document.getElementById("input-ticket-message") as HTMLTextAreaElement | null;
                        if (msgInput) {
                          msgInput.focus();
                        }
                      }, 50);
                    }}
                    className="flex-1 min-w-[160px] py-3 px-5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 active:scale-95 text-black font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/20 transition cursor-pointer"
                  >
                    <span>📩</span>
                    <span>متابعة الدعم</span>
                  </button>

                  <button
                    type="button"
                    id="btn-interactive-back-sections"
                    onClick={() => {
                      setSelectedQuestion(null);
                      setIsRequestPrepared(false);
                    }}
                    className="py-3 px-5 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] active:scale-95 border border-white/10 hover:border-[#D4AF37] text-gray-200 hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <span>🔄</span>
                    <span>العودة للأقسام</span>
                  </button>
                </div>
              </div>
            )}

            {/* Dedicated Gmail Button inside the interactive card */}
            <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-gray-300 flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#D4AF37]" />
                <span>تفضل مراسلتنا مباشرة عبر البريد الإلكتروني؟</span>
              </span>
              <a
                id="btn-welcome-gmail-compose"
                href={GMAIL_COMPOSE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-[#D4AF37]/50 hover:border-[#D4AF37] text-[#D4AF37] hover:text-white font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-md"
              >
                <Mail className="w-4 h-4 text-[#D4AF37]" />
                <span>✉️ التواصل عبر البريد الإلكتروني</span>
              </a>
            </div>
          </div>
        </div>

        {/* Main Grid: Sidebar + Chat Thread / Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left / Sidebar Column: My Tickets List */}
          <div
            className={`lg:col-span-4 space-y-4 ${
              (isCreatingNew || (activeTicket && activeTicketId)) ? "hidden lg:block" : "block"
            }`}
          >
            <div className="bg-[#151515] border border-white/10 rounded-2xl p-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
                  تذاكر الدعم الخاصة بي ({myTickets.length})
                </h3>
                {myTickets.length > 0 && (
                  <button
                    id="btn-create-sub-ticket"
                    onClick={handleStartFirstTicket}
                    className="text-xs text-[#D4AF37] hover:brightness-125 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    تذكرة جديدة
                  </button>
                )}
              </div>

              {myTickets.length === 0 ? (
                <div
                  id="empty-tickets-container"
                  className="py-10 px-4 text-center text-gray-400 space-y-4"
                >
                  <Bot className="w-12 h-12 mx-auto text-gray-600 animate-pulse" />
                  <p className="text-sm font-semibold text-gray-300">
                    لا توجد لديك تذاكر دعم سابقة.
                  </p>
                  <button
                    id="btn-start-first-ticket"
                    onClick={handleStartFirstTicket}
                    className="px-4 py-2 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/30 border border-[#D4AF37]/40 text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
                  >
                    <PlusCircle className="w-4 h-4" />
                    ابدأ محادثتك الأولى الآن
                  </button>
                </div>
              ) : (
                <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1 custom-scrollbar">
                  {myTickets.map((ticket) => {
                    const isSelected = activeTicketId === ticket.id && !isCreatingNew;
                    return (
                      <button
                        key={ticket.id}
                        id={`btn-ticket-${ticket.id}`}
                        onClick={() => {
                          setActiveTicketId(ticket.id);
                          setIsCreatingNew(false);
                        }}
                        className={`w-full text-right p-3.5 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? "bg-[#D4AF37]/15 border-[#D4AF37]/60 shadow-md ring-1 ring-[#D4AF37]/30"
                            : "bg-[#0A0A0A] border-white/5 hover:bg-[#1A1A1A] hover:border-white/15"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <span className="font-bold text-xs text-white truncate flex-1">
                            {ticket.subject}
                          </span>
                          <span className="text-[10px] text-gray-400 whitespace-nowrap font-mono">
                            {new Date(ticket.updatedAt || ticket.createdAt).toLocaleDateString(
                              "ar-EG",
                              { month: "short", day: "numeric" }
                            )}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-400 line-clamp-1 mb-2">
                          {ticket.lastMessageText || "لا توجد رسائل"}
                        </p>
                        <div className="flex items-center justify-between gap-1 flex-wrap">
                          <span className="text-[10px] text-gray-400 truncate max-w-[120px]">
                            {getCategoryLabel(ticket.category)}
                          </span>
                          {getStatusBadge(ticket.status, ticket.needsAdminAttention)}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Quick Support Info Box */}
            <div
              id="support-info-box"
              className="bg-[#151515] border border-white/10 rounded-2xl p-4 text-xs space-y-3 shadow-xl"
            >
              <div className="flex items-center gap-2 font-bold text-white">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                معلومات التواصل والدعم
              </div>
              <div className="p-3 bg-[#0A0A0A] rounded-xl space-y-1.5 border border-[#D4AF37]/30">
                <span className="text-gray-400 block text-[11px]">محفظة Etisalat Cash الرسمية:</span>
                <span className="font-mono text-sm font-black text-[#D4AF37] select-all block">
                  {settings.etisalatCashNumber || "01157783934"}
                </span>
              </div>
              <div className="p-3 bg-[#0A0A0A] rounded-xl space-y-1.5 border border-white/5">
                <span className="text-gray-400 block text-[11px]">البريد الإلكتروني الرسمي للدعم:</span>
                <a
                  id="support-chat-email-link"
                  href={`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(supportEmail)}&su=${encodeURIComponent("طلب دعم - منصة اتعلم ببساطة")}&body=${encodeURIComponent("مرحبًا فريق دعم منصة اتعلم ببساطة 👋\n\nأحتاج إلى المساعدة بخصوص:\n[اكتب مشكلتك هنا]\n\nشكرًا لكم ❤️")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-xs font-bold text-[#D4AF37] hover:underline flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="فتح Gmail لإنشاء رسالة جديدة للدعم"
                >
                  <Mail className="w-3.5 h-3.5 text-[#D4AF37] flex-shrink-0" />
                  <span className="truncate">{supportEmail}</span>
                </a>
              </div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                • يتم مراجعة التذاكر وتحديث حالتها في الحال.<br />
                • خصوصية تامة: تذاكرك محمية ولا يمكن لأي طالب آخر الاطلاع عليها.
              </p>
            </div>
          </div>

          {/* Right / Main Content Column */}
          <div className="lg:col-span-8">
            {isCreatingNew || (myTickets.length === 0 && !activeTicket) ? (
              /* Create New Ticket Form */
              <div
                ref={createFormRef}
                id="create-ticket-card"
                className="bg-[#151515] border border-white/10 rounded-2xl p-6 shadow-2xl space-y-6"
              >
                <div className="border-b border-white/10 pb-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                      <PlusCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-lg font-bold text-white">
                        إنشاء تذكرة دعم جديدة
                      </h2>
                      <p className="text-xs text-gray-400">
                        املأ بيانات التذكرة وسيقوم فريق الدعم والمساعد بالرد والمتابعة معك
                      </p>
                    </div>
                  </div>
                  {myTickets.length > 0 && (
                    <button
                      id="btn-cancel-create"
                      onClick={() => {
                        setIsCreatingNew(false);
                        if (myTickets.length > 0) setActiveTicketId(myTickets[0].id);
                      }}
                      className="text-xs text-gray-400 hover:text-white px-3 py-1.5 rounded-lg border border-white/10 hover:bg-white/5 transition cursor-pointer"
                    >
                      إلغاء والعودة
                    </button>
                  )}
                </div>

                {errorMsg && (
                  <div className="p-3.5 bg-red-500/10 border border-red-500/30 text-red-300 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleCreateTicket} className="space-y-5">
                  {/* Category Selector */}
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-gray-300">
                      نوع المشكلة / القسم:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {CATEGORIES.map((cat) => {
                        const Icon = cat.icon;
                        const isSel = selectedCategory === cat.id;
                        return (
                          <button
                            key={cat.id}
                            id={`btn-cat-${cat.id}`}
                            type="button"
                            onClick={() => setSelectedCategory(cat.id)}
                            className={`p-3 rounded-xl border text-right transition-all flex items-start gap-3 cursor-pointer ${
                              isSel
                                ? "bg-[#D4AF37]/15 border-[#D4AF37] text-white shadow-md shadow-[#D4AF37]/10"
                                : "bg-[#0A0A0A] border-white/5 text-gray-300 hover:border-white/20"
                            }`}
                          >
                            <Icon
                              className={`w-5 h-5 mt-0.5 shrink-0 ${
                                isSel ? "text-[#D4AF37]" : "text-gray-400"
                              }`}
                            />
                            <div>
                              <div className="text-xs font-bold">{cat.label}</div>
                              <div className="text-[11px] text-gray-400 leading-snug mt-0.5">
                                {cat.desc}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Subject */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="input-ticket-subject"
                      className="text-xs font-semibold text-gray-300"
                    >
                      عنوان المشكلة: <span className="text-red-400">*</span>
                    </label>
                    <input
                      ref={subjectInputRef}
                      id="input-ticket-subject"
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="مثال: مشكلة في تشغيل فيديو الدرس أو تأكيد إيصال الدفع"
                      className="w-full px-4 py-3 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#D4AF37]"
                      required
                    />
                  </div>

                  {/* Initial Message */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="input-ticket-message"
                      className="text-xs font-semibold text-gray-300"
                    >
                      وصف وتفاصيل المشكلة: <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      id="input-ticket-message"
                      rows={4}
                      value={initialMessage}
                      onChange={(e) => setInitialMessage(e.target.value)}
                      placeholder="اكتب تفاصيل استفسارك أو المشكلة التي تواجهك بكل وضوح..."
                      className="w-full px-4 py-3 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#D4AF37]"
                      required
                    />
                  </div>

                  {/* File / Image Attachment */}
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
                      <span>إرفاق صورة أو لقطة شاشة (اختياري):</span>
                      <span className="text-[11px] text-gray-500">الحد الأقصى: 5 ميجابايت</span>
                    </label>

                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, "ticket")}
                      className="hidden"
                    />

                    {ticketAttachment ? (
                      <div className="p-3 bg-[#0A0A0A] border border-[#D4AF37]/40 rounded-xl flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2 overflow-hidden">
                          <img
                            src={ticketAttachment}
                            alt="Attachment preview"
                            className="w-10 h-10 object-cover rounded-lg border border-white/10 cursor-pointer"
                            onClick={() => setPreviewImage(ticketAttachment)}
                          />
                          <span className="text-xs text-gray-300 truncate max-w-[200px]">
                            {ticketAttachmentName || "صورة مرفقة"}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setTicketAttachment(null);
                            setTicketAttachmentName("");
                            if (fileInputRef.current) fileInputRef.current.value = "";
                          }}
                          className="p-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition cursor-pointer"
                          title="حذف المرفق"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full p-3.5 rounded-xl border border-dashed border-white/20 hover:border-[#D4AF37] bg-[#0A0A0A] text-xs text-gray-400 hover:text-white flex items-center justify-center gap-2 transition cursor-pointer"
                      >
                        <Paperclip className="w-4 h-4 text-[#D4AF37]" />
                        <span>اضغط لرفع لقطة شاشة أو صورة إيصال الدفع</span>
                      </button>
                    )}
                  </div>

                  {/* Submit Button */}
                  <button
                    id="btn-submit-ticket"
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/20 transition-all disabled:opacity-50 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        جاري إرسال التذكرة وحفظها...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        إرسال التذكرة وبدء المحادثة
                      </>
                    )}
                  </button>
                </form>
              </div>
            ) : activeTicket ? (
              /* Active Ticket Conversation Thread */
              <div
                id="ticket-thread-container"
                className="bg-[#151515] border border-white/10 rounded-2xl flex flex-col h-[650px] shadow-2xl overflow-hidden"
              >
                {/* Thread Header */}
                <div
                  id="thread-header"
                  className="p-4 sm:p-5 border-b border-white/10 bg-[#1A1A1A] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => {
                          setActiveTicketId(null);
                          setIsCreatingNew(false);
                        }}
                        className="lg:hidden text-xs text-[#D4AF37] flex items-center gap-1 font-bold pl-2 border-l border-white/10 cursor-pointer"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                        الرجوع للتذاكر
                      </button>

                      <span className="text-[11px] font-semibold text-[#D4AF37] bg-[#D4AF37]/15 px-2.5 py-0.5 rounded-full border border-[#D4AF37]/30">
                        {getCategoryLabel(activeTicket.category)}
                      </span>
                      {getStatusBadge(activeTicket.status, activeTicket.needsAdminAttention)}
                    </div>
                    <h2 className="font-black text-base sm:text-lg text-white">
                      {activeTicket.subject}
                    </h2>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-[11px] text-gray-400 text-left">
                      تاريخ الإنشاء: <span className="font-mono text-white">{new Date(activeTicket.createdAt).toLocaleDateString("ar-EG")}</span>
                    </div>

                    {activeTicket.status !== "closed" && (
                      <button
                        id="btn-student-close-ticket"
                        onClick={handleCloseTicket}
                        className="text-xs px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 transition cursor-pointer"
                        title="إغلاق التذكرة إذا تم حل المشكلة"
                      >
                        إغلاق التذكرة
                      </button>
                    )}
                  </div>
                </div>

                {/* Escalation Alert if Needs Admin */}
                {activeTicket.needsAdminAttention && (
                  <div
                    id="escalation-alert"
                    className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2.5 text-xs text-amber-200 flex items-center gap-2 shrink-0"
                  >
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>
                      تم تحويل استفسارك إلى <strong>فريق الدعم الفني البشري</strong> لمراجعته والرد عليك قريباً.
                    </span>
                  </div>
                )}

                {/* Messages Scroll Area */}
                <div
                  id="messages-scroll-area"
                  className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 custom-scrollbar bg-[#0A0A0A]"
                >
                  {(!activeTicket.messages || activeTicket.messages.length === 0) && (
                    <div
                      id="thread-welcome-card"
                      className="p-5 rounded-2xl bg-gradient-to-br from-[#1C180A] via-[#151515] to-[#0A0A0A] border border-[#D4AF37]/40 shadow-xl space-y-4 max-w-2xl mx-auto my-4"
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] text-white flex items-center justify-center shrink-0 shadow-lg shadow-[#D4AF37]/30 border border-white/20">
                          <Bot className="w-5 h-5" />
                        </div>
                        <div className="space-y-1.5 text-sm text-gray-200 leading-relaxed flex-1">
                          <div className="font-black text-white text-base flex items-center gap-2">
                            <span>👋 أهلاً بك في دعم «اتعلم ببساطة»</span>
                          </div>
                          <div className="p-2 rounded-xl bg-[#0A0A0A]/70 border border-[#D4AF37]/30 text-xs text-[#D4AF37] font-semibold flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0 animate-pulse" />
                            <span>كيف يمكننا مساعدتك اليوم؟ اختر أحد الأقسام التالية أو اكتب رسالتك:</span>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-[#D4AF37]/20">
                        {SUPPORT_CATEGORIES.map((cat) => {
                          const isSel = selectedSection === cat.id;
                          return (
                            <button
                              key={cat.id}
                              id={`btn-thread-welcome-${cat.id}`}
                              type="button"
                              onClick={() => setSelectedSection((prev) => (prev === cat.id ? null : cat.id))}
                              className={`p-2.5 rounded-xl border text-right transition-all text-xs font-bold flex items-center justify-between gap-2 cursor-pointer group ${
                                isSel
                                  ? "bg-[#D4AF37]/20 border-[#D4AF37] text-white"
                                  : "bg-[#0A0A0A] hover:bg-[#1A1A1A] border-[#D4AF37]/30 text-gray-200"
                              }`}
                            >
                              <span className="flex items-center gap-2">
                                <span className="text-base">{cat.emoji}</span>
                                <span className="group-hover:text-[#D4AF37] transition-colors">{cat.label}</span>
                              </span>
                              <span className="text-[10px] text-gray-400">3 أسئلة</span>
                            </button>
                          );
                        })}
                      </div>

                      {selectedSection && (() => {
                        const activeCat = SUPPORT_CATEGORIES.find((c) => c.id === selectedSection);
                        if (!activeCat) return null;
                        return (
                          <div className="p-3 rounded-xl bg-[#0A0A0A] border border-[#D4AF37]/30 space-y-2 animate-in fade-in">
                            <div className="text-[11px] font-bold text-[#D4AF37]">
                              اختر سؤالاً لإدراجه في المحادثة:
                            </div>
                            <div className="grid grid-cols-1 gap-1.5">
                              {activeCat.questions.map((q, idx) => (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => handleSelectThreadPresetQuestion(q)}
                                  className="p-2 rounded-lg bg-[#151515] hover:bg-[#202020] border border-white/5 hover:border-[#D4AF37] text-gray-200 hover:text-white text-xs text-right flex items-center justify-between transition cursor-pointer"
                                >
                                  <span>{q}</span>
                                  <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
                                </button>
                              ))}
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}

                  {activeTicket.messages?.map((msg) => {
                    const isStudent = msg.sender === "student";
                    const isAi = msg.sender === "ai";
                    const isAdmin = msg.sender === "admin";

                    return (
                      <div
                        key={msg.id}
                        id={`chat-message-${msg.id}`}
                        className={`flex gap-3 max-w-[85%] ${
                          isStudent ? "mr-auto flex-row-reverse" : "ml-auto"
                        }`}
                      >
                        {/* Avatar */}
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                            isStudent
                              ? "bg-slate-700 text-white"
                              : isAi
                              ? "bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/30"
                              : "bg-red-600 text-white shadow-md shadow-red-600/30"
                          }`}
                        >
                          {isStudent ? (
                            <User className="w-4 h-4" />
                          ) : isAi ? (
                            <Bot className="w-4 h-4" />
                          ) : (
                            <ShieldCheck className="w-4 h-4" />
                          )}
                        </div>

                        {/* Message Box */}
                        <div className="space-y-1">
                          <div
                            className={`flex items-center gap-2 text-[11px] ${
                              isStudent ? "justify-end text-gray-400" : "text-gray-400"
                            }`}
                          >
                            <span className="font-semibold text-gray-200">
                              {msg.senderName || (isAi ? "المساعد الذكي (Gemini AI)" : isAdmin ? "مشرف الدعم" : "أنت")}
                            </span>
                            {isAi && (
                              <span className="text-[9px] bg-[#D4AF37]/20 text-[#D4AF37] px-1.5 py-0.2 rounded border border-[#D4AF37]/30">
                                AI
                              </span>
                            )}
                            {isAdmin && (
                              <span className="text-[9px] bg-red-500/20 text-red-300 px-1.5 py-0.2 rounded border border-red-500/30">
                                مشرف الدعم
                              </span>
                            )}
                            <span className="text-[10px] text-gray-500">
                              {new Date(msg.createdAt).toLocaleTimeString("ar-EG", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>

                          <div
                            className={`p-3.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                              isStudent
                                ? "bg-[#1A1A1A] text-white rounded-tr-none border border-white/10"
                                : isAi
                                ? "bg-[#151515] text-gray-200 rounded-tl-none border border-[#D4AF37]/30 shadow-lg"
                                : "bg-[#1F1515] text-red-100 rounded-tl-none border border-red-500/40 shadow-lg"
                            }`}
                          >
                            {msg.text && <p>{msg.text}</p>}

                            {/* Image Attachment Preview in message */}
                            {msg.attachmentUrl && (
                              <div className="mt-2.5">
                                <img
                                  src={msg.attachmentUrl}
                                  alt="Message attachment"
                                  onClick={() => setPreviewImage(msg.attachmentUrl!)}
                                  className="max-h-48 max-w-full rounded-xl border border-white/15 object-cover cursor-pointer hover:opacity-90 transition"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {isSendingReply && (
                    <div className="flex gap-3 max-w-[80%] ml-auto">
                      <div className="w-8 h-8 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
                        <Bot className="w-4 h-4 animate-spin" />
                      </div>
                      <div className="p-3 bg-[#151515] border border-white/10 rounded-2xl text-xs text-gray-400 flex items-center gap-2">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
                        جاري معالجة الرد وتحديث المحادثة...
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {/* Reply Composer */}
                <form
                  onSubmit={handleSendReply}
                  id="form-send-reply"
                  className="p-3 sm:p-4 border-t border-white/10 bg-[#151515] shrink-0 space-y-2"
                >
                  {replyAttachment && (
                    <div className="p-2 bg-[#0A0A0A] border border-[#D4AF37]/40 rounded-xl flex items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        <img
                          src={replyAttachment}
                          alt="Reply attachment"
                          className="w-7 h-7 object-cover rounded"
                        />
                        <span className="text-gray-300 truncate max-w-[200px]">
                          {replyAttachmentName || "صورة مرفقة"}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setReplyAttachment(null);
                          setReplyAttachmentName("");
                        }}
                        className="p-1 text-red-400 hover:text-red-300"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <input
                      ref={replyFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, "reply")}
                      className="hidden"
                    />

                    <button
                      type="button"
                      onClick={() => replyFileInputRef.current?.click()}
                      className="p-3 rounded-xl bg-[#0A0A0A] border border-white/10 text-gray-400 hover:text-[#D4AF37] hover:border-[#D4AF37]/50 transition cursor-pointer"
                      title="إرفاق صورة"
                    >
                      <ImageIcon className="w-4 h-4" />
                    </button>

                    <input
                      id="input-reply-message"
                      type="text"
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      placeholder="اكتب ردك أو استفساراً إضافياً هنا..."
                      className="flex-1 px-4 py-3 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#D4AF37]"
                      disabled={isSendingReply}
                    />

                    <button
                      id="btn-send-reply"
                      type="submit"
                      disabled={isSendingReply || (!replyMessage.trim() && !replyAttachment)}
                      className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white font-bold text-sm flex items-center gap-1.5 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-[#D4AF37]/20 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span className="hidden sm:inline">إرسال</span>
                    </button>
                  </div>
                </form>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {/* Image Zoom Lightbox Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="max-w-3xl max-h-[85vh] bg-[#151515] border border-white/10 rounded-2xl p-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-3 left-3 p-1.5 rounded-lg bg-[#0A0A0A] text-gray-300 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewImage}
              alt="Preview"
              className="max-h-[75vh] w-auto mx-auto object-contain rounded-xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
