import React, { useState, useMemo } from "react";
import { useApp } from "../context/AppContext";
import { CourseCategory, CourseLevelItem, Course, HierarchicalCategoryNode } from "../types";
import {
  buildCategoryTree,
  getDescendantCategoryIds,
  getCategoryAncestry,
  getDepthBadgeInfo,
  isCourseInSelectedCategory,
} from "../lib/categoryUtils";
import {
  Layers,
  Tag,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Search,
  AlertTriangle,
  ArrowUp,
  ArrowDown,
  Globe,
  Bot,
  Terminal,
  Palette,
  Shield,
  Database,
  Smartphone,
  Cpu,
  BookOpen,
  Sparkles,
  Code,
  GraduationCap,
  Flame,
  Check,
  X,
  BookMarked,
  Info,
  ChevronDown,
  ChevronRight,
  FolderTree,
  ListFilter,
  RefreshCw,
  CornerDownLeft,
  FolderPlus,
  HelpCircle,
  ExternalLink,
} from "lucide-react";

// Icon mapping helper
export const CATEGORY_ICONS: Record<string, React.FC<{ className?: string }>> = {
  GraduationCap: GraduationCap,
  BookOpen: BookOpen,
  Code: Code,
  Globe: Globe,
  Bot: Bot,
  Terminal: Terminal,
  Palette: Palette,
  Flame: Flame,
  Sparkles: Sparkles,
  Cpu: Cpu,
  Database: Database,
  Smartphone: Smartphone,
  Shield: Shield,
  Layers: Layers,
  BookMarked: BookMarked,
  Tag: Tag,
};

export const AdminCategoriesLevels: React.FC = () => {
  const {
    language,
    categories,
    levels,
    courses,
    addCategory,
    updateCategory,
    deleteCategory,
    toggleCategoryActive,
    reorderCategories,
    seedDefaultCategories,
    addLevel,
    updateLevel,
    deleteLevel,
    toggleLevelActive,
    reorderLevels,
  } = useApp();

  const isAr = language === "ar";
  const [subTab, setSubTab] = useState<"categories" | "levels">("categories");
  const [viewMode, setViewMode] = useState<"tree" | "table">("tree");
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({});

  // Search & Filters
  const [catSearch, setCatSearch] = useState("");
  const [depthFilter, setDepthFilter] = useState<"all" | "0" | "1" | "2">("all");
  const [lvlSearch, setLvlSearch] = useState("");

  // Feedback Toasts
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const showToast = (message: string, type: "success" | "error" = "success") => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  // Category Modal State
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<CourseCategory | null>(null);
  const [catForm, setCatForm] = useState<{
    name: string;
    nameEn: string;
    description: string;
    icon: string;
    parentId: string | null;
    active: boolean;
    order: number;
  }>({
    name: "",
    nameEn: "",
    description: "",
    icon: "GraduationCap",
    parentId: null,
    active: true,
    order: 1,
  });

  // Delete Category Warning Modal State
  const [catToDelete, setCatToDelete] = useState<CourseCategory | null>(null);
  const [catReplacement, setCatReplacement] = useState<string>("");
  const [isDeletingCat, setIsDeletingCat] = useState(false);

  // Seed Default Categories Confirmation Modal
  const [isSeedModalOpen, setIsSeedModalOpen] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  // Level Modal State
  const [isLvlModalOpen, setIsLvlModalOpen] = useState(false);
  const [editingLvl, setEditingLvl] = useState<CourseLevelItem | null>(null);
  const [lvlForm, setLvlForm] = useState<{
    name: string;
    nameEn: string;
    description: string;
    active: boolean;
    order: number;
  }>({
    name: "",
    nameEn: "",
    description: "",
    active: true,
    order: 1,
  });

  // Delete Level Warning Modal State
  const [lvlToDelete, setLvlToDelete] = useState<CourseLevelItem | null>(null);
  const [lvlReplacement, setLvlReplacement] = useState<string>("");
  const [isDeletingLvl, setIsDeletingLvl] = useState(false);

  // Build hierarchical category tree
  const categoryTree = useMemo(() => {
    return buildCategoryTree(categories, courses);
  }, [categories, courses]);

  // Toggle expand/collapse node
  const toggleExpand = (nodeId: string) => {
    setExpandedNodes((prev) => ({
      ...prev,
      [nodeId]: prev[nodeId] === undefined ? false : !prev[nodeId],
    }));
  };

  // Expand all / Collapse all
  const expandAll = () => {
    const next: Record<string, boolean> = {};
    categories.forEach((c) => {
      next[c.id] = true;
    });
    setExpandedNodes(next);
  };

  const collapseAll = () => {
    const next: Record<string, boolean> = {};
    categories.forEach((c) => {
      next[c.id] = false;
    });
    setExpandedNodes(next);
  };

  // Stats calculation
  const stats = useMemo(() => {
    const mainCats = categories.filter((c) => !c.parentId);
    const subCats = categories.filter((c) => {
      if (!c.parentId) return false;
      const parent = categories.find((p) => p.id === c.parentId);
      return !parent || !parent.parentId;
    });
    const subjectCats = categories.filter((c) => {
      if (!c.parentId) return false;
      const parent = categories.find((p) => p.id === c.parentId);
      return parent && parent.parentId;
    });
    const totalCoursesWithCat = courses.filter((c) => c.category || c.categoryId).length;

    return {
      mainCount: mainCats.length,
      subCount: subCats.length,
      subjectCount: subjectCats.length,
      totalCount: categories.length,
      totalCourses: totalCoursesWithCat,
    };
  }, [categories, courses]);

  // Filtered categories for list/table view
  const filteredCategories = useMemo(() => {
    return categories
      .filter((c) => {
        const q = catSearch.toLowerCase().trim();
        const matchesSearch =
          !q ||
          c.name.toLowerCase().includes(q) ||
          (c.nameEn && c.nameEn.toLowerCase().includes(q)) ||
          (c.description && c.description.toLowerCase().includes(q));

        if (!matchesSearch) return false;

        if (depthFilter === "0") return !c.parentId;
        if (depthFilter === "1") {
          if (!c.parentId) return false;
          const parent = categories.find((p) => p.id === c.parentId);
          return !parent || !parent.parentId;
        }
        if (depthFilter === "2") {
          if (!c.parentId) return false;
          const parent = categories.find((p) => p.id === c.parentId);
          return parent && parent.parentId;
        }

        return true;
      })
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [categories, catSearch, depthFilter]);

  // Filtered Levels
  const filteredLevels = useMemo(() => {
    return levels
      .filter((l) => {
        const q = lvlSearch.toLowerCase().trim();
        return (
          !q ||
          l.name.toLowerCase().includes(q) ||
          (l.nameEn && l.nameEn.toLowerCase().includes(q)) ||
          (l.description && l.description.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [levels, lvlSearch]);

  // Open Category Create / Edit Modal
  const openCategoryModal = (cat?: CourseCategory, defaultParentId: string | null = null) => {
    if (cat) {
      setEditingCat(cat);
      setCatForm({
        name: cat.name,
        nameEn: cat.nameEn || "",
        description: cat.description || "",
        icon: cat.icon || "GraduationCap",
        parentId: cat.parentId || null,
        active: cat.active !== false,
        order: cat.order || 1,
      });
    } else {
      setEditingCat(null);
      // Auto-calculate next order for siblings
      const siblingCount = categories.filter((c) => c.parentId === defaultParentId).length;
      setCatForm({
        name: "",
        nameEn: "",
        description: "",
        icon: defaultParentId ? "BookOpen" : "GraduationCap",
        parentId: defaultParentId,
        active: true,
        order: siblingCount + 1,
      });
    }
    setIsCatModalOpen(true);
  };

  // Handle Save Category
  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catForm.name.trim()) {
      showToast(isAr ? "يرجى كتابة اسم القسم" : "Category name is required", "error");
      return;
    }

    try {
      if (editingCat) {
        // Prevent setting parent to itself or one of its descendants to avoid cycles
        if (catForm.parentId === editingCat.id) {
          showToast(isAr ? "لا يمكن جعل القسم أباً لنفسه!" : "Category cannot be its own parent!", "error");
          return;
        }
        const descendantIds = getDescendantCategoryIds(editingCat.id, categories);
        if (catForm.parentId && descendantIds.includes(catForm.parentId)) {
          showToast(
            isAr ? "لا يمكن نقل القسم ليكون فرعاً تحت أحد أقسامه الفرعية!" : "Cannot set a child as parent!",
            "error"
          );
          return;
        }

        await updateCategory(
          editingCat.id,
          {
            name: catForm.name.trim(),
            nameEn: catForm.nameEn.trim() || undefined,
            description: catForm.description.trim() || undefined,
            icon: catForm.icon,
            parentId: catForm.parentId || null,
            active: catForm.active,
            order: Number(catForm.order) || 1,
          },
          editingCat.name
        );
        showToast(isAr ? `تم تحديث «${catForm.name}» بنجاح` : "Category updated successfully");
      } else {
        await addCategory({
          name: catForm.name.trim(),
          nameEn: catForm.nameEn.trim() || undefined,
          description: catForm.description.trim() || undefined,
          icon: catForm.icon,
          parentId: catForm.parentId || null,
          active: catForm.active,
          order: Number(catForm.order) || 1,
        });
        showToast(isAr ? `تمت إضافة «${catForm.name}» بنجاح` : "Category added successfully");
      }
      setIsCatModalOpen(false);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || (isAr ? "حدث خطأ أثناء الحفظ" : "Error saving category"), "error");
    }
  };

  // Reorder sibling categories (Move Up / Down)
  const handleMoveSibling = async (catId: string, direction: "up" | "down") => {
    const current = categories.find((c) => c.id === catId);
    if (!current) return;

    const siblings = categories
      .filter((c) => (c.parentId || null) === (current.parentId || null))
      .sort((a, b) => (a.order || 0) - (b.order || 0));

    const index = siblings.findIndex((c) => c.id === catId);
    if (index === -1) return;

    if (direction === "up" && index > 0) {
      const prev = siblings[index - 1];
      const newSiblings = [...siblings];
      newSiblings[index - 1] = current;
      newSiblings[index] = prev;
      await reorderCategories(newSiblings.map((s) => s.id));
      showToast(isAr ? "تم تعديل الترتيب" : "Reordered successfully");
    } else if (direction === "down" && index < siblings.length - 1) {
      const next = siblings[index + 1];
      const newSiblings = [...siblings];
      newSiblings[index + 1] = current;
      newSiblings[index] = next;
      await reorderCategories(newSiblings.map((s) => s.id));
      showToast(isAr ? "تم تعديل الترتيب" : "Reordered successfully");
    }
  };

  // Open Delete Category Modal
  const openDeleteCategoryModal = (cat: CourseCategory) => {
    setCatToDelete(cat);
    const otherCats = categories.filter((c) => c.id !== cat.id);
    setCatReplacement(otherCats[0]?.name || "");
  };

  // Confirm Delete Category
  const handleConfirmDeleteCategory = async () => {
    if (!catToDelete) return;
    setIsDeletingCat(true);
    try {
      await deleteCategory(catToDelete.id, catReplacement || undefined);
      showToast(isAr ? `تم حذف قسم «${catToDelete.name}» بأمان` : "Category deleted safely");
      setCatToDelete(null);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || (isAr ? "حدث خطأ أثناء الحذف" : "Error deleting category"), "error");
    } finally {
      setIsDeletingCat(false);
    }
  };

  // Seed Default Categories
  const handleConfirmSeed = async () => {
    setIsSeeding(true);
    try {
      await seedDefaultCategories();
      showToast(isAr ? "تم استيراد وتهيئة الهيكل النموذجي بنجاح!" : "Default hierarchy imported successfully!");
      setIsSeedModalOpen(false);
    } catch (err: any) {
      console.error(err);
      showToast(isAr ? "حدث خطأ أثناء التهيئة" : "Error seeding categories", "error");
    } finally {
      setIsSeeding(false);
    }
  };

  // Level Management Handlers
  const openLevelModal = (lvl?: CourseLevelItem) => {
    if (lvl) {
      setEditingLvl(lvl);
      setLvlForm({
        name: lvl.name,
        nameEn: lvl.nameEn || "",
        description: lvl.description || "",
        active: lvl.active !== false,
        order: lvl.order || 1,
      });
    } else {
      setEditingLvl(null);
      setLvlForm({
        name: "",
        nameEn: "",
        description: "",
        active: true,
        order: levels.length + 1,
      });
    }
    setIsLvlModalOpen(true);
  };

  const handleSaveLevel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lvlForm.name.trim()) {
      showToast(isAr ? "يرجى كتابة اسم المستوى" : "Level name is required", "error");
      return;
    }

    try {
      if (editingLvl) {
        await updateLevel(
          editingLvl.id,
          {
            name: lvlForm.name.trim(),
            nameEn: lvlForm.nameEn.trim() || undefined,
            description: lvlForm.description.trim() || undefined,
            active: lvlForm.active,
            order: Number(lvlForm.order) || 1,
          },
          editingLvl.name
        );
        showToast(isAr ? `تم تحديث مستوى «${lvlForm.name}»` : "Level updated successfully");
      } else {
        await addLevel({
          name: lvlForm.name.trim(),
          nameEn: lvlForm.nameEn.trim() || undefined,
          description: lvlForm.description.trim() || undefined,
          active: lvlForm.active,
          order: Number(lvlForm.order) || 1,
        });
        showToast(isAr ? `تمت إضافة مستوى «${lvlForm.name}»` : "Level added successfully");
      }
      setIsLvlModalOpen(false);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || (isAr ? "حدث خطأ أثناء الحفظ" : "Error saving level"), "error");
    }
  };

  const handleMoveLevel = async (lvlId: string, direction: "up" | "down") => {
    const index = levels.findIndex((l) => l.id === lvlId);
    if (index === -1) return;

    if (direction === "up" && index > 0) {
      const newLevels = [...levels];
      const temp = newLevels[index - 1];
      newLevels[index - 1] = newLevels[index];
      newLevels[index] = temp;
      await reorderLevels(newLevels.map((l) => l.id));
      showToast(isAr ? "تم تعديل الترتيب" : "Reordered successfully");
    } else if (direction === "down" && index < levels.length - 1) {
      const newLevels = [...levels];
      const temp = newLevels[index + 1];
      newLevels[index + 1] = newLevels[index];
      newLevels[index] = temp;
      await reorderLevels(newLevels.map((l) => l.id));
      showToast(isAr ? "تم تعديل الترتيب" : "Reordered successfully");
    }
  };

  const openDeleteLevelModal = (lvl: CourseLevelItem) => {
    setLvlToDelete(lvl);
    const otherLevels = levels.filter((l) => l.id !== lvl.id);
    setLvlReplacement(otherLevels[0]?.name || "");
  };

  const handleConfirmDeleteLevel = async () => {
    if (!lvlToDelete) return;
    setIsDeletingLvl(true);
    try {
      await deleteLevel(lvlToDelete.id, lvlReplacement || undefined);
      showToast(isAr ? `تم حذف مستوى «${lvlToDelete.name}» بأمان` : "Level deleted safely");
      setLvlToDelete(null);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || (isAr ? "حدث خطأ أثناء الحذف" : "Error deleting level"), "error");
    } finally {
      setIsDeletingLvl(false);
    }
  };

  // Renders a category node recursively in Tree View
  const renderTreeNode = (node: HierarchicalCategoryNode, depth: number = 0) => {
    const hasChildren = node.children && node.children.length > 0;
    // Default open for root and depth 1 unless explicitly collapsed
    const isExpanded = expandedNodes[node.id] !== false;
    const IconComp = CATEGORY_ICONS[node.icon || "GraduationCap"] || GraduationCap;
    const depthInfo = getDepthBadgeInfo(depth, isAr);

    return (
      <div key={node.id} className="space-y-2">
        {/* Node Item Card */}
        <div
          className={`group relative rounded-2xl border transition-all duration-200 ${
            depth === 0
              ? "bg-[#151515] border-white/15 p-3.5 sm:p-4 shadow-md"
              : depth === 1
              ? "bg-[#121212] border-white/10 p-3 sm:p-3.5 mr-4 sm:mr-8 border-r-2 border-r-blue-500/50"
              : "bg-[#0E0E0E] border-white/5 p-2.5 sm:p-3 mr-8 sm:mr-16 border-r-2 border-r-emerald-500/50"
          } hover:border-[#D4AF37]/40`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Left/Right Identity */}
            <div className="flex items-center gap-2.5 sm:gap-3 flex-1 min-w-0">
              {/* Expand/Collapse Chevron */}
              {hasChildren ? (
                <button
                  type="button"
                  onClick={() => toggleExpand(node.id)}
                  className="p-1 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer flex-shrink-0"
                  title={isExpanded ? (isAr ? "طي" : "Collapse") : (isAr ? "توسيع" : "Expand")}
                >
                  {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </button>
              ) : (
                <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
                  <div className="w-1.5 h-1.5 rounded-full bg-gray-600" />
                </div>
              )}

              {/* Icon Container */}
              <div
                className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center flex-shrink-0 border ${
                  depth === 0
                    ? "bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37]"
                    : depth === 1
                    ? "bg-blue-500/10 border-blue-500/30 text-blue-400"
                    : "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                }`}
              >
                <IconComp className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>

              {/* Text Info */}
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                    {node.name}
                  </h4>
                  {node.nameEn && (
                    <span className="text-[10px] text-gray-400 font-mono">
                      ({node.nameEn})
                    </span>
                  )}
                  {/* Depth Badge */}
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${depthInfo.colorClass}`}
                  >
                    {depthInfo.label}
                  </span>
                  {/* Course count badge */}
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#0A0A0A] text-gray-300 border border-white/10">
                    {node.courseCount || 0} {isAr ? "كورس" : "courses"}
                  </span>
                  {!node.active && (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-red-950/50 text-red-400 border border-red-500/30">
                      {isAr ? "معطل" : "Inactive"}
                    </span>
                  )}
                </div>

                {node.description && (
                  <p className="text-[11px] text-gray-400 truncate mt-0.5">
                    {node.description}
                  </p>
                )}
              </div>
            </div>

            {/* Actions Bar */}
            <div className="flex items-center gap-1.5 sm:gap-2 self-end sm:self-center flex-shrink-0">
              {/* Add Sub Category direct button */}
              {depth < 2 && (
                <button
                  type="button"
                  onClick={() => openCategoryModal(undefined, node.id)}
                  className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-[#1A1A1A] hover:bg-[#D4AF37]/20 text-gray-300 hover:text-[#D4AF37] border border-white/10 hover:border-[#D4AF37]/40 flex items-center gap-1 transition cursor-pointer"
                  title={isAr ? "إضافة فرع أو مادة تحت هذا القسم" : "Add child under this category"}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline text-[11px]">
                    {depth === 0 ? (isAr ? "إضافة فرعي" : "Add Sub") : (isAr ? "إضافة مادة" : "Add Track")}
                  </span>
                </button>
              )}

              {/* Move Up / Down */}
              <div className="flex items-center rounded-lg bg-[#0A0A0A] border border-white/10 overflow-hidden">
                <button
                  type="button"
                  onClick={() => handleMoveSibling(node.id, "up")}
                  className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
                  title={isAr ? "تحريك لأعلى" : "Move Up"}
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleMoveSibling(node.id, "down")}
                  className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer border-r border-white/10"
                  title={isAr ? "تحريك لأسفل" : "Move Down"}
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Toggle Active */}
              <button
                type="button"
                onClick={() => toggleCategoryActive(node.id, !node.active)}
                className={`p-1.5 rounded-lg border transition cursor-pointer ${
                  node.active
                    ? "bg-emerald-950/40 text-emerald-400 border-emerald-500/30 hover:bg-emerald-900/50"
                    : "bg-red-950/40 text-red-400 border-red-500/30 hover:bg-red-900/50"
                }`}
                title={
                  node.active
                    ? isAr
                      ? "فعال (انقر للتعطيل)"
                      : "Active"
                    : isAr
                    ? "معطل (انقر للتفعيل)"
                    : "Inactive"
                }
              >
                {node.active ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
              </button>

              {/* Edit */}
              <button
                type="button"
                onClick={() => openCategoryModal(node)}
                className="p-1.5 rounded-lg bg-[#0A0A0A] text-[#D4AF37] border border-white/10 hover:bg-white/10 transition cursor-pointer"
                title={isAr ? "تعديل" : "Edit"}
              >
                <Edit2 className="w-4 h-4" />
              </button>

              {/* Delete */}
              <button
                type="button"
                onClick={() => openDeleteCategoryModal(node)}
                className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/80 text-red-400 border border-red-500/20 hover:border-red-500/40 transition cursor-pointer"
                title={isAr ? "حذف" : "Delete"}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Children Subtrees */}
        {hasChildren && isExpanded && (
          <div className="space-y-2 relative">
            {node.children!.map((child) => renderTreeNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Toast Notification Banner */}
      {toast && (
        <div
          className={`p-4 rounded-2xl flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold shadow-xl border animate-in slide-in-from-top-3 ${
            toast.type === "success"
              ? "bg-emerald-950/80 text-emerald-200 border-emerald-500/40"
              : "bg-red-950/80 text-red-200 border-red-500/40"
          }`}
        >
          <div className="flex items-center gap-2">
            {toast.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
          <button
            onClick={() => setToast(null)}
            className="p-1 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header & SubTabs Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl bg-[#151515] border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="text-lg sm:text-xl font-bold text-white">
              {isAr ? "إدارة الأقسام والتصنيفات الهرمية" : "Hierarchical Categories & Levels"}
            </h2>
          </div>
          <p className="text-xs text-gray-400">
            {isAr
              ? "نظام هرمي مرن وديناميكي (القسم الرئيسي ← القسم الفرعي ← التصنيف/المادة ← الكورسات) مع تحكم شامل."
              : "Full control over hierarchical categories, subcategories, subjects, and levels."}
          </p>
        </div>

        {/* Tab Switcher Pills */}
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#0A0A0A] border border-white/10 self-start md:self-auto">
          <button
            onClick={() => setSubTab("categories")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
              subTab === "categories"
                ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{isAr ? "الأقسام والتصنيفات الهرمية" : "Categories"}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
              {categories.length}
            </span>
          </button>

          <button
            onClick={() => setSubTab("levels")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
              subTab === "levels"
                ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            <span>{isAr ? "مستويات الكورسات" : "Course Levels"}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
              {levels.length}
            </span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUBTAB 1: HIERARCHICAL CATEGORIES */}
      {/* ========================================================================= */}
      {subTab === "categories" && (
        <div className="space-y-6">
          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
            <div className="p-4 rounded-2xl bg-[#151515] border border-amber-500/20 shadow-md">
              <span className="text-[11px] font-semibold text-gray-400 block mb-1">
                {isAr ? "الأقسام الرئيسية" : "Main Categories"}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl sm:text-2xl font-black text-[#D4AF37]">
                  {stats.mainCount}
                </span>
                <span className="text-[10px] text-amber-400/80">المستوى 1</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#151515] border border-blue-500/20 shadow-md">
              <span className="text-[11px] font-semibold text-gray-400 block mb-1">
                {isAr ? "الأقسام الفرعية" : "Sub Categories"}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl sm:text-2xl font-black text-blue-400">
                  {stats.subCount}
                </span>
                <span className="text-[10px] text-blue-400/80">المستوى 2</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#151515] border border-emerald-500/20 shadow-md">
              <span className="text-[11px] font-semibold text-gray-400 block mb-1">
                {isAr ? "المواد / التصنيفات" : "Subjects & Tracks"}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl sm:text-2xl font-black text-emerald-400">
                  {stats.subjectCount}
                </span>
                <span className="text-[10px] text-emerald-400/80">المستوى 3</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#151515] border border-purple-500/20 shadow-md">
              <span className="text-[11px] font-semibold text-gray-400 block mb-1">
                {isAr ? "الكورسات المصنفة" : "Classified Courses"}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl sm:text-2xl font-black text-purple-400">
                  {stats.totalCourses}
                </span>
                <span className="text-[10px] text-gray-400">من {courses.length}</span>
              </div>
            </div>
          </div>

          {/* Action Bar: Search, View Mode, Filter, Create */}
          <div className="p-4 rounded-2xl bg-[#151515] border border-white/10 shadow-lg space-y-3">
            <div className="flex flex-col md:flex-row items-center justify-between gap-3">
              {/* Search Bar */}
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={catSearch}
                  onChange={(e) => setCatSearch(e.target.value)}
                  placeholder={
                    isAr
                      ? "بحث في جميع الأقسام والمواد..."
                      : "Search categories & tracks..."
                  }
                  className="w-full pr-10 pl-4 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
                />
              </div>

              {/* View Toggle & Expand/Collapse */}
              <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end flex-wrap">
                {/* View Mode */}
                <div className="flex items-center p-1 rounded-xl bg-[#0A0A0A] border border-white/10">
                  <button
                    onClick={() => setViewMode("tree")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                      viewMode === "tree"
                        ? "bg-[#1A1A1A] text-[#D4AF37] border border-white/10"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    <FolderTree className="w-3.5 h-3.5" />
                    <span>{isAr ? "عرض الشجرة الهرمية" : "Tree"}</span>
                  </button>

                  <button
                    onClick={() => setViewMode("table")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                      viewMode === "table"
                        ? "bg-[#1A1A1A] text-[#D4AF37] border border-white/10"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    <ListFilter className="w-3.5 h-3.5" />
                    <span>{isAr ? "عرض القائمة" : "Table"}</span>
                  </button>
                </div>

                {viewMode === "tree" && (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={expandAll}
                      className="px-2.5 py-1.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-[11px] text-gray-300 hover:text-white hover:bg-white/5 transition cursor-pointer"
                    >
                      {isAr ? "توسيع الكل" : "Expand All"}
                    </button>
                    <button
                      onClick={collapseAll}
                      className="px-2.5 py-1.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-[11px] text-gray-300 hover:text-white hover:bg-white/5 transition cursor-pointer"
                    >
                      {isAr ? "طي الكل" : "Collapse All"}
                    </button>
                  </div>
                )}

                {/* Primary Action Button */}
                <button
                  onClick={() => openCategoryModal()}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-[#D4AF37]/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isAr ? "إضافة قسم جديد" : "New Category"}</span>
                </button>

                {/* Seed Default Template Button */}
                <button
                  onClick={() => setIsSeedModalOpen(true)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-[#0A0A0A] hover:bg-[#1A1A1A] text-amber-300 border border-amber-500/30 hover:border-amber-500/50 flex items-center gap-1.5 transition cursor-pointer"
                  title={isAr ? "تهيئة واستيراد الهيكل التعليمي النموذجي" : "Import Default Template"}
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{isAr ? "استيراد الهيكل النموذجي" : "Import Template"}</span>
                </button>
              </div>
            </div>

            {/* Depth filter for table view */}
            {viewMode === "table" && (
              <div className="flex items-center gap-2 pt-2 border-t border-white/5 overflow-x-auto">
                <span className="text-[11px] text-gray-400 font-semibold whitespace-nowrap">
                  {isAr ? "تصفية حسب المستوى الهرمي:" : "Filter by level:"}
                </span>
                {(
                  [
                    { id: "all", label: isAr ? "الكل" : "All" },
                    { id: "0", label: isAr ? "أقسام رئيسية فقط" : "Main Only" },
                    { id: "1", label: isAr ? "أقسام فرعية فقط" : "Sub Only" },
                    { id: "2", label: isAr ? "مواد وتصنيفات فقط" : "Subjects Only" },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setDepthFilter(f.id)}
                    className={`px-3 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                      depthFilter === f.id
                        ? "bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40"
                        : "bg-[#0A0A0A] text-gray-400 border border-white/10 hover:text-white"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ========================================= */}
          {/* VIEW 1: INTERACTIVE HIERARCHY TREE VIEW */}
          {/* ========================================= */}
          {viewMode === "tree" && (
            <div className="space-y-4">
              {categoryTree.length > 0 ? (
                <div className="space-y-3">
                  {categoryTree.map((rootNode) => renderTreeNode(rootNode, 0))}
                </div>
              ) : (
                <div className="text-center py-16 px-4 rounded-3xl bg-[#151515] border border-white/10 space-y-3">
                  <FolderTree className="w-12 h-12 text-gray-600 mx-auto" />
                  <h4 className="text-base font-bold text-white">
                    {isAr ? "لا توجد أقسام مسجلة حتى الآن" : "No categories yet"}
                  </h4>
                  <p className="text-xs text-gray-400 max-w-sm mx-auto">
                    {isAr
                      ? "يمكنك البدء بإنشاء قسم رئيسي جديد أو استيراد الهيكل النموذجي (طلاب / مبرمجين / مصممين) بضغطة واحدة."
                      : "Create your first category or import the default hierarchical blueprint."}
                  </p>
                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => openCategoryModal()}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-[#D4AF37] text-black hover:brightness-110"
                    >
                      {isAr ? "إضافة قسم رئيسي" : "Add Main Category"}
                    </button>
                    <button
                      onClick={() => setIsSeedModalOpen(true)}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-[#1A1A1A] border border-white/10 text-white hover:bg-white/10"
                    >
                      {isAr ? "استيراد الهيكل النموذجي" : "Import Blueprint"}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================= */}
          {/* VIEW 2: ORGANIZED TABLE LIST VIEW */}
          {/* ========================================= */}
          {viewMode === "table" && (
            <div className="rounded-2xl border border-white/10 overflow-hidden bg-[#151515] shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#0A0A0A] text-gray-400 border-b border-white/10 uppercase tracking-wider">
                    <tr>
                      <th className="p-3.5">{isAr ? "القسم / المادة" : "Category / Subject"}</th>
                      <th className="p-3.5">{isAr ? "المسار الهرمي (Ancestry Path)" : "Hierarchy Path"}</th>
                      <th className="p-3.5">{isAr ? "المستوى" : "Depth"}</th>
                      <th className="p-3.5">{isAr ? "الكورسات" : "Courses"}</th>
                      <th className="p-3.5">{isAr ? "الحالة" : "Status"}</th>
                      <th className="p-3.5 text-center">{isAr ? "إجراءات" : "Actions"}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-gray-300">
                    {filteredCategories.map((cat) => {
                      const IconComp = CATEGORY_ICONS[cat.icon || "GraduationCap"] || GraduationCap;
                      const ancestry = getCategoryAncestry(cat.id, categories);
                      const depth = ancestry.length - 1;
                      const depthInfo = getDepthBadgeInfo(depth, isAr);
                      const linkedCourses = courses.filter((c) =>
                        isCourseInSelectedCategory(c, cat.id, categories)
                      );

                      return (
                        <tr key={cat.id} className="hover:bg-white/5 transition">
                          <td className="p-3.5">
                            <div className="flex items-center gap-2.5">
                              <div className="w-7 h-7 rounded-lg bg-[#0A0A0A] border border-white/10 flex items-center justify-center text-[#D4AF37]">
                                <IconComp className="w-3.5 h-3.5" />
                              </div>
                              <div>
                                <p className="font-bold text-white">{cat.name}</p>
                                {cat.nameEn && (
                                  <p className="text-[10px] text-gray-400 font-mono">
                                    {cat.nameEn}
                                  </p>
                                )}
                              </div>
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="flex items-center gap-1.5 text-[11px] text-gray-300 flex-wrap">
                              {ancestry.map((anc, idx) => (
                                <React.Fragment key={anc.id}>
                                  <span
                                    className={
                                      idx === ancestry.length - 1
                                        ? "font-bold text-[#D4AF37]"
                                        : "text-gray-400"
                                    }
                                  >
                                    {anc.name}
                                  </span>
                                  {idx < ancestry.length - 1 && (
                                    <span className="text-gray-600">←</span>
                                  )}
                                </React.Fragment>
                              ))}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${depthInfo.colorClass}`}>
                              {depthInfo.label}
                            </span>
                          </td>

                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#0A0A0A] text-gray-200 border border-white/10">
                              {linkedCourses.length} {isAr ? "كورس" : "courses"}
                            </span>
                          </td>

                          <td className="p-3.5">
                            <button
                              onClick={() => toggleCategoryActive(cat.id, !cat.active)}
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold border cursor-pointer ${
                                cat.active
                                  ? "bg-emerald-950/40 text-emerald-300 border-emerald-500/30"
                                  : "bg-red-950/40 text-red-300 border-red-500/30"
                              }`}
                            >
                              {cat.active ? (isAr ? "فعال" : "Active") : (isAr ? "معطل" : "Inactive")}
                            </button>
                          </td>

                          <td className="p-3.5">
                            <div className="flex items-center justify-center gap-1.5">
                              {depth < 2 && (
                                <button
                                  onClick={() => openCategoryModal(undefined, cat.id)}
                                  className="p-1.5 rounded-lg bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 text-gray-300 hover:text-white cursor-pointer"
                                  title={isAr ? "إضافة فرع تحته" : "Add Child"}
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button
                                onClick={() => openCategoryModal(cat)}
                                className="p-1.5 rounded-lg bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 text-[#D4AF37] cursor-pointer"
                                title={isAr ? "تعديل" : "Edit"}
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => openDeleteCategoryModal(cat)}
                                className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/80 text-red-400 border border-red-500/20 cursor-pointer"
                                title={isAr ? "حذف" : "Delete"}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 2: COURSE LEVELS MANAGEMENT */}
      {/* ========================================================================= */}
      {subTab === "levels" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151515] border border-white/10 shadow-lg">
            <div className="relative w-72">
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={lvlSearch}
                onChange={(e) => setLvlSearch(e.target.value)}
                placeholder={isAr ? "بحث في المستويات..." : "Search levels..."}
                className="w-full pr-10 pl-4 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <button
              onClick={() => openLevelModal()}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white flex items-center gap-1.5 transition cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? "إضافة مستوى جديد" : "Add Level"}</span>
            </button>
          </div>

          <div className="space-y-2.5">
            {filteredLevels.map((lvl, index) => {
              const linkedCourses = courses.filter((c) => c.level === lvl.name);

              return (
                <div
                  key={lvl.id}
                  className="p-4 rounded-2xl bg-[#151515] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm hover:border-[#D4AF37]/40 transition"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#0A0A0A] border border-white/10 flex items-center justify-center text-xs font-bold text-[#D4AF37]">
                      {index + 1}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white">{lvl.name}</h4>
                        {lvl.nameEn && (
                          <span className="text-xs text-gray-400 font-mono">({lvl.nameEn})</span>
                        )}
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#0A0A0A] text-gray-300 border border-white/10">
                          {linkedCourses.length} {isAr ? "كورس" : "courses"}
                        </span>
                      </div>
                      {lvl.description && (
                        <p className="text-xs text-gray-400 mt-0.5">{lvl.description}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {/* Move Up / Down */}
                    <div className="flex items-center rounded-lg bg-[#0A0A0A] border border-white/10 overflow-hidden">
                      <button
                        onClick={() => handleMoveLevel(lvl.id, "up")}
                        className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
                        title={isAr ? "تحريك لأعلى" : "Move Up"}
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveLevel(lvl.id, "down")}
                        className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer border-r border-white/10"
                        title={isAr ? "تحريك لأسفل" : "Move Down"}
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Toggle Active */}
                    <button
                      onClick={() => toggleLevelActive(lvl.id, !lvl.active)}
                      className={`p-1.5 rounded-lg border transition cursor-pointer ${
                        lvl.active
                          ? "bg-emerald-950/40 text-emerald-400 border-emerald-500/30"
                          : "bg-red-950/40 text-red-400 border-red-500/30"
                      }`}
                      title={lvl.active ? (isAr ? "فعال" : "Active") : (isAr ? "معطل" : "Inactive")}
                    >
                      {lvl.active ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                    </button>

                    {/* Edit */}
                    <button
                      onClick={() => openLevelModal(lvl)}
                      className="p-1.5 rounded-lg bg-[#0A0A0A] text-[#D4AF37] border border-white/10 hover:bg-white/10 transition cursor-pointer"
                      title={isAr ? "تعديل" : "Edit"}
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => openDeleteLevelModal(lvl)}
                      className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/80 text-red-400 border border-red-500/20 hover:border-red-500/40 transition cursor-pointer"
                      title={isAr ? "حذف" : "Delete"}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT CATEGORY */}
      {/* ========================================================================= */}
      {isCatModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setIsCatModalOpen(false)}
        >
          <div
            className="w-full max-w-xl bg-[#151515] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto text-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <FolderPlus className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="text-base font-bold text-white">
                  {editingCat
                    ? isAr
                      ? `تعديل قسم: «${editingCat.name}»`
                      : "Edit Category"
                    : isAr
                    ? "إضافة قسم أو تصنيف هرمي جديد"
                    : "New Category"}
                </h3>
              </div>
              <button
                onClick={() => setIsCatModalOpen(false)}
                className="text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-4 text-xs sm:text-sm">
              {/* Category Hierarchy Level (Parent Selector) */}
              <div className="p-3.5 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 space-y-2">
                <label className="block text-gray-200 font-bold text-xs">
                  {isAr ? "القسم الأب / المستوى الهرمي" : "Parent Category"}
                </label>
                <select
                  value={catForm.parentId || ""}
                  onChange={(e) =>
                    setCatForm({ ...catForm, parentId: e.target.value ? e.target.value : null })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#151515] border border-white/15 text-white focus:outline-none focus:border-[#D4AF37]/50"
                >
                  <option value="">
                    {isAr
                      ? "⭐ قسم رئيسي (المستوى الأول - بدون أب)"
                      : "⭐ Root / Main Category (Level 1)"}
                  </option>
                  {/* Indented parent options */}
                  {categories
                    .filter((c) => !editingCat || c.id !== editingCat.id)
                    .map((c) => {
                      const ancestry = getCategoryAncestry(c.id, categories);
                      const indent = "— ".repeat(ancestry.length - 1);
                      return (
                        <option key={c.id} value={c.id}>
                          {indent}
                          {c.name} {c.nameEn ? `(${c.nameEn})` : ""}
                        </option>
                      );
                    })}
                </select>
                <p className="text-[11px] text-gray-400">
                  {catForm.parentId
                    ? isAr
                      ? `سيكون هذا العنصر فرعاً تابعاً لـ «${
                          categories.find((c) => c.id === catForm.parentId)?.name || ""
                        }»`
                      : "This item will be created as a child under the selected category."
                    : isAr
                    ? "سيكون هذا قسماً رئيسياً كبيراً في أعلى الهيكل."
                    : "This will be a top-level main category."}
                </p>
              </div>

              {/* Names AR / EN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1 text-xs">
                    {isAr ? "الاسم بالعربية (مطلوب)" : "Arabic Name (Required)"} *
                  </label>
                  <input
                    type="text"
                    required
                    value={catForm.name}
                    onChange={(e) => setCatForm({ ...catForm, name: e.target.value })}
                    placeholder={isAr ? "مثال: طلاب / كيمياء / برمجة الويب" : "Category name"}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 font-semibold mb-1 text-xs">
                    {isAr ? "الاسم بالإنجليزية (اختياري)" : "English Name (Optional)"}
                  </label>
                  <input
                    type="text"
                    value={catForm.nameEn}
                    onChange={(e) => setCatForm({ ...catForm, nameEn: e.target.value })}
                    placeholder={isAr ? "مثال: Students / Chemistry / Web Dev" : "English name"}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-gray-300 font-semibold mb-1 text-xs">
                  {isAr ? "الوصف التعريفي" : "Description"}
                </label>
                <textarea
                  rows={2}
                  value={catForm.description}
                  onChange={(e) => setCatForm({ ...catForm, description: e.target.value })}
                  placeholder={
                    isAr
                      ? "نبذة موجزة عن هذا القسم وما يحتويه من مواد وكورسات..."
                      : "Brief description..."
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                />
              </div>

              {/* Icon Picker */}
              <div>
                <label className="block text-gray-300 font-semibold mb-1.5 text-xs">
                  {isAr ? "اختر أيقونة مناسبة للقسم" : "Category Icon"}
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 p-2 rounded-2xl bg-[#0A0A0A] border border-white/10 max-h-36 overflow-y-auto">
                  {Object.keys(CATEGORY_ICONS).map((iconKey) => {
                    const IconComp = CATEGORY_ICONS[iconKey];
                    const isSelected = catForm.icon === iconKey;
                    return (
                      <button
                        key={iconKey}
                        type="button"
                        onClick={() => setCatForm({ ...catForm, icon: iconKey })}
                        className={`p-2 rounded-xl flex flex-col items-center justify-center gap-1 border transition cursor-pointer ${
                          isSelected
                            ? "bg-[#D4AF37]/20 border-[#D4AF37] text-[#D4AF37] shadow-sm"
                            : "bg-[#151515] border-white/5 text-gray-400 hover:text-white hover:border-white/20"
                        }`}
                      >
                        <IconComp className="w-4 h-4" />
                        <span className="text-[9px] truncate max-w-full font-mono">{iconKey}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Order & Status */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1.5 text-xs">
                    {isAr ? "ترتيب العرض" : "Display Order"}
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={catForm.order}
                    onChange={(e) => setCatForm({ ...catForm, order: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 font-semibold mb-1.5 text-xs">
                    {isAr ? "حالة القسم" : "Status"}
                  </label>
                  <select
                    value={catForm.active ? "active" : "inactive"}
                    onChange={(e) =>
                      setCatForm({ ...catForm, active: e.target.value === "active" })
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                  >
                    <option value="active">{isAr ? "فعال (يظهر للجمهور)" : "Active"}</option>
                    <option value="inactive">{isAr ? "معطل (مخفي مؤقتاً)" : "Inactive"}</option>
                  </select>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-lg shadow-[#D4AF37]/20 transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>{isAr ? "حفظ القسم" : "Save Category"}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCatModalOpen(false)}
                  className="px-5 py-3 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] border border-white/10 hover:bg-white/5 transition cursor-pointer"
                >
                  {isAr ? "إلغاء" : "Cancel"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DELETE CATEGORY CONFIRMATION & SAFE REASSIGNMENT */}
      {/* ========================================================================= */}
      {catToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setCatToDelete(null)}
        >
          <div
            className="w-full max-w-md bg-[#151515] border border-red-500/30 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl text-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">
                {isAr ? "تأكيد حذف القسم" : "Confirm Category Deletion"}
              </h3>
              <p className="text-xs text-gray-400">
                {isAr
                  ? `هل أنت متأكد من رغبتك في حذف قسم «${catToDelete.name}»؟`
                  : `Are you sure you want to delete "${catToDelete.name}"?`}
              </p>
            </div>

            {/* Child categories and linked courses safety check */}
            {(() => {
              const directChildren = categories.filter((c) => c.parentId === catToDelete.id);
              const linkedCourses = courses.filter((c) =>
                isCourseInSelectedCategory(c, catToDelete.id, categories)
              );
              const otherCategories = categories.filter((c) => c.id !== catToDelete.id);

              return (
                <div className="space-y-3">
                  {directChildren.length > 0 && (
                    <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200 space-y-1">
                      <p className="font-bold flex items-center gap-1">
                        <Info className="w-4 h-4 text-amber-400 flex-shrink-0" />
                        <span>
                          {isAr
                            ? `يوجد (${directChildren.length}) أقسام فرعية تابعة لهذا القسم:`
                            : `There are (${directChildren.length}) child categories:`}
                        </span>
                      </p>
                      <p className="text-[11px] text-gray-300">
                        {directChildren.map((c) => c.name).join("، ")}
                      </p>
                      <p className="text-[10px] text-amber-400">
                        {isAr
                          ? "سيتم ترقية الأقسام الفرعية تلقائياً إلى المستوى الأعلى أو المستوى الرئيسي حتى لا تُفقد."
                          : "Child categories will be moved to the parent level safely."}
                      </p>
                    </div>
                  )}

                  {linkedCourses.length > 0 ? (
                    <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/30 space-y-3">
                      <div className="flex items-start gap-2 text-xs text-red-200">
                        <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold">
                            {isAr
                              ? `تحذير: يوجد عدد (${linkedCourses.length}) كورس مرتبط بهذا القسم أو فروعه!`
                              : `Warning: ${linkedCourses.length} courses are linked to this category!`}
                          </p>
                          <p className="text-[11px] text-gray-300 mt-0.5">
                            {linkedCourses
                              .map((c) => c.title)
                              .slice(0, 3)
                              .join("، ")}
                            {linkedCourses.length > 3 ? "..." : ""}
                          </p>
                        </div>
                      </div>

                      {otherCategories.length > 0 && (
                        <div className="space-y-1">
                          <label className="block text-[11px] font-semibold text-gray-200">
                            {isAr
                              ? "اختر قسماً بديلاً لنقل هذه الكورسات إليه تلقائياً:"
                              : "Select a replacement category for linked courses:"}
                          </label>
                          <select
                            value={catReplacement}
                            onChange={(e) => setCatReplacement(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white focus:outline-none focus:border-[#D4AF37]/50"
                          >
                            {otherCategories.map((c) => (
                              <option key={c.id} value={c.name}>
                                {c.name} {c.nameEn ? `(${c.nameEn})` : ""}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>{isAr ? "لا توجد كورسات مرتبطة بهذا القسم حالياً." : "No courses linked to this category."}</span>
                    </div>
                  )}
                </div>
              );
            })()}

            <div className="flex items-center gap-3 pt-2">
              <button
                disabled={isDeletingCat}
                onClick={handleConfirmDeleteCategory}
                className="flex-1 py-2.5 rounded-xl font-bold text-white bg-red-600 hover:bg-red-500 transition cursor-pointer shadow-lg shadow-red-600/20 disabled:opacity-50 text-xs"
              >
                {isDeletingCat
                  ? isAr
                    ? "جارٍ الحذف..."
                    : "Deleting..."
                  : isAr
                  ? "تأكيد الحذف الآمن"
                  : "Delete"}
              </button>
              <button
                disabled={isDeletingCat}
                onClick={() => setCatToDelete(null)}
                className="px-4 py-2.5 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] border border-white/10 hover:bg-white/5 transition cursor-pointer text-xs"
              >
                {isAr ? "إلغاء" : "Cancel"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: SEED DEFAULT TEMPLATE CONFIRMATION */}
      {/* ========================================================================= */}
      {isSeedModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setIsSeedModalOpen(false)}
        >
          <div
            className="w-full max-w-md bg-[#151515] border border-amber-500/30 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl text-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-[#D4AF37] flex items-center justify-center mx-auto">
              <RefreshCw className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">
                {isAr ? "استيراد الهيكل التعليمي النموذجي" : "Import Default Category Blueprint"}
              </h3>
              <p className="text-xs text-gray-400">
                {isAr
                  ? "سيتم استيراد هيكل الأقسام الثلاثي الكامل لمنصة اتعلم ببساطة:"
                  : "Will import standard multi-tier category hierarchy:"}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 text-xs text-gray-300 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <GraduationCap className="w-4 h-4" />
                <span>طلاب (ابتدائي ← إعدادي ← ثانوي ← مواد الكيمياء والفيزياء والرياضيات)</span>
              </div>
              <div className="flex items-center gap-2 text-blue-400 font-bold">
                <Code className="w-4 h-4" />
                <span>مبرمجين (برمجة الويب ← بايثون والبيانات ← الذكاء الاصطناعي)</span>
              </div>
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Palette className="w-4 h-4" />
                <span>مصممين (التصميم الرقمي وواجهات وتجربة المستخدم Figma)</span>
              </div>
            </div>

            <p className="text-[11px] text-gray-400">
              {isAr
                ? "ملاحظة: لن يتم حذف أي كورس موجود، بل سيتم تحديث وتجهيز الأقسام في قاعدة البيانات."
                : "Note: No existing courses will be deleted."}
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                disabled={isSeeding}
                onClick={handleConfirmSeed}
                className="flex-1 py-2.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 transition cursor-pointer shadow-lg shadow-[#D4AF37]/20 disabled:opacity-50 text-xs flex items-center justify-center gap-2"
              >
                {isSeeding ? (
                  <span>{isAr ? "جارٍ الاستيراد..." : "Importing..."}</span>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>{isAr ? "تأكيد الاستيراد الآن" : "Confirm Import"}</span>
                  </>
                )}
              </button>
              <button
                disabled={isSeeding}
                onClick={() => setIsSeedModalOpen(false)}
                className="px-4 py-2.5 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] border border-white/10 hover:bg-white/5 transition cursor-pointer text-xs"
              >
                {isAr ? "إلغاء" : "Cancel"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT LEVEL */}
      {/* ========================================================================= */}
      {isLvlModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setIsLvlModalOpen(false)}
        >
          <div
            className="w-full max-w-md bg-[#151515] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl text-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-bold text-white">
                {editingLvl ? (isAr ? "تعديل المستوى" : "Edit Level") : (isAr ? "إضافة مستوى جديد" : "New Level")}
              </h3>
              <button onClick={() => setIsLvlModalOpen(false)} className="text-gray-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLevel} className="space-y-3.5 text-xs sm:text-sm">
              <div>
                <label className="block text-gray-300 font-semibold mb-1 text-xs">
                  {isAr ? "اسم المستوى (عربي)" : "Level Name (Arabic)"} *
                </label>
                <input
                  type="text"
                  required
                  value={lvlForm.name}
                  onChange={(e) => setLvlForm({ ...lvlForm, name: e.target.value })}
                  placeholder={isAr ? "مثال: مبتدئ / متوسط / متقدم / محترف" : "Level name"}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1 text-xs">
                  {isAr ? "الاسم بالإنجليزية" : "English Name"}
                </label>
                <input
                  type="text"
                  value={lvlForm.nameEn}
                  onChange={(e) => setLvlForm({ ...lvlForm, nameEn: e.target.value })}
                  placeholder={isAr ? "مثال: Beginner / Intermediate" : "English name"}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1 text-xs">
                  {isAr ? "الوصف" : "Description"}
                </label>
                <textarea
                  rows={2}
                  value={lvlForm.description}
                  onChange={(e) => setLvlForm({ ...lvlForm, description: e.target.value })}
                  placeholder={isAr ? "شرح موجز للفئة المستهدفة من هذا المستوى..." : "Level description"}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1.5 text-xs">
                    {isAr ? "ترتيب العرض" : "Display Order"}
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={lvlForm.order}
                    onChange={(e) => setLvlForm({ ...lvlForm, order: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 font-semibold mb-1.5 text-xs">
                    {isAr ? "الحالة" : "Status"}
                  </label>
                  <select
                    value={lvlForm.active ? "active" : "inactive"}
                    onChange={(e) => setLvlForm({ ...lvlForm, active: e.target.value === "active" })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
                  >
                    <option value="active">{isAr ? "فعال" : "Active"}</option>
                    <option value="inactive">{isAr ? "غير فعال" : "Inactive"}</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-lg shadow-[#D4AF37]/20 transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>{isAr ? "حفظ المستوى" : "Save Level"}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsLvlModalOpen(false)}
                  className="px-5 py-3 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] border border-white/10 hover:bg-white/5 transition cursor-pointer"
                >
                  {isAr ? "إلغاء" : "Cancel"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DELETE LEVEL CONFIRMATION */}
      {/* ========================================================================= */}
      {lvlToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setLvlToDelete(null)}
        >
          <div
            className="w-full max-w-md bg-[#151515] border border-red-500/30 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl text-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">
                {isAr ? "تأكيد حذف المستوى" : "Confirm Level Deletion"}
              </h3>
              <p className="text-xs text-gray-400">
                {isAr
                  ? `هل أنت متأكد من رغبتك في حذف مستوى «${lvlToDelete.name}»؟`
                  : `Are you sure you want to delete "${lvlToDelete.name}"?`}
              </p>
            </div>

            {/* Linked courses check */}
            {(() => {
              const linked = courses.filter((c) => c.level === lvlToDelete.name);
              const otherLevels = levels.filter((l) => l.id !== lvlToDelete.id);

              if (linked.length > 0) {
                return (
                  <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/30 space-y-3">
                    <div className="flex items-start gap-2 text-xs text-red-200">
                      <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold">
                          {isAr
                            ? `تحذير: يوجد عدد (${linked.length}) كورس مرتبط بهذا المستوى!`
                            : `Warning: ${linked.length} courses are linked to this level!`}
                        </p>
                        <p className="text-[11px] text-gray-300 mt-0.5">
                          {isAr
                            ? "الكورسات: " +
                              linked
                                .map((c) => c.title)
                                .slice(0, 3)
                                .join("، ") +
                              (linked.length > 3 ? "..." : "")
                            : linked.map((c) => c.title).join(", ")}
                        </p>
                      </div>
                    </div>

                    {otherLevels.length > 0 && (
                      <div className="space-y-1">
                        <label className="block text-[11px] font-semibold text-gray-200">
                          {isAr
                            ? "اختر مستوى بديلاً لنقل هذه الكورسات إليه تلقائياً:"
                            : "Select a replacement level for linked courses:"}
                        </label>
                        <select
                          value={lvlReplacement}
                          onChange={(e) => setLvlReplacement(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white focus:outline-none focus:border-[#D4AF37]/50"
                        >
                          {otherLevels.map((l) => (
                            <option key={l.id} value={l.name}>
                              {l.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>
                );
              }
              return (
                <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>{isAr ? "لا توجد كورسات مرتبطة بهذا المستوى حالياً." : "No courses linked to this level."}</span>
                </div>
              );
            })()}

            <div className="flex items-center gap-3 pt-2">
              <button
                disabled={isDeletingLvl}
                onClick={handleConfirmDeleteLevel}
                className="flex-1 py-2.5 rounded-xl font-bold text-white bg-red-600 hover:bg-red-500 transition cursor-pointer shadow-lg shadow-red-600/20 disabled:opacity-50 text-xs"
              >
                {isDeletingLvl
                  ? isAr
                    ? "جارٍ الحذف..."
                    : "Deleting..."
                  : isAr
                  ? "تأكيد الحذف"
                  : "Delete"}
              </button>
              <button
                disabled={isDeletingLvl}
                onClick={() => setLvlToDelete(null)}
                className="px-4 py-2.5 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] border border-white/10 hover:bg-white/5 transition cursor-pointer text-xs"
              >
                {isAr ? "إلغاء" : "Cancel"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
