import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import {
  Sparkles,
  Send,
  Loader2,
  Bot,
  User,
  BookOpen,
  Code,
  Lightbulb,
  Zap,
  HelpCircle,
} from "lucide-react";

interface Message {
  role: "user" | "assistant";
  text: string;
  timestamp: string;
}

export const AiAssistantModal: React.FC = () => {
  const { language, courses } = useApp();
  const isAr = language === "ar";

  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      text: isAr
        ? "مرحباً بك! أنا مساعد «اتعلم ببساطة» الذكي، مدعوم بأحدث نماذج Gemini AI. كيف يمكنني مساعدتك اليوم في رحلتك التعليمية؟ يمكنك سؤالي عن البرمجة، خريطة طريق مقترحة، شرح مفهوم تقني، أو حتى حل مشكلة برمجية."
        : "Hello! I am your Learn Simply AI Tutor. How can I help you master coding, AI, or system design today?",
      timestamp: new Date().toLocaleTimeString(isAr ? "ar-EG" : "en-US", { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const quickPrompts = [
    {
      label: isAr ? "🚀 خارطة طريق لتعلم الويب 2026" : "Web Dev Roadmap",
      prompt: isAr ? "ما هي خارطة الطريق العملية لتعلم تطوير الويب من الصفر حتى احتراف بناء التطبيقات؟" : "What is the complete roadmap to learn web development in 2026?",
    },
    {
      label: isAr ? "💡 شرح مبسط للـ Async/Await في JS" : "Explain Async/Await",
      prompt: isAr ? "اشرح لي مفهوم Async / Await في الجافاسكربت بمثال واقعي وبسيط جداً." : "Explain JavaScript async/await with a simple real-world analogy.",
    },
    {
      label: isAr ? "🤖 كيف أبدأ في الذكاء الاصطناعي؟" : "Getting Started with AI",
      prompt: isAr ? "كيف أبدأ في استخدام نماذج الذكاء الاصطناعي ودمج Gemini API في موقعي؟" : "How do I integrate Gemini API into a modern web app?",
    },
    {
      label: isAr ? "📱 ما الفرق بين Frontend و Backend؟" : "Frontend vs Backend",
      prompt: isAr ? "ما هو الفرق بين الواجهات الأمامية والخلفية وكيف يتكاملان؟" : "What is the difference between frontend and backend?",
    },
  ];

  const handleSend = async (customPrompt?: string) => {
    const textToSend = (customPrompt || input).trim();
    if (!textToSend || loading) return;

    const userMsg: Message = {
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString(isAr ? "ar-EG" : "en-US", { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          userPrompt: textToSend,
          language,
        }),
      });

      const data = await res.json();
      const assistantMsg: Message = {
        role: "assistant",
        text: data.reply || (isAr ? "عذراً، لم أستطع توليد إجابة حالياً." : "Sorry, could not generate a response."),
        timestamp: new Date().toLocaleTimeString(isAr ? "ar-EG" : "en-US", { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: isAr
            ? "تعذر الاتصال بالخادم الذكي. يرجى التأكد من اتصال الإنترنت والمحاولة ثانية."
            : "Network error connecting to AI.",
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="p-6 rounded-3xl bg-[#151515] border border-white/10 text-center space-y-3 shadow-xl">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] mx-auto flex items-center justify-center text-white font-bold shadow-xl shadow-[#D4AF37]/25">
          <Sparkles className="w-7 h-7" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white">
          {isAr ? "مساعد «اتعلم ببساطة» الذكي" : "AI Smart Tutor"}
        </h1>
        <p className="text-xs sm:text-sm text-gray-300 max-w-xl mx-auto">
          {isAr
            ? "شريكك الشخصي في التعلم، مدعوم بنماذج Gemini المتقدمة للإجابة على أسئلتك البرمجية والتقنية في أي وقت."
            : "Your 24/7 personal coding mentor powered by Gemini AI."}
        </p>

        {/* Quick Suggestion Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(qp.prompt)}
              className="px-3 py-1.5 rounded-xl bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 hover:border-[#D4AF37]/40 text-xs text-gray-300 hover:text-[#D4AF37] transition cursor-pointer"
            >
              {qp.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="rounded-3xl bg-[#151515] border border-white/10 p-4 sm:p-6 space-y-4 min-h-[420px] max-h-[550px] overflow-y-auto flex flex-col justify-between shadow-xl">
        <div className="space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-3 ${
                m.role === "user" ? "flex-row-reverse" : "flex-row"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                  m.role === "user"
                    ? "bg-blue-600 text-white"
                    : "bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30"
                }`}
              >
                {m.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed max-w-[82%] whitespace-pre-line space-y-1 ${
                  m.role === "user"
                    ? "bg-blue-600/20 text-blue-100 border border-blue-500/30 text-right"
                    : "bg-[#0A0A0A] text-gray-200 border border-white/10 text-right"
                }`}
              >
                <p>{m.text}</p>
                <span className="block text-[10px] text-gray-500 text-left font-mono">
                  {m.timestamp}
                </span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 flex items-center gap-2 text-xs text-[#D4AF37]">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{isAr ? "المساعد الذكي يفكر ويصيغ الإجابة..." : "AI Tutor is typing..."}</span>
              </div>
            </div>
          )}
        </div>

        {/* Chat Input Field */}
        <div className="relative pt-4 border-t border-white/10">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder={
              isAr
                ? "اكتب سؤالك البرمجي هنا (مثال: كيف أربط React بقاعدة بيانات؟)..."
                : "Ask any programming question..."
            }
            className="w-full pr-4 pl-12 py-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 text-xs sm:text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/60 transition shadow-inner"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 mt-2 p-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white disabled:opacity-40 transition cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
