import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import {
  X,
  GraduationCap,
  LogIn,
  UserPlus,
  Mail,
  Lock,
  User,
  Phone,
  AlertCircle,
} from "lucide-react";

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    authModalMode,
    setAuthModalMode,
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    language,
  } = useApp();

  const isAr = language === "ar";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setLoading(true);

    try {
      if (authModalMode === "login") {
        await loginWithEmail(email, password);
      } else {
        if (!name.trim()) {
          setErrorMsg(isAr ? "يرجى كتابة الاسم بالكامل" : "Please enter your full name");
          setLoading(false);
          return;
        }
        await registerWithEmail(email, password, name, phone);
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      const code = err.code || "";
      if (code === "auth/user-not-found" || code === "auth/wrong-password" || code === "auth/invalid-credential") {
        setErrorMsg(isAr ? "البريد الإلكتروني أو كلمة المرور غير صحيحة" : "Invalid email or password");
      } else if (code === "auth/email-already-in-use") {
        setErrorMsg(isAr ? "هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول بدلاً من ذلك" : "Email already in use, please sign in");
      } else if (code === "auth/weak-password") {
        setErrorMsg(isAr ? "كلمة المرور ضعيفة، يجب أن تكون 6 أحرف أو أرقام على الأقل" : "Password must be at least 6 characters");
      } else if (code === "auth/invalid-email") {
        setErrorMsg(isAr ? "صيغة البريد الإلكتروني غير صحيحة" : "Invalid email format");
      } else if (code === "auth/operation-not-allowed") {
        setErrorMsg(
          isAr
            ? "مزود تسجيل الدخول هذا غير مفعل بعد في مشروع Firebase، يرجى تفعيله من Firebase Console."
            : "Sign-in provider is disabled in Firebase Console."
        );
      } else {
        setErrorMsg(err.message || (isAr ? "حدث خطأ أثناء المصادقة" : "Authentication error"));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMsg("");
    setLoading(true);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      console.error("Google sign in error:", err);
      const code = err.code || "";
      if (code === "auth/popup-closed-by-user") {
        setErrorMsg(isAr ? "تم إغلاق نافذة تسجيل الدخول قبل اكتمال العملية" : "Popup closed by user");
      } else if (code === "auth/popup-blocked") {
        setErrorMsg(isAr ? "تم حظر النافذة المنبثقة من قبل المتصفح، يرجى السماح بالنوافذ المنبثقة" : "Popup blocked by browser");
      } else if (code === "auth/unauthorized-domain") {
        setErrorMsg(isAr ? "هذا النطاق غير مصرح به في Firebase Console > Authentication > Settings" : "Unauthorized domain in Firebase Console");
      } else if (code === "auth/operation-not-allowed") {
        setErrorMsg(isAr ? "تسجيل الدخول عبر Google غير مفعل في Firebase Console" : "Google Sign-In is disabled in Firebase Console");
      } else {
        setErrorMsg(err.message || (isAr ? "فشل تسجيل الدخول عبر Google" : "Google sign in failed"));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      id="auth-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={() => setIsAuthModalOpen(false)}
    >
      <div
        id="auth-modal-container"
        className="w-full max-w-md bg-[#151515] border border-white/10 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="auth-modal-close-btn"
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-4 left-4 sm:top-5 sm:left-5 p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#B8860B] mx-auto flex items-center justify-center text-white font-black shadow-lg shadow-[#D4AF37]/20">
            <GraduationCap className="w-7 h-7" />
          </div>

          <h3 className="text-xl sm:text-2xl font-bold text-white">
            {authModalMode === "login"
              ? isAr
                ? "تسجيل الدخول إلى حسابك"
                : "Welcome Back"
              : isAr
              ? "إنشاء حساب طالب جديد"
              : "Create a Student Account"}
          </h3>
          <p className="text-xs text-gray-400">
            {authModalMode === "login"
              ? isAr
                ? "تابع كورساتك ودروسك والمدفوعات الخاصة بك"
                : "Access your enrolled courses and receipts"
              : isAr
              ? "انضم الآن إلى مجتمع اتعلم ببساطة"
              : "Start learning in minutes"}
          </p>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Google One-Click Button */}
        <button
          id="google-signin-btn"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full py-2.5 px-4 rounded-xl border border-white/10 bg-[#0A0A0A] hover:bg-[#1A1A1A] text-gray-200 hover:text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-3 transition cursor-pointer"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#EA4335"
              d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.4 1 3.6 3.6 1.8 7.4l3.7 2.9C6.4 7.4 8.9 5 12 5z"
            />
            <path
              fill="#4285F4"
              d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
            />
            <path
              fill="#FBBC05"
              d="M5.5 14.7c-.2-.7-.4-1.5-.4-2.4s.2-1.7.4-2.4L1.8 7c-.8 1.6-1.3 3.4-1.3 5.3s.5 3.7 1.3 5.3l3.7-2.9z"
            />
            <path
              fill="#34A853"
              d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.6-2.1-6.5-5.1L1.8 16.1C3.6 19.9 7.4 23 12 23z"
            />
          </svg>
          <span>{isAr ? "الدخول السريع عبر Google" : "Continue with Google"}</span>
        </button>

        <div className="relative flex items-center justify-center">
          <div className="border-t border-white/10 w-full"></div>
          <span className="bg-[#151515] px-3 text-[11px] text-gray-500 font-semibold uppercase">
            {isAr ? "أو بالبريد الإلكتروني" : "Or with email"}
          </span>
        </div>

        {/* Email & Password Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs sm:text-sm">
          {authModalMode === "register" && (
            <>
              <div>
                <label className="block text-gray-300 font-semibold mb-1 text-xs">
                  {isAr ? "الاسم الكامل" : "Full Name"}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-gray-500 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={isAr ? "مثال: أحمد محمد" : "e.g. Ahmed Mohamed"}
                    className="w-full pr-9 pl-3 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1 text-xs">
                  {isAr ? "رقم الهاتف / محفظة الكاش (اختياري)" : "Phone Number (Optional)"}
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-500 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="011XXXXXXXX"
                    className="w-full pr-9 pl-3 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-gray-300 font-semibold mb-1 text-xs">
              {isAr ? "البريد الإلكتروني" : "Email Address"}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-gray-500 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pr-9 pl-3 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-1 text-xs">
              {isAr ? "كلمة المرور" : "Password"}
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-500 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pr-9 pl-3 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-lg shadow-[#D4AF37]/20 transition flex items-center justify-center gap-2 mt-4 cursor-pointer"
          >
            {loading ? (
              <span className="animate-spin">⏳</span>
            ) : authModalMode === "login" ? (
              <>
                <LogIn className="w-4 h-4" />
                <span>{isAr ? "تسجيل الدخول" : "Sign In"}</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>{isAr ? "إنشاء الحساب" : "Create Account"}</span>
              </>
            )}
          </button>
        </form>

        {/* Toggle between Login and Register */}
        <div className="text-center text-xs text-gray-400 pt-2 border-t border-white/10">
          {authModalMode === "login" ? (
            <p>
              {isAr ? "ليس لديك حساب بعد؟" : "Don't have an account?"}{" "}
              <button
                type="button"
                onClick={() => setAuthModalMode("register")}
                className="text-[#D4AF37] font-bold hover:underline cursor-pointer"
              >
                {isAr ? "سجل كطالب جديد الآن" : "Register now"}
              </button>
            </p>
          ) : (
            <p>
              {isAr ? "لديك حساب بالفعل؟" : "Already have an account?"}{" "}
              <button
                type="button"
                onClick={() => setAuthModalMode("login")}
                className="text-[#D4AF37] font-bold hover:underline cursor-pointer"
              >
                {isAr ? "تسجيل الدخول" : "Sign In"}
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
