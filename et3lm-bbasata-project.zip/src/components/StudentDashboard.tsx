import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import {
  User,
  BookOpen,
  CreditCard,
  CheckCircle2,
  Clock,
  AlertCircle,
  PlayCircle,
  Award,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Eye,
  LifeBuoy,
  MessageSquare,
  PlusCircle,
  Bot,
  Lock,
} from "lucide-react";
import { PaymentRequest } from "../types";

export const StudentDashboard: React.FC = () => {
  const {
    user,
    enrollments,
    myPayments,
    myTickets,
    courses,
    setSelectedCourse,
    setActiveView,
    language,
    setIsAuthModalOpen,
    setAuthModalMode,
  } = useApp();

  const isAr = language === "ar";
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 rounded-3xl bg-[#151515] border border-white/10 text-center space-y-4 shadow-xl">
        <User className="w-12 h-12 text-[#D4AF37] mx-auto" />
        <h3 className="text-xl font-bold text-white">
          {isAr ? "يرجى تسجيل الدخول للوصول إلى لوحتك" : "Please login to view dashboard"}
        </h3>
        <p className="text-xs text-gray-400">
          {isAr
            ? "تابع كورساتك المشترك بها وحالة طلبات الدفع وإيصالات التحويل وتذاكر الدعم."
            : "Access your enrolled tracks, payment verification status, and support tickets."}
        </p>
        <button
          onClick={() => {
            setAuthModalMode("login");
            setIsAuthModalOpen(true);
          }}
          className="w-full py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-lg shadow-[#D4AF37]/20 transition cursor-pointer"
        >
          {isAr ? "تسجيل الدخول" : "Sign In"}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Student Welcome Header Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#151515] border border-white/10 relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] flex items-center justify-center text-white font-black text-xl shadow-lg shadow-[#D4AF37]/20">
              {user.displayName ? user.displayName[0].toUpperCase() : "ط"}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-white">{user.displayName}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                  {user.role === "admin" ? (isAr ? "مشرف" : "Admin") : (isAr ? "طالب" : "Student")}
                </span>
              </div>
              <p className="text-xs text-gray-400">{user.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <button
              id="student-dashboard-support-btn"
              onClick={() => setActiveView("support")}
              className="px-4 py-2.5 rounded-xl font-bold text-xs bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-[#D4AF37] border border-[#D4AF37]/40 flex items-center gap-1.5 transition cursor-pointer shadow-sm"
            >
              <LifeBuoy className="w-4 h-4 text-[#D4AF37]" />
              <span>{isAr ? "تواصل معنا والدعم الفني" : "Help & Support"}</span>
            </button>

            <button
              onClick={() => setActiveView("courses")}
              className="px-4 py-2.5 rounded-xl font-bold text-xs bg-[#0A0A0A] hover:bg-[#1A1A1A] text-gray-200 hover:text-white border border-white/10 flex items-center gap-1.5 transition cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-[#D4AF37]" />
              <span>{isAr ? "تصفح كورسات جديدة" : "Explore Courses"}</span>
            </button>
          </div>
        </div>

        {/* Quick Stats bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 text-center">
          <div className="p-3 rounded-xl bg-[#0A0A0A] border border-white/10">
            <p className="text-lg font-bold text-[#D4AF37] font-mono">{enrollments.length}</p>
            <p className="text-[11px] text-gray-400">{isAr ? "الكورسات المشترك بها" : "Enrolled Courses"}</p>
          </div>
          <div className="p-3 rounded-xl bg-[#0A0A0A] border border-white/10">
            <p className="text-lg font-bold text-emerald-400 font-mono">
              {enrollments.filter((e) => e.progress === 100).length}
            </p>
            <p className="text-[11px] text-gray-400">{isAr ? "الكورسات المكتملة" : "Completed"}</p>
          </div>
          <div className="p-3 rounded-xl bg-[#0A0A0A] border border-white/10">
            <p className="text-lg font-bold text-blue-400 font-mono">{myPayments.length}</p>
            <p className="text-[11px] text-gray-400">{isAr ? "طلبات Etisalat Cash" : "Payment Requests"}</p>
          </div>
          <div className="p-3 rounded-xl bg-[#0A0A0A] border border-white/10">
            <p className="text-lg font-bold text-amber-400 font-mono">{myTickets.length}</p>
            <p className="text-[11px] text-gray-400">{isAr ? "تذاكر الدعم" : "Support Tickets"}</p>
          </div>
        </div>
      </div>

      {/* SECTION 1: MY ENROLLED COURSES */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#D4AF37]" />
            <span>{isAr ? "كورساتي المشترك بها" : "My Enrolled Courses"}</span>
          </h2>
          <span className="text-xs text-gray-400">
            {enrollments.length} {isAr ? "كورس مفعل" : "courses active"}
          </span>
        </div>

        {enrollments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrollments.map((enr) => {
              const courseObj = courses.find((c) => c.id === enr.courseId);
              return (
                <div
                  key={enr.id}
                  className="rounded-2xl bg-[#151515] border border-white/10 overflow-hidden flex flex-col justify-between shadow-lg"
                >
                  <div>
                    <div className="aspect-video relative bg-[#0A0A0A]">
                      <img
                        src={
                          courseObj?.thumbnail ||
                          "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80"
                        }
                        alt={enr.courseTitle}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2 px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white shadow-sm">
                        {isAr ? "نشط ومفعل ✓" : "Active"}
                      </div>
                    </div>

                    <div className="p-5 space-y-3">
                      <h3 className="text-base font-bold text-white line-clamp-1">
                        {enr.courseTitle}
                      </h3>

                      {/* Progress bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-gray-400">{isAr ? "التقدم:" : "Progress:"}</span>
                          <span className="text-[#D4AF37] font-bold font-mono">{enr.progress}%</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-[#0A0A0A] overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] rounded-full transition-all duration-500"
                            style={{ width: `${enr.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 pt-0">
                    <button
                      onClick={() => {
                        if (courseObj) setSelectedCourse(courseObj);
                        setActiveView("player");
                      }}
                      className="w-full py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white flex items-center justify-center gap-2 shadow-md shadow-[#D4AF37]/20 transition cursor-pointer"
                    >
                      <PlayCircle className="w-4 h-4" />
                      <span>{isAr ? "متابعة مشاهدة الكورس" : "Resume Learning"}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 rounded-2xl bg-[#151515] border border-white/10 text-center space-y-3 shadow-lg">
            <BookOpen className="w-10 h-10 text-gray-500 mx-auto" />
            <p className="text-sm font-bold text-white">
              {isAr ? "لم تشترك في أي كورس حتى الآن" : "No enrolled courses yet"}
            </p>
            <p className="text-xs text-gray-400">
              {isAr
                ? "تصفح الكورسات المتاحة واشترك بسهولة عبر محفظة اتصالات كاش."
                : "Explore our catalog and enroll instantly via Etisalat Cash."}
            </p>
            <button
              onClick={() => setActiveView("courses")}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white hover:brightness-110 cursor-pointer shadow-md"
            >
              {isAr ? "استكشف الكورسات" : "Explore Courses"}
            </button>
          </div>
        )}
      </div>

      {/* SECTION 2: MY SUPPORT TICKETS */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#D4AF37]" />
            <span>{isAr ? "تذاكر الدعم الفني والاستفسارات" : "Support Tickets"}</span>
          </h2>
          <button
            id="btn-dashboard-new-ticket"
            onClick={() => setActiveView("support")}
            className="text-xs text-[#D4AF37] hover:underline font-bold flex items-center gap-1 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>{isAr ? "إنشاء تذكرة جديدة" : "New Ticket"}</span>
          </button>
        </div>

        {myTickets.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {myTickets.map((ticket) => (
              <div
                key={ticket.id}
                onClick={() => setActiveView("support")}
                className="p-4 rounded-2xl bg-[#151515] border border-white/10 hover:border-[#D4AF37]/50 hover:bg-[#1A1A1A] transition cursor-pointer shadow-md flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h3 className="font-bold text-sm text-white line-clamp-1">
                      {ticket.subject}
                    </h3>
                    <span className="text-[10px] text-gray-400 font-mono whitespace-nowrap">
                      {new Date(ticket.updatedAt || ticket.createdAt).toLocaleDateString("ar-EG")}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 line-clamp-2">
                    {ticket.lastMessageText || "لا توجد رسائل بعد"}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5">
                  <span className="text-[11px] text-gray-500">
                    {ticket.messages?.length || 0} رسائل
                  </span>

                  {ticket.status === "closed" ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-gray-400 bg-gray-800 px-2 py-0.5 rounded-full">
                      <Lock className="w-3 h-3" />
                      مغلقة
                    </span>
                  ) : ticket.status === "resolved" ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3" />
                      تم الحل
                    </span>
                  ) : ticket.needsAdminAttention ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                      <AlertCircle className="w-3 h-3" />
                      متابعة الإدارة
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#D4AF37] bg-[#D4AF37]/10 px-2 py-0.5 rounded-full border border-[#D4AF37]/30">
                      <Bot className="w-3 h-3" />
                      مفتوحة
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 rounded-2xl bg-[#151515] border border-white/10 text-center space-y-2">
            <p className="text-xs text-gray-400">
              {isAr ? "لا توجد لديك تذاكر دعم سابقة." : "No support tickets yet."}
            </p>
            <button
              onClick={() => setActiveView("support")}
              className="text-xs text-[#D4AF37] hover:underline font-bold cursor-pointer"
            >
              {isAr ? "ابدأ محادثتك الأولى وتواصل مع الدعم الآن" : "Start your first conversation"}
            </button>
          </div>
        )}
      </div>

      {/* SECTION 3: ETISALAT CASH PAYMENT REQUESTS & STATUS */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-400" />
            <span>{isAr ? "سجل طلبات الدفع عبر Etisalat Cash" : "Etisalat Cash Payment Receipts"}</span>
          </h2>
          <span className="text-xs text-gray-400">
            {myPayments.length} {isAr ? "طلب مسجل" : "requests"}
          </span>
        </div>

        {myPayments.length > 0 ? (
          <div className="rounded-2xl border border-white/10 overflow-hidden bg-[#151515] shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-[#0A0A0A] text-gray-400 border-b border-white/10 uppercase tracking-wider">
                  <tr>
                    <th className="p-3.5">{isAr ? "الكورس" : "Course"}</th>
                    <th className="p-3.5">{isAr ? "المبلغ" : "Amount"}</th>
                    <th className="p-3.5">{isAr ? "رقم التحويل" : "Sender Phone"}</th>
                    <th className="p-3.5">{isAr ? "الحالة" : "Status"}</th>
                    <th className="p-3.5">{isAr ? "التاريخ" : "Date"}</th>
                    <th className="p-3.5">{isAr ? "الإيصال" : "Receipt"}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-gray-300">
                  {myPayments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-white/5 transition">
                      <td className="p-3.5 font-bold text-white">{pay.courseTitle}</td>
                      <td className="p-3.5 font-mono font-bold text-[#D4AF37]">
                        {pay.amount} {isAr ? "ج.م" : "EGP"}
                      </td>
                      <td className="p-3.5 font-mono">{pay.senderPhone}</td>
                      <td className="p-3.5">
                        {pay.status === "approved" && (
                          <span className="px-2.5 py-1 rounded-full font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-fit">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{isAr ? "مقبول ومفعل" : "Approved"}</span>
                          </span>
                        )}
                        {pay.status === "pending" && (
                          <span className="px-2.5 py-1 rounded-full font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30 flex items-center gap-1 w-fit">
                            <Clock className="w-3 h-3" />
                            <span>{isAr ? "قيد المراجعة" : "Pending"}</span>
                          </span>
                        )}
                        {pay.status === "rejected" && (
                          <span className="px-2.5 py-1 rounded-full font-bold bg-red-500/20 text-red-400 border border-red-500/30 flex items-center gap-1 w-fit">
                            <AlertCircle className="w-3 h-3" />
                            <span>{isAr ? "مرفوض" : "Rejected"}</span>
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-gray-400">
                        {new Date(pay.createdAt).toLocaleDateString(isAr ? "ar-EG" : "en-US")}
                      </td>
                      <td className="p-3.5">
                        {pay.receiptUrl && (
                          <button
                            onClick={() => setSelectedReceipt(pay.receiptUrl)}
                            className="p-1.5 rounded-lg bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 text-gray-300 hover:text-white flex items-center gap-1 transition cursor-pointer"
                            title={isAr ? "عرض الإيصال" : "View Receipt"}
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{isAr ? "عرض" : "View"}</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="p-6 rounded-2xl bg-[#151515] border border-white/10 text-center text-xs text-gray-400">
            {isAr ? "لا توجد طلبات دفع سابقة." : "No payment requests yet."}
          </div>
        )}
      </div>

      {/* Receipt Image Lightbox Modal */}
      {selectedReceipt && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedReceipt(null)}
        >
          <div
            className="max-w-2xl max-h-[85vh] bg-[#151515] border border-white/10 rounded-2xl p-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedReceipt(null)}
              className="absolute top-2 left-2 p-1.5 rounded-lg bg-[#0A0A0A] text-gray-300 hover:text-white cursor-pointer"
            >
              ✕
            </button>
            <img
              src={selectedReceipt}
              alt="Receipt"
              className="max-h-[75vh] w-auto mx-auto object-contain rounded-xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
