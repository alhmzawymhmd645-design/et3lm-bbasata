import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  CreditCard,
  Sparkles,
  Code2,
  PlayCircle,
  Award,
  ShieldCheck,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

interface FeatureDetail {
  id: string;
  icon: React.ReactNode;
  cardTitle: string;
  cardDesc: string;
  modalTitle: string;
  badge: string;
  intro: string;
  highlightsTitle?: string;
  highlights: string[];
  notes?: string[];
  footerNote?: string;
}

export const WhyChooseUs: React.FC = () => {
  const { language } = useApp();
  const isAr = language === "ar";

  const [activeFeature, setActiveFeature] = useState<FeatureDetail | null>(null);

  // Close modal on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setActiveFeature(null);
      }
    };
    if (activeFeature) {
      window.addEventListener("keydown", handleKeyDown);
      // Prevent background scrolling
      document.body.style.overflow = "hidden";
    }
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "unset";
    };
  }, [activeFeature]);

  const features: FeatureDetail[] = [
    {
      id: "practical-explanation",
      icon: <Brain className="w-6 h-6 text-amber-400" />,
      cardTitle: isAr ? "شرح مبسط وواقعي" : "Simplified Real-world Explanations",
      cardDesc: isAr
        ? "شرح واضح ومنظم بعيداً عن الحشو والمصطلحات المعقدة مع أمثلة واقعية."
        : "Clear, practical explanations avoiding unnecessary theory and jargon.",
      modalTitle: isAr ? "شرح مبسط وواقعي 📚" : "Simplified & Practical Learning 📚",
      badge: isAr ? "منهجية الفهم والتطبيق" : "Intuitive Methodology",
      intro: isAr
        ? "التعلم مش لازم يكون معقد! 🚀\n\nفي «اتعلم ببساطة» بنشرح المعلومة بطريقة واضحة ومنظمة، بعيدًا عن الحشو النظري والمصطلحات المعقدة."
        : "Learning shouldn't be complicated! 🚀\n\nAt 'Learn Simply', we explain every concept in a clear, organized manner, far from dry theory and complicated jargon.",
      highlightsTitle: isAr ? "🎯 هتتعلم خطوة بخطوة:" : "🎯 Step-by-step learning:",
      highlights: isAr
        ? [
            "نفهم الفكرة أولًا قبل ما نستخدمها.",
            "نشرح المصطلحات بطريقة سهلة ومباشرة.",
            "نستخدم أمثلة عملية من الواقع وسوق العمل.",
            "نطبق اللي اتعلمناه مباشرة خطوة بخطوة.",
            "ننتقل من المستوى البسيط إلى المستوى المتقدم تدريجيًا.",
          ]
        : [
            "Understand the concept deeply before writing code.",
            "Demystify complex terms in everyday language.",
            "Utilize real-world industry examples and workflows.",
            "Apply what you learn immediately through exercises.",
            "Smooth progression from fundamentals to advanced concepts.",
          ],
      notes: isAr
        ? [
            "💡 هدفنا إنك مش بس تحفظ المعلومة، لكن تفهمها وتعرف تستخدمها بنفسك.",
            "سواء كنت مبتدئًا أو عندك خبرة، هتلاقي المحتوى منظم بطريقة تساعدك تتعلم بثقة.",
          ]
        : [
            "💡 Our goal is not just memorization, but true comprehension and independent problem solving.",
            "Whether you're a complete beginner or looking to upskill, the curriculum is structured to build your confidence.",
          ],
    },
    {
      id: "etisalat-cash",
      icon: <CreditCard className="w-6 h-6 text-blue-400" />,
      cardTitle: isAr ? "دفع سهل عبر Etisalat Cash" : "Easy Etisalat Cash Checkout",
      cardDesc: isAr
        ? "ادفع مباشرة من محفظة هاتفك برقم المنصة الرسمي وتفعيل فوري."
        : "Pay easily using local mobile wallets without needing credit cards.",
      modalTitle: isAr ? "دفع سهل عبر Etisalat Cash 💳" : "Easy Mobile Payment (Etisalat Cash) 💳",
      badge: isAr ? "دفع محلي آمن 100%" : "100% Safe Local Payments",
      intro: isAr
        ? "مش محتاج بطاقة بنكية عشان تبدأ التعلم! 📱\n\nتقدر تدفع مقابل الكورس باستخدام محفظة Etisalat Cash بطريقة سهلة ومباشرة."
        : "No credit card needed to start learning! 📱\n\nYou can easily enroll in any course using Etisalat Cash mobile wallet directly.",
      highlightsTitle: isAr ? "⚡ طريقة الدفع:" : "⚡ Payment Steps:",
      highlights: isAr
        ? [
            "1️⃣ اختر الكورس الذي تريد الاشتراك فيه.",
            "2️⃣ اختر طريقة الدفع Etisalat Cash.",
            "3️⃣ حوّل المبلغ إلى الرقم الرسمي الظاهر داخل المنصة.",
            "4️⃣ أرسل إثبات الدفع إذا طلب منك النظام (رفع صورة الإيصال).",
            "5️⃣ انتظر مراجعة الطلب من فريق العمل.",
            "6️⃣ بعد تأكيد الدفع يتم تفعيل الكورس لحسابك فوراً.",
          ]
        : [
            "1️⃣ Choose the course you wish to enroll in.",
            "2️⃣ Select Etisalat Cash as your payment method.",
            "3️⃣ Transfer the fee to the official wallet number shown in the platform.",
            "4️⃣ Submit your transfer receipt.",
            "5️⃣ Our team promptly reviews the transaction.",
            "6️⃣ Once approved, the course is activated immediately on your account.",
          ],
      footerNote: isAr
        ? "🔐 جميع عمليات الدفع تتم وفق نظام المنصة، ولا تطلب المنصة منك مطلقاً مشاركة الرقم السري للمحفظة (PIN) أو أي بيانات حساسة."
        : "🔐 All transactions follow strict platform protocols. The platform will never ask for your wallet PIN or sensitive passwords.",
    },
    {
      id: "ai-assistant",
      icon: <Sparkles className="w-6 h-6 text-amber-300" />,
      cardTitle: isAr ? "مساعد اتعلم ببساطة AI" : "AI Interactive Tutor",
      cardDesc: isAr
        ? "مساعد ذكي يرافقك بالدرس؛ يلخص المحتوى، يجيب أسئلتك ويختبرك."
        : "Smart AI companion inside lessons to summarize, clarify and test your knowledge.",
      modalTitle: isAr ? "مساعد اتعلم ببساطة AI 🤖" : "Learn Simply AI Assistant 🤖",
      badge: isAr ? "مساعدك الشخصي على مدار الساعة" : "24/7 Smart Companion",
      intro: isAr
        ? "مش بتتعلم لوحدك! 🤝\n\nمساعد «اتعلم ببساطة AI» موجود لمساعدتك وتوجيهك أثناء رحلة التعلم في كل درس."
        : "You're never learning alone! 🤝\n\nThe 'Learn Simply AI' tutor is always by your side to support you through every lesson.",
      highlightsTitle: isAr ? "✨ يقدر يساعدك في:" : "✨ How it empowers you:",
      highlights: isAr
        ? [
            "شرح المفاهيم الصعبة بأسلوب مبسط وأمثلة برمجية.",
            "تبسيط أجزاء الدرس المعقدة وإعادة صياغتها.",
            "تلخيص المحتوى وأهم النقاط الأساسية.",
            "إنشاء أسئلة تفاعلية (اختيار من متعدد) لتقييم فهمك.",
            "مساعدتك على مراجعة الدرس وتثبيت المعلومة.",
            "الإجابة الفورية عن أسئلتك المتعلقة بالمحتوى التعليمي.",
          ]
        : [
            "Explaining complex technical concepts with simplified examples.",
            "Breaking down tricky lesson sections into digestible steps.",
            "Summarizing lesson takeaways and key takeaways.",
            "Generating instant multiple-choice quizzes to test mastery.",
            "Helping you review and solidify lesson outcomes.",
            "Answering your questions on demand while watching videos.",
          ],
      notes: isAr
        ? [
            "🧠 اسأله عن أي نقطة مش واضحة في الدرس، وهيحاول يشرحها لك بطريقة بسيطة وسريعة.",
            "🎯 الفكرة مش إنه يحل كل حاجة بدل منك، لكن يساعدك تفهم وتتعلم بشكل أفضل وتبني مهاراتك بنفسك.",
          ]
        : [
            "🧠 Ask about any ambiguous point in the lesson and get instant, tailored guidance.",
            "🎯 The goal isn't to do the work for you, but to help you understand deeply and cultivate true mastery.",
          ],
    },
    {
      id: "capstone-projects",
      icon: <Code2 className="w-6 h-6 text-emerald-400" />,
      cardTitle: isAr ? "مشاريع تخرج فعلية" : "Hands-on Capstone Projects",
      cardDesc: isAr
        ? "تطبيقات ومشاريع كاملة لبناء معرض أعمال قوي لسوق العمل."
        : "Real-world projects to build an impressive portfolio for employers.",
      modalTitle: isAr ? "مشاريع تخرج فعلية 🏆" : "Real Practical Projects 🏆",
      badge: isAr ? "خبرة عملية واقعية" : "Applied Portfolio Experience",
      intro: isAr
        ? "التعلم الحقيقي بيظهر لما تطبق! 💻\n\nعشان كده مش هدفنا إنك تخلص الكورس وخلاص، لكن خلال رحلة التعلم هتشتغل على تطبيقات ومشاريع عملية تساعدك تحول اللي اتعلمته إلى مهارات حقيقية ملموسة."
        : "Real learning happens when you build! 💻\n\nOur objective isn't just finishing video lectures, but delivering working full-scale projects that prove your capabilities.",
      highlightsTitle: isAr ? "🎯 المشاريع تساعدك على:" : "🎯 Projects empower you to:",
      highlights: isAr
        ? [
            "تطبيق المفاهيم والأدوات التي تعلمتها في سياق واقعي.",
            "التدريب على حل المشكلات التقنية والأخطاء الشائعة (Debugging).",
            "بناء مشاريع حقيقية متكاملة من الصفر حتى النشر.",
            "تطوير مهاراتك العملية بما يواكب معايير الشركات.",
            "تكوين Portfolio قوي واحترافي على GitHub ومعارض الأعمال.",
            "الاستعداد التام لمتطلبات واختبارات سوق العمل والمقابلات.",
          ]
        : [
            "Apply concepts and tools in production-like contexts.",
            "Master problem-solving and debugging real scenarios.",
            "Build complete software solutions from scratch to deployment.",
            "Refine your practical skills to meet company standards.",
            "Create a standout GitHub portfolio to showcase to clients.",
            "Thoroughly prepare for technical job interviews.",
          ],
      notes: isAr
        ? ["💡 كل مشروع هو فرصة جديدة تثبت لنفسك إنك قادر تبني حاجة بنفسك وتفتخر بيها."]
        : ["💡 Each project is an opportunity to prove to yourself and the world that you can build meaningful products."],
    },
    {
      id: "interactive-player",
      icon: <PlayCircle className="w-6 h-6 text-purple-400" />,
      cardTitle: isAr ? "مشغل دروس تفاعلي" : "Interactive Lesson Player",
      cardDesc: isAr
        ? "مشاهدة سلسة تحفظ تقدمك تلقائياً وتتيح التنقل السريع."
        : "Smooth lesson player with automatic progress saving and fluid navigation.",
      modalTitle: isAr ? "مشغل دروس تفاعلي ▶️" : "Interactive Lesson Player ▶️",
      badge: isAr ? "تجربة دراسة متطورة" : "Advanced Learning UI",
      intro: isAr
        ? "اتعلم بطريقتك وبالسرعة اللي تناسبك! 🎓\n\nمشغل الدروس في «اتعلم ببساطة» مصمم بعناية ليجعل تجربة التعلم مريحة ومركزة بدون أي تشتيت."
        : "Learn at your own pace! 🎓\n\nOur lesson player is crafted to ensure a seamless, focused learning experience across all devices.",
      highlightsTitle: isAr ? "✨ مميزات المشغل التفاعلي:" : "✨ Key Player Features:",
      highlights: isAr
        ? [
            "▶️ تشغيل الدروس والفيديوهات بجودة عالية وبدون تقطيع.",
            "⏯️ متابعة الفيديو بدقة من المكان الذي توقفت عنده بالضبط.",
            "📊 حفظ تقدمك ونسبة الإنجاز تلقائيًا في حسابك.",
            "➡️ سهولة الانتقال والتنقل بين الدروس والمحاور التدريبية.",
            "📱 تجربة متجاوبة وسلسة على الموبايل والتابلت والكمبيوتر.",
            "📝 الوصول المباشر إلى الأنشطة والاختبارات والمصادر المرفقة بالدرس.",
          ]
        : [
            "▶️ High quality, stutter-free video playback.",
            "⏯️ Seamless resume from exact timestamp where you left off.",
            "📊 Automatic progress tracking synced across devices.",
            "➡️ Fluid navigation between chapters and course modules.",
            "📱 Fully responsive UI optimized for mobile, tablet & desktop.",
            "📝 Instant access to lesson attachments, notes, and quizzes.",
          ],
      notes: isAr
        ? ["🎯 هدفنا إنك تركز على التعلم واستيعاب الدروس، والمنصة تهتم بحفظ تقدمك وتنظيم رحلتك."]
        : ["🎯 Focus purely on learning while the platform takes care of organizing your journey."],
    },
    {
      id: "course-certificate",
      icon: <Award className="w-6 h-6 text-amber-400" />,
      cardTitle: isAr ? "شهادة إتمام" : "Completion Certificate",
      cardDesc: isAr
        ? "شهادة إتمام من المنصة تثبت إنهاءك لكافة متطلبات الكورس بنجاح."
        : "Document your achievement with a platform completion certificate upon 100% progress.",
      modalTitle: isAr ? "شهادة إتمام 🎓" : "Platform Completion Certificate 🎓",
      badge: isAr ? "شهادة إتمام من المنصة" : "Platform Certificate",
      intro: isAr
        ? "كملت رحلتك؟ خلي إنجازك موثق! 🏆\n\nعند إتمام متطلبات الكورس ووصول نسبة تقدمك إلى 100%، يمكنك الحصول على شهادة إتمام من المنصة وفق نظام الشهادات المعتمد داخل «اتعلم ببساطة»."
        : "Finished your curriculum? Document your victory! 🏆\n\nUpon completing all course requirements and reaching 100% progress, you receive an official completion certificate issued by the platform.",
      highlightsTitle: isAr ? "📜 تتضمن الشهادة:" : "📜 The certificate includes:",
      highlights: isAr
        ? [
            "اسم الطالب كما هو مسجل بالمنصة.",
            "اسم الكورس والتخصص المكتمل.",
            "تاريخ إتمام الكورس وإصداره.",
            "رقم ومعرّف التحقق الفريد للشهادة (Verification ID).",
            "اسم وشعار منصة اتعلم ببساطة الرسمي.",
            "تأكيد إتمام واجتياز كافة متطلبات الدبلومة.",
          ]
        : [
            "Student's registered full name.",
            "Completed course & track title.",
            "Official completion and issuance date.",
            "Unique verification credential ID.",
            "Official Learn Simply seal and signature.",
            "Verification of successful completion of all lessons.",
          ],
      notes: isAr
        ? ["🎯 هدف الشهادة هو توثيق إتمامك للمحتوى التعليمي داخل المنصة وإبراز إنجازك في ملفك الشخصي ومجتمع التعلم."]
        : ["🎯 The certificate serves as concrete proof of your dedicated effort and completion of the training track."],
    },
  ];

  return (
    <section className="py-20 bg-[#0A0A0A] relative overflow-hidden border-t border-white/10" id="platform-features">
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-bold shadow-sm">
            <ShieldCheck className="w-4 h-4" />
            <span>{isAr ? "لماذا اتعلم ببساطة؟" : "Why Choose Learn Simply?"}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            {isAr
              ? "تجربة تعليمية متكاملة مصممة لنجاحك"
              : "A Complete Learning Experience Built For You"}
          </h2>

          <p className="text-sm sm:text-base text-gray-300 leading-relaxed">
            {isAr
              ? "اضغط على أي من المميزات التالية لمعرفة كافة التفاصيل وكيف نساعدك في تحقيق أهدافك التعليمية:"
              : "Click any of the features below to view detailed breakdown of what makes our platform unique:"}
          </p>
        </div>

        {/* Features 3-Column Interactive Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, idx) => (
            <button
              key={f.id}
              id={`btn-feature-${f.id}`}
              onClick={() => setActiveFeature(f)}
              className="w-full text-right p-6 rounded-2xl bg-[#151515] hover:bg-[#1A1A1A] border border-white/10 hover:border-[#D4AF37]/60 hover:shadow-xl hover:shadow-[#D4AF37]/10 transition-all duration-300 group cursor-pointer flex flex-col justify-between h-full relative overflow-hidden focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
            >
              {/* Card Corner Accent */}
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-[#D4AF37]/10 to-transparent rounded-bl-full pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="space-y-4">
                {/* Icon & Badge */}
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-[#0A0A0A] border border-white/10 flex items-center justify-center shadow-inner group-hover:border-[#D4AF37]/40 group-hover:scale-105 transition-all duration-300">
                    {f.icon}
                  </div>
                  <span className="text-[11px] font-bold text-gray-500 group-hover:text-[#D4AF37] transition-colors flex items-center gap-1">
                    <span>{isAr ? "اضغط للتفاصيل" : "View Details"}</span>
                    {isAr ? (
                      <ChevronLeft className="w-3.5 h-3.5 transform group-hover:-translate-x-1 transition-transform" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                    )}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-white group-hover:text-[#D4AF37] transition-colors">
                  {f.cardTitle}
                </h3>

                {/* Short Description */}
                <p className="text-xs sm:text-sm text-gray-400 leading-relaxed line-clamp-2">
                  {f.cardDesc}
                </p>
              </div>

              {/* Bottom interactive hint */}
              <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between text-xs text-gray-400 group-hover:text-gray-200">
                <span className="font-semibold text-[11px] text-[#D4AF37]/80">
                  {isAr ? `ميزة #${idx + 1}` : `Feature #${idx + 1}`}
                </span>
                <span className="text-[11px] font-medium underline underline-offset-4 decoration-[#D4AF37]/40 group-hover:decoration-[#D4AF37]">
                  {isAr ? "اقرأ الشرح الكامل ↗" : "Read More ↗"}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* FEATURE DETAIL MODAL */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {activeFeature && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md"
            onClick={() => setActiveFeature(null)}
            role="dialog"
            aria-modal="true"
            aria-labelledby="feature-modal-title"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl bg-[#151515] border border-[#D4AF37]/40 rounded-3xl p-6 sm:p-8 max-h-[88vh] overflow-y-auto shadow-2xl shadow-[#D4AF37]/10 text-right space-y-6 relative custom-scrollbar"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center flex-shrink-0 shadow-lg">
                    {activeFeature.icon}
                  </div>
                  <div>
                    <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30 mb-1">
                      {activeFeature.badge}
                    </span>
                    <h3
                      id="feature-modal-title"
                      className="text-lg sm:text-xl font-bold text-white"
                    >
                      {activeFeature.modalTitle}
                    </h3>
                  </div>
                </div>

                {/* Close Button Top */}
                <button
                  id="btn-close-feature-modal"
                  onClick={() => setActiveFeature(null)}
                  className="p-2 rounded-xl bg-[#0A0A0A] border border-white/10 hover:border-[#D4AF37]/50 text-gray-400 hover:text-white transition cursor-pointer flex items-center gap-1 text-xs font-semibold"
                  title={isAr ? "إغلاق النافذة" : "Close"}
                >
                  <X className="w-4 h-4" />
                  <span className="hidden sm:inline">{isAr ? "إغلاق" : "Close"}</span>
                </button>
              </div>

              {/* Intro Text */}
              <div className="space-y-3">
                {activeFeature.intro.split("\n\n").map((para, i) => (
                  <p
                    key={i}
                    className="text-sm sm:text-base text-gray-200 leading-relaxed whitespace-pre-line"
                  >
                    {para}
                  </p>
                ))}
              </div>

              {/* Highlights Box */}
              {activeFeature.highlights && activeFeature.highlights.length > 0 && (
                <div className="p-4 sm:p-5 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-3">
                  {activeFeature.highlightsTitle && (
                    <h4 className="text-sm sm:text-base font-bold text-[#D4AF37]">
                      {activeFeature.highlightsTitle}
                    </h4>
                  )}
                  <ul className="space-y-2 text-xs sm:text-sm text-gray-300">
                    {activeFeature.highlights.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 leading-relaxed">
                        <span className="text-[#D4AF37] mt-0.5 font-bold flex-shrink-0">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Notes / Tips */}
              {activeFeature.notes && activeFeature.notes.length > 0 && (
                <div className="space-y-2">
                  {activeFeature.notes.map((note, i) => (
                    <p
                      key={i}
                      className="text-xs sm:text-sm text-gray-300 bg-white/[0.02] p-3 rounded-xl border border-white/5 leading-relaxed"
                    >
                      {note}
                    </p>
                  ))}
                </div>
              )}

              {/* Footer Note */}
              {activeFeature.footerNote && (
                <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-500/30 text-blue-200 text-xs leading-relaxed flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                  <p>{activeFeature.footerNote}</p>
                </div>
              )}

              {/* Modal Actions */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
                <p className="text-[11px] text-gray-500">
                  {isAr ? "اضغط Escape أو خارج النافذة للإغلاق" : "Press Esc or click outside to close"}
                </p>
                <button
                  onClick={() => setActiveFeature(null)}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white text-xs sm:text-sm font-bold shadow-md shadow-[#D4AF37]/20 transition cursor-pointer flex items-center gap-1.5"
                >
                  <X className="w-4 h-4" />
                  <span>{isAr ? "إغلاق ✕" : "Close ✕"}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

