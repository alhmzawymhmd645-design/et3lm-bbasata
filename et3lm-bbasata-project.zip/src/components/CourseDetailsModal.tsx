import React, { useEffect, useState } from "react";
import { useApp } from "../context/AppContext";
import { Course, Lesson } from "../types";
import { collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { db } from "../lib/firebase";
import {
  X,
  Clock,
  BookOpen,
  Star,
  Users,
  CheckCircle2,
  Lock,
  PlayCircle,
  CreditCard,
  Sparkles,
  ShieldCheck,
  Award,
} from "lucide-react";

interface CourseDetailsModalProps {
  course: Course | null;
  isOpen: boolean;
  onClose: () => void;
  onEnroll: (course: Course) => void;
}

export const CourseDetailsModal: React.FC<CourseDetailsModalProps> = ({
  course,
  isOpen,
  onClose,
  onEnroll,
}) => {
  const {
    isEnrolledInCourse,
    setSelectedCourse,
    setSelectedLesson,
    setActiveView,
    language,
  } = useApp();

  const isAr = language === "ar";
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loadingLessons, setLoadingLessons] = useState(false);

  useEffect(() => {
    if (!course) return;
    async function loadLessons() {
      setLoadingLessons(true);
      try {
        const q = query(
          collection(db, "lessons"),
          where("courseId", "==", course.id)
        );
        const snap = await getDocs(q);
        const list: Lesson[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as Lesson);
        });
        list.sort((a, b) => (a.order || 0) - (b.order || 0));
        setLessons(list);
      } catch (err) {
        console.error("Error loading course lessons:", err);
      } finally {
        setLoadingLessons(false);
      }
    }
    loadLessons();
  }, [course]);

  if (!isOpen || !course) return null;

  const enrolled = isEnrolledInCourse(course.id);

  const handleStartLesson = (lesson: Lesson) => {
    setSelectedCourse(course);
    setSelectedLesson(lesson);
    onClose();
    setActiveView("player");
  };

  return (
    <div
      id="course-details-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="course-details-container"
        className="w-full max-w-3xl bg-[#151515] border border-white/10 rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6 relative max-h-[90vh] overflow-y-auto select-none"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="course-details-close-btn"
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Section */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-7 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              {course.categoryPath && course.categoryPath.length > 0 ? (
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30 flex-wrap">
                  {course.categoryPath.map((segment, idx) => (
                    <React.Fragment key={idx}>
                      <span>{segment}</span>
                      {idx < course.categoryPath!.length - 1 && (
                        <span className="text-gray-500 text-[10px]">←</span>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              ) : (
                <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30">
                  {course.category}
                </span>
              )}
              <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-[#0A0A0A] text-gray-200 border border-white/10">
                {course.level}
              </span>
              {enrolled && (
                <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isAr ? "أنت مشترك في هذا الكورس" : "Enrolled"}</span>
                </span>
              )}
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold text-white leading-tight">
              {isAr ? course.title : course.titleEn || course.title}
            </h2>

            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
              {isAr ? course.description : course.descriptionEn || course.description}
            </p>

            <div className="flex items-center gap-4 text-xs text-gray-400 pt-1">
              <div className="flex items-center gap-1">
                <BookOpen className="w-4 h-4 text-[#D4AF37]" />
                <span>
                  {course.lessonCount || lessons.length} {isAr ? "درس" : "lessons"}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-blue-400" />
                <span>{course.duration}</span>
              </div>
              <div className="flex items-center gap-1 font-bold text-[#D4AF37]">
                <Star className="w-4 h-4 fill-[#D4AF37]" />
                <span>{course.rating || 4.9}</span>
              </div>
            </div>
          </div>

          {/* Thumbnail & Pricing Box */}
          <div className="md:col-span-5 rounded-2xl overflow-hidden bg-[#0A0A0A] border border-white/10 p-3 space-y-3">
            <div className="aspect-video rounded-xl overflow-hidden relative">
              <img
                src={course.thumbnail}
                alt={course.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-center space-y-2">
              <div className="flex items-baseline justify-center gap-2">
                <span className="text-2xl font-bold text-[#D4AF37] font-mono">
                  {course.price}
                </span>
                <span className="text-xs font-bold text-gray-300">
                  {isAr ? "جنيه مصري" : "EGP"}
                </span>
                {course.originalPrice && (
                  <span className="text-xs text-gray-500 line-through font-mono">
                    {course.originalPrice}
                  </span>
                )}
              </div>

              {enrolled ? (
                <button
                  onClick={() => {
                    setSelectedCourse(course);
                    if (lessons.length > 0) setSelectedLesson(lessons[0]);
                    onClose();
                    setActiveView("player");
                  }}
                  className="w-full py-3 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 text-xs sm:text-sm cursor-pointer"
                >
                  <PlayCircle className="w-4 h-4" />
                  <span>{isAr ? "فتح مشغل الدروس ومتابعة التعلم" : "Resume Course"}</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    onClose();
                    onEnroll(course);
                  }}
                  className="w-full py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 transition flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/25 text-xs sm:text-sm cursor-pointer"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>{isAr ? "اشترك الآن عبر Etisalat Cash" : "Enroll via Etisalat Cash"}</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* What you will learn */}
        {course.whatYouWillLearn && course.whatYouWillLearn.length > 0 && (
          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>{isAr ? "ماذا ستتعلم في هذا الكورس؟" : "What You'll Learn"}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-300">
              {course.whatYouWillLearn.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Lessons List Curriculum */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-400" />
              <span>
                {isAr ? "منهاج ودروس الكورس" : "Course Curriculum"} ({lessons.length} {isAr ? "درس" : "lessons"})
              </span>
            </h4>
            <span className="text-[11px] text-gray-400">
              {isAr ? "الدروس المجانية تحمل علامة معاينة" : "Free previews marked"}
            </span>
          </div>

          {loadingLessons ? (
            <div className="py-6 text-center text-xs text-gray-500">
              {isAr ? "جاري تحميل الدروس..." : "Loading lessons..."}
            </div>
          ) : (
            <div className="space-y-2">
              {lessons.map((lesson, idx) => {
                const canPlay = enrolled || lesson.isFreePreview;
                return (
                  <div
                    key={lesson.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition ${
                      canPlay
                        ? "bg-[#0A0A0A] border-white/10 hover:border-[#D4AF37]/40"
                        : "bg-[#0A0A0A]/40 border-white/5 opacity-70"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                          canPlay
                            ? "bg-[#D4AF37]/15 text-[#D4AF37]"
                            : "bg-white/5 text-gray-500"
                        }`}
                      >
                        {idx + 1}
                      </div>
                      <div>
                        <p className="text-xs sm:text-sm font-bold text-white">
                          {lesson.title}
                        </p>
                        <p className="text-[11px] text-gray-400 line-clamp-1">
                          {lesson.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 flex-shrink-0">
                      <span className="text-xs text-gray-400 font-mono">
                        {lesson.duration}
                      </span>

                      {canPlay ? (
                        <button
                          onClick={() => handleStartLesson(lesson)}
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#D4AF37] border border-[#D4AF37]/40 flex items-center gap-1 transition cursor-pointer"
                        >
                          <PlayCircle className="w-3.5 h-3.5" />
                          <span>{lesson.isFreePreview && !enrolled ? (isAr ? "معاينة مجانية" : "Preview") : (isAr ? "مشاهدة" : "Play")}</span>
                        </button>
                      ) : (
                        <div className="p-2 text-gray-600" title={isAr ? "مغلق، يتطلب الاشتراك" : "Locked"}>
                          <Lock className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
