import React from "react";
import { useApp } from "../context/AppContext";
import appLogo from "../assets/images/app_logo_1787091289735.jpg";
import {
  GraduationCap,
  CreditCard,
  Mail,
  Phone,
  Sparkles,
  ShieldCheck,
  Heart,
  LifeBuoy,
} from "lucide-react";

export const Footer: React.FC = () => {
  const { settings, setActiveView, language, isAdmin } = useApp();
  const isAr = language === "ar";

  return (
    <footer className="bg-[#0F0F0F] border-t border-white/10 text-gray-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#D4AF37]/40 bg-[#121212] flex-shrink-0 shadow-sm">
                <img
                  src={settings.logoUrl || appLogo}
                  alt={settings.platformName || "اتعلم ببساطة"}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-lg font-bold text-white">
                {isAr ? (
                  <>
                    اتعلم <span className="text-[#D4AF37]">ببساطة</span>
                  </>
                ) : (
                  <>
                    Learn <span className="text-[#D4AF37]">Simply</span>
                  </>
                )}
              </span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              {isAr
                ? settings.description ||
                  "المنصة التعليمية الشاملة لتعلم المهارات الرقمية وبناء المشاريع العملية ببساطة."
                : settings.descriptionEn ||
                  "Your practical gateway to mastering tech and coding in simple steps."}
            </p>
          </div>

          {/* Col 2: Etisalat Cash payment box */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 text-[#D4AF37]">
              <CreditCard className="w-4 h-4" />
              <span>{isAr ? "الدفع والتحويل" : "Payments"}</span>
            </h4>
            <div className="p-3.5 rounded-2xl bg-[#151515] border border-white/10 space-y-2">
              <p className="text-[11px] text-gray-300">
                {isAr
                  ? "رقم محفظة Etisalat Cash المعتمد للدفع:"
                  : "Official Etisalat Cash Wallet:"}
              </p>
              <div className="px-2.5 py-1.5 rounded-xl bg-[#0A0A0A] border border-[#D4AF37]/30 text-[#D4AF37] font-mono font-bold text-center text-sm">
                {settings.etisalatCashNumber}
              </div>
              <p className="text-[10px] text-gray-400">
                {isAr
                  ? "يتم رفع إيصال التحويل للمراجعة الفورية وتفعيل الكورس."
                  : "Upload screenshot receipt for instant verification."}
              </p>
            </div>
          </div>

          {/* Col 3: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              {isAr ? "روابط سريعة" : "Quick Links"}
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveView("home")}
                  className="hover:text-[#D4AF37] transition"
                >
                  {isAr ? "الصفحة الرئيسية" : "Home"}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView("courses")}
                  className="hover:text-[#D4AF37] transition"
                >
                  {isAr ? "جميع الكورسات والمسارات" : "All Courses"}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView("ai-assistant")}
                  className="hover:text-[#D4AF37] transition flex items-center gap-1 text-[#D4AF37]"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>{isAr ? "مساعد اتعلم ببساطة AI" : "AI Assistant"}</span>
                </button>
              </li>
              <li>
                <button
                  id="footer-nav-support"
                  onClick={() => setActiveView("support")}
                  className="hover:text-[#D4AF37] transition flex items-center gap-1 text-slate-300"
                >
                  <LifeBuoy className="w-3 h-3 text-[#D4AF37]" />
                  <span>{isAr ? "الدعم الفني والرد الآلي" : "Technical Support"}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView("student-dashboard")}
                  className="hover:text-[#D4AF37] transition"
                >
                  {isAr ? "لوحة الطالب ومتابعة الطلبات" : "Student Dashboard"}
                </button>
              </li>
              {isAdmin && (
                <li>
                  <button
                    onClick={() => setActiveView("admin-dashboard")}
                    className="hover:text-red-300 transition font-bold text-red-400 flex items-center gap-1"
                  >
                    <ShieldCheck className="w-3 h-3" />
                    <span>{isAr ? "لوحة تحكم المشرف (Admin)" : "Admin Dashboard"}</span>
                  </button>
                </li>
              )}
            </ul>
          </div>

          {/* Col 4: Contact info */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? "تواصل معنا والدعم" : "Contact & Support"}</span>
            </h4>
            <div className="space-y-2.5 text-xs">
              <button
                type="button"
                id="footer-email-link"
                onClick={() => {
                  setActiveView("support");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="w-full flex items-center gap-2 p-2 rounded-xl bg-[#151515] hover:bg-[#1A1A1A] border border-white/10 hover:border-[#D4AF37]/50 text-gray-200 hover:text-[#D4AF37] transition-all group cursor-pointer text-right"
                title={isAr ? "فتح مركز الدعم الفني والمساعدة التفاعلي" : "Open Interactive Support Center"}
              >
                <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Mail className="w-3.5 h-3.5 text-[#D4AF37]" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="block text-[10px] text-gray-400 font-medium">
                    {isAr ? "البريد الإلكتروني المباشر" : "Direct Support Email"}
                  </span>
                  <span className="truncate block font-mono text-[11px] text-[#D4AF37] font-bold">
                    {settings.contactEmail || "alhmzawymhmd645@gmail.com"}
                  </span>
                </div>
              </button>

              {settings.contactPhone && (
                <a
                  id="footer-phone-link"
                  href={`tel:${settings.contactPhone.replace(/\s+/g, "")}`}
                  onClick={() => {
                    try {
                      window.location.href = `tel:${settings.contactPhone.replace(/\s+/g, "")}`;
                    } catch (e) {
                      console.warn("Tel triggered:", e);
                    }
                  }}
                  className="flex items-center gap-2 p-2 rounded-xl bg-[#151515] hover:bg-[#1A1A1A] border border-white/10 hover:border-[#D4AF37]/50 text-gray-200 hover:text-[#D4AF37] transition-all group cursor-pointer"
                  title={isAr ? "الاتصال المباشر" : "Call us"}
                >
                  <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                    <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block text-[10px] text-gray-400 font-medium">
                      {isAr ? "الهاتف / الواتساب" : "Phone / WhatsApp"}
                    </span>
                    <span dir="ltr" className="block font-mono text-[11px] text-gray-300 font-semibold text-right">
                      {settings.contactPhone}
                    </span>
                  </div>
                </a>
              )}

              <button
                id="footer-support-chat-btn"
                onClick={() => setActiveView("support")}
                className="mt-1 w-full py-2 px-3 rounded-xl bg-[#151515] hover:bg-[#1A1A1A] border border-white/10 hover:border-blue-500/50 text-blue-400 hover:text-blue-300 font-bold text-[11px] flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
              >
                <LifeBuoy className="w-3.5 h-3.5" />
                <span>{isAr ? "نظام تذاكر الدعم والرد الآلي" : "Open Support Ticket"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-right">
          <p className="text-[11px] text-gray-500">
            © {new Date().getFullYear()} اتعلم ببساطة. {isAr ? "جميع الحقوق محفوظة." : "All rights reserved."}
          </p>
          <p className="text-[11px] text-gray-500 flex items-center gap-1">
            <span>{isAr ? "صُنع بإتقان لخدمة الشباب العربي" : "Crafted with passion for Arabic learners"}</span>
            <Heart className="w-3 h-3 text-[#D4AF37] fill-[#D4AF37]" />
          </p>
        </div>
      </div>
    </footer>
  );
};
