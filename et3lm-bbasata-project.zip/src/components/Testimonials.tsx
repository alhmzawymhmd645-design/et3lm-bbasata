import React from "react";
import { useApp } from "../context/AppContext";
import { Star, Quote, Sparkles } from "lucide-react";

export const Testimonials: React.FC = () => {
  const { testimonials, language } = useApp();
  const isAr = language === "ar";

  if (!testimonials || testimonials.length === 0) return null;

  return (
    <section className="py-20 relative bg-[#0A0A0A] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isAr ? "قصص نجاح وآراء الطلاب" : "Student Reviews"}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            {isAr ? "ماذا يقول طلاب «اتعلم ببساطة»؟" : "Loved by students across the Arab world"}
          </h2>

          <p className="text-sm text-gray-400">
            {isAr
              ? "انضم إلى آلاف الطلاب الذين غيروا مسارهم المهني وحققوا أهدافهم بالتعلم معنا."
              : "Read how students leveled up their careers and built real apps."}
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="p-6 rounded-2xl bg-[#151515] border border-white/10 flex flex-col justify-between space-y-4 hover:border-[#D4AF37]/40 transition duration-300 shadow-lg"
            >
              <div className="space-y-3">
                {/* Rating stars */}
                <div className="flex items-center gap-1 text-[#D4AF37]">
                  {[...Array(t.rating || 5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                  ))}
                </div>

                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed italic">
                  "{t.comment}"
                </p>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-white/10">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-10 h-10 rounded-full object-cover border border-[#D4AF37]/30"
                />
                <div>
                  <h4 className="text-xs font-bold text-white">{t.name}</h4>
                  <p className="text-[11px] text-gray-400">{t.role}</p>
                  <p className="text-[10px] text-[#D4AF37] font-semibold">{t.courseTitle}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
