import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import appLogo from "../assets/images/app_logo_1787091289735.jpg";
import {
  GraduationCap,
  Sparkles,
  BookOpen,
  LayoutDashboard,
  ShieldCheck,
  User,
  LogOut,
  LogIn,
  Globe,
  Menu,
  X,
  CreditCard,
  PhoneCall,
  Download,
  Image as ImageIcon,
  LifeBuoy,
  MessageSquare,
} from "lucide-react";

export const Navbar: React.FC = () => {
  const {
    user,
    isAdmin,
    settings,
    language,
    setLanguage,
    activeView,
    setActiveView,
    unreadMessengerCount,
    setIsAuthModalOpen,
    setAuthModalMode,
    logout,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  const isAr = language === "ar";

  const handleNavClick = (view: any) => {
    setActiveView(view);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#0F0F0F]/95 backdrop-blur-md">
      {/* Top Announcement Bar */}
      {settings.announcement && (
        <div className="bg-[#14120B] border-b border-[#D4AF37]/30 py-2 px-4 text-center text-xs font-medium text-[#F3E5AB] flex items-center justify-center gap-2.5 flex-wrap">
          <CreditCard className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>{settings.announcement}</span>
          <span className="bg-[#D4AF37]/20 border border-[#D4AF37]/40 px-2.5 py-0.5 rounded-full text-[11px] font-bold text-[#D4AF37]">
            {isAr ? "كاش:" : "Cash:"} {settings.etisalatCashNumber}
          </span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 select-none">
            <div
              id="brand-logo-icon"
              title={isAr ? "انقر لعرض وتحميل الشعار بدقة عالية" : "Click to view and download HD logo"}
              onClick={() => setIsLogoModalOpen(true)}
              className="relative w-9 h-9 sm:w-11 sm:h-11 rounded-xl overflow-hidden border border-[#D4AF37]/50 shadow-md shadow-[#D4AF37]/20 hover:border-[#D4AF37] hover:scale-105 transition-all duration-300 bg-[#121212] flex-shrink-0 cursor-pointer group"
            >
              <img
                src={settings.logoUrl || appLogo}
                alt={settings.platformName || "اتعلم ببساطة"}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
              </div>
            </div>
            <div
              id="brand-logo-text"
              onClick={() => handleNavClick("home")}
              className="cursor-pointer group"
            >
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-2xl font-bold tracking-tight text-white group-hover:text-[#D4AF37] transition">
                  {isAr ? (
                    <>
                      اتعلم <span className="text-[#D4AF37]">ببساطة</span>
                    </>
                  ) : (
                    <>
                      Learn <span className="text-[#D4AF37]">Simply</span>
                    </>
                  )}
                </span>
                <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30">
                  {isAr ? "ذكية" : "Smart"}
                </span>
              </div>
              <p className="text-[11px] text-gray-400 hidden sm:block">
                {isAr ? "المنصة التعليمية الأولى بأسلوب مبسط" : "Learn Simply & Effectively"}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm text-gray-400 mr-8">
            <button
              id="nav-home"
              onClick={() => handleNavClick("home")}
              className={`transition-colors font-medium ${
                activeView === "home"
                  ? "text-[#D4AF37] font-bold"
                  : "text-gray-400 hover:text-[#D4AF37]"
              }`}
            >
              {isAr ? "الرئيسية" : "Home"}
            </button>

            <button
              id="nav-courses"
              onClick={() => handleNavClick("courses")}
              className={`transition-colors font-medium ${
                activeView === "courses"
                  ? "text-[#D4AF37] font-bold"
                  : "text-gray-400 hover:text-[#D4AF37]"
              }`}
            >
              {isAr ? "الكورسات" : "Courses"}
            </button>

            <button
              id="nav-ai-assistant"
              onClick={() => handleNavClick("ai-assistant")}
              className={`flex items-center gap-1.5 transition-colors font-medium ${
                activeView === "ai-assistant"
                  ? "text-[#D4AF37] font-bold"
                  : "text-gray-400 hover:text-[#D4AF37]"
              }`}
            >
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>{isAr ? "مساعد الذكاء الاصطناعي" : "AI Assistant"}</span>
            </button>

            <button
              id="nav-support"
              onClick={() => handleNavClick("support")}
              className={`flex items-center gap-1.5 transition-colors font-medium ${
                activeView === "support"
                  ? "text-[#D4AF37] font-bold"
                  : "text-gray-400 hover:text-[#D4AF37]"
              }`}
            >
              <LifeBuoy className="w-4 h-4 text-[#D4AF37]" />
              <span>{isAr ? "الدعم الفني" : "Support"}</span>
            </button>

            <button
              id="nav-messenger"
              onClick={() => handleNavClick("messenger")}
              className={`flex items-center gap-1.5 transition-colors font-medium relative ${
                activeView === "messenger"
                  ? "text-[#D4AF37] font-bold"
                  : "text-gray-400 hover:text-[#D4AF37]"
              }`}
            >
              <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
              <span>{isAr ? "المراسلة" : "Messenger"}</span>
              {unreadMessengerCount > 0 && (
                <span className="min-w-[16px] h-4 px-1 rounded-full bg-[#D4AF37] text-black font-black text-[9px] flex items-center justify-center animate-bounce">
                  {unreadMessengerCount}
                </span>
              )}
            </button>

            {user && (
              <button
                id="nav-student-dashboard"
                onClick={() => handleNavClick("student-dashboard")}
                className={`flex items-center gap-1.5 transition-colors font-medium ${
                  activeView === "student-dashboard"
                    ? "text-[#D4AF37] font-bold"
                    : "text-gray-400 hover:text-[#D4AF37]"
                }`}
              >
                <LayoutDashboard className="w-4 h-4 text-blue-400" />
                <span>{isAr ? "لوحة الطالب" : "My Dashboard"}</span>
              </button>
            )}

            {isAdmin && (
              <button
                id="nav-admin-dashboard"
                onClick={() => handleNavClick("admin-dashboard")}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition ${
                  activeView === "admin-dashboard"
                    ? "bg-red-500/20 text-red-300 border border-red-500/40"
                    : "text-red-400 hover:text-red-300 border border-red-500/20 bg-red-950/30"
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
                <span>{isAr ? "لوحة الأدمن" : "Admin Panel"}</span>
              </button>
            )}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Language Switcher */}
            <button
              id="lang-toggle-btn"
              onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
              className="text-xs border border-white/20 px-3 py-1.5 rounded text-gray-300 hover:text-white hover:border-[#D4AF37] transition-colors"
              title={isAr ? "Switch to English" : "التبديل إلى العربية"}
            >
              {language === "ar" ? "English" : "العربية"}
            </button>

            {/* User Account Controls */}
            {user ? (
              <div className="relative">
                <button
                  id="user-menu-btn"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-[#1A1A1A] hover:border-[#D4AF37]/50 text-white transition"
                >
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] flex items-center justify-center text-white font-bold text-xs shadow-sm">
                    {user.displayName ? user.displayName[0].toUpperCase() : "ط"}
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-xs font-bold leading-none text-white truncate max-w-[110px]">
                      {user.displayName}
                    </p>
                    <span className="text-[10px] text-[#D4AF37] font-semibold">
                      {isAdmin ? (isAr ? "مشرف" : "Admin") : (isAr ? "طالب" : "Student")}
                    </span>
                  </div>
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div
                    id="user-dropdown-menu"
                    className="absolute left-0 mt-2 w-56 rounded-2xl bg-[#151515] border border-white/10 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-200"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="p-2 border-b border-white/10 mb-1">
                      <p className="text-xs font-bold text-white truncate">{user.displayName}</p>
                      <p className="text-[11px] text-gray-400 truncate">{user.email}</p>
                    </div>

                    <button
                      onClick={() => {
                        handleNavClick("student-dashboard");
                        setUserDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-gray-300 hover:bg-[#1A1A1A] hover:text-[#D4AF37] rounded-xl transition"
                    >
                      <LayoutDashboard className="w-4 h-4 text-blue-400" />
                      <span>{isAr ? "لوحة الطالب" : "My Dashboard"}</span>
                    </button>

                    <button
                      onClick={() => {
                        handleNavClick("support");
                        setUserDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-gray-300 hover:bg-[#1A1A1A] hover:text-[#D4AF37] rounded-xl transition"
                    >
                      <LifeBuoy className="w-4 h-4 text-[#D4AF37]" />
                      <span>{isAr ? "الدعم الفني" : "Support"}</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          handleNavClick("admin-dashboard");
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-red-300 hover:bg-red-950/40 rounded-xl transition"
                      >
                        <ShieldCheck className="w-4 h-4 text-red-400" />
                        <span>{isAr ? "لوحة الأدمن" : "Admin Dashboard"}</span>
                      </button>
                    )}

                    <div className="border-t border-white/10 my-1"></div>

                    <button
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-gray-400 hover:text-red-400 hover:bg-red-950/30 rounded-xl transition"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{isAr ? "تسجيل الخروج" : "Sign Out"}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <button
                  id="login-header-btn"
                  onClick={() => {
                    setAuthModalMode("login");
                    setIsAuthModalOpen(true);
                  }}
                  className="text-sm text-gray-300 hover:text-white transition-colors"
                >
                  {isAr ? "تسجيل دخول" : "Log In"}
                </button>
                <button
                  id="register-header-btn"
                  onClick={() => {
                    setAuthModalMode("register");
                    setIsAuthModalOpen(true);
                  }}
                  className="bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white px-5 py-1.5 rounded-full text-sm font-bold hover:brightness-110 transition-all shadow-md shadow-[#D4AF37]/20 cursor-pointer"
                >
                  {isAr ? "ابدأ الآن" : "Get Started"}
                </button>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="md:hidden border-t border-slate-800 bg-[#0B0F17] px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-4 duration-200 shadow-2xl"
        >
          <button
            onClick={() => handleNavClick("home")}
            className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800"
          >
            {isAr ? "الرئيسية" : "Home"}
          </button>
          <button
            onClick={() => handleNavClick("courses")}
            className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800"
          >
            {isAr ? "الكورسات والمسارات" : "Courses & Tracks"}
          </button>
          <button
            onClick={() => handleNavClick("ai-assistant")}
            className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-amber-400 hover:bg-slate-800 flex items-center justify-between"
          >
            <span>{isAr ? "مساعد اتعلم ببساطة AI" : "AI Assistant"}</span>
            <Sparkles className="w-4 h-4" />
          </button>

          <button
            onClick={() => handleNavClick("support")}
            className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 flex items-center justify-between"
          >
            <span>{isAr ? "الدعم الفني والرد الآلي" : "Technical Support"}</span>
            <LifeBuoy className="w-4 h-4 text-[#D4AF37]" />
          </button>

          <button
            onClick={() => handleNavClick("messenger")}
            className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-amber-300 hover:bg-slate-800 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <span>{isAr ? "المراسلة الداخلية" : "Internal Messenger"}</span>
              {unreadMessengerCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-[#D4AF37] text-black font-black text-[10px]">
                  {unreadMessengerCount}
                </span>
              )}
            </div>
            <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
          </button>

          {user && (
            <button
              onClick={() => handleNavClick("student-dashboard")}
              className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-blue-400 hover:bg-slate-800"
            >
              {isAr ? "لوحة الطالب (كورساتي والمدفوعات)" : "My Dashboard"}
            </button>
          )}

          {isAdmin && (
            <button
              onClick={() => handleNavClick("admin-dashboard")}
              className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-bold text-red-400 bg-red-950/30 border border-red-500/30"
            >
              {isAr ? "لوحة الأدمن (الموافقة على التحويلات والإعدادات)" : "Admin Dashboard"}
            </button>
          )}

          <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
            <span>{isAr ? "رقم اتصالات كاش الرسمي:" : "Etisalat Cash Number:"}</span>
            <span className="font-bold text-amber-400 bg-slate-900 px-2 py-1 rounded border border-amber-500/30">
              {settings.etisalatCashNumber}
            </span>
          </div>
        </div>
      )}

      {/* Logo Download & HD Preview Modal */}
      {isLogoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#141414] border border-[#D4AF37]/40 rounded-3xl p-6 shadow-2xl space-y-5 text-center">
            <button
              onClick={() => setIsLogoModalOpen(false)}
              className="absolute top-4 left-4 sm:left-auto sm:right-4 w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white flex items-center justify-center gap-2">
                <ImageIcon className="w-5 h-5 text-[#D4AF37]" />
                <span>{isAr ? "شعار منصة اتعلم ببساطة (HD)" : "Official Platform Logo (HD)"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isAr
                  ? "يمكنك تحميل الشعار الرسمي بدقة عالية واستخدامه في أي تصميم"
                  : "Download the official high-resolution logo image"}
              </p>
            </div>

            <div className="relative w-48 h-48 mx-auto rounded-3xl overflow-hidden border-2 border-[#D4AF37] shadow-xl shadow-[#D4AF37]/20 bg-black">
              <img
                src={settings.logoUrl || appLogo}
                alt="Logo HD"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="pt-2 flex flex-col gap-2.5">
              <a
                href={settings.logoUrl || appLogo}
                download="et3lem-bebasata-logo.jpg"
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 px-4 rounded-xl font-bold text-black bg-[#D4AF37] hover:bg-[#c49f2e] transition flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/30 text-sm cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{isAr ? "تحميل صورة الشعار (Download Image)" : "Download Logo Image"}</span>
              </a>

              <button
                type="button"
                onClick={() => setIsLogoModalOpen(false)}
                className="w-full py-2.5 px-4 rounded-xl font-medium text-gray-400 hover:text-white hover:bg-white/5 transition text-xs cursor-pointer"
              >
                {isAr ? "إغلاق النافذة" : "Close"}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
