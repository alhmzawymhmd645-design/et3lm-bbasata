import React, { useEffect, useState, useRef } from "react";
import { useApp } from "../context/AppContext";
import { Course, Lesson, QuizQuestion } from "../types";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import { DynamicVideoWatermark } from "./ContentProtection";
import {
  ArrowRight,
  ArrowLeft,
  PlayCircle,
  CheckCircle2,
  Lock,
  Sparkles,
  BookOpen,
  HelpCircle,
  Code,
  Send,
  Loader2,
  Award,
  ChevronRight,
  ChevronLeft,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  ShieldAlert,
  EyeOff,
  FileText,
  Download,
  Layout,
  Image as ImageIcon,
  X,
} from "lucide-react";

export const LessonPlayer: React.FC = () => {
  const {
    selectedCourse,
    selectedLesson,
    setSelectedLesson,
    setActiveView,
    isEnrolledInCourse,
    markLessonCompleted,
    enrollments,
    language,
    user,
    setIsAuthModalOpen,
  } = useApp();

  const isAr = language === "ar";
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"syllabus" | "ai-tutor" | "quiz" | "notes">("syllabus");

  // AI Assistant States
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiResponse, setAiResponse] = useState<string>("");
  const [aiLoading, setAiLoading] = useState(false);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);

  const currentEnrollment = enrollments.find(
    (e) => e.courseId === selectedCourse?.id
  );
  const isEnrolled = selectedCourse ? isEnrolledInCourse(selectedCourse.id) : false;

  // Load course lessons
  useEffect(() => {
    if (!selectedCourse) return;
    async function fetchLessons() {
      setLoading(true);
      try {
        const q = query(
          collection(db, "lessons"),
          where("courseId", "==", selectedCourse!.id)
        );
        const snap = await getDocs(q);
        const list: Lesson[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as Lesson);
        });
        list.sort((a, b) => (a.order || 0) - (b.order || 0));
        setLessons(list);

        // If no lesson currently selected, select first
        if (!selectedLesson && list.length > 0) {
          setSelectedLesson(list[0]);
        }
      } catch (err) {
        console.error("Error loading lessons:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchLessons();
  }, [selectedCourse]);

  if (!selectedCourse) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-6 text-center space-y-4">
        <BookOpen className="w-12 h-12 text-gray-500" />
        <h3 className="text-xl font-bold text-white">
          {isAr ? "لم يتم اختيار كورس بعد" : "No Course Selected"}
        </h3>
        <button
          onClick={() => setActiveView("courses")}
          className="px-5 py-2.5 rounded-xl font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white hover:brightness-110 cursor-pointer shadow-lg shadow-[#D4AF37]/20"
        >
          {isAr ? "تصفح الكورسات" : "Browse Courses"}
        </button>
      </div>
    );
  }

  const currentLessonIndex = lessons.findIndex((l) => l.id === selectedLesson?.id);
  const isCompleted = selectedLesson
    ? currentEnrollment?.completedLessons?.includes(selectedLesson.id)
    : false;

  const handleNextLesson = () => {
    if (currentLessonIndex < lessons.length - 1) {
      setSelectedLesson(lessons[currentLessonIndex + 1]);
    }
  };

  const handlePrevLesson = () => {
    if (currentLessonIndex > 0) {
      setSelectedLesson(lessons[currentLessonIndex - 1]);
    }
  };

  const handleMarkComplete = async () => {
    if (selectedCourse && selectedLesson) {
      await markLessonCompleted(selectedCourse.id, selectedLesson.id);
    }
  };

  // Gemini AI Call Handler
  const handleAiAction = async (
    actionType: "explain" | "summary" | "generate-quiz" | "challenge" | "chat"
  ) => {
    if (!selectedLesson) return;
    setAiLoading(true);
    setAiResponse("");

    try {
      let endpoint = "/api/ai-assistant";
      let payload: any = {
        action: actionType,
        courseTitle: selectedCourse.title,
        lessonTitle: selectedLesson.title,
        lessonDescription: selectedLesson.description,
        userPrompt: aiPrompt,
        language,
      };

      if (actionType === "generate-quiz") {
        endpoint = "/api/generate-quiz";
      }

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.error) {
        setAiResponse(`خطأ: ${data.error}`);
      } else if (actionType === "generate-quiz" && data.quiz) {
        setQuizQuestions(data.quiz);
        setSelectedAnswers({});
        setQuizSubmitted(false);
        setActiveTab("quiz");
      } else {
        setAiResponse(data.reply || data.summary || data.explanation || "تم تجهيز الرد بنجاح.");
      }
    } catch (err: any) {
      console.error("AI Error:", err);
      setAiResponse(
        isAr
          ? "تعذر الاتصال بمساعد الذكاء الاصطناعي حالياً، يرجى المحاولة لاحقاً."
          : "Could not connect to AI Tutor at the moment."
      );
    } finally {
      setAiLoading(false);
    }
  };

  // Render Video Player Embed or Video Tag
  const renderVideoPlayer = () => {
    if (!selectedLesson) {
      return (
        <div className="aspect-video bg-[#0A0A0A] flex items-center justify-center text-gray-500 rounded-2xl border border-white/10">
          {isAr ? "اختر درساً للبدء" : "Select a lesson to begin"}
        </div>
      );
    }

    const canPlay = isEnrolled || selectedLesson.isFreePreview;

    if (!canPlay) {
      return (
        <div className="aspect-video bg-[#0A0A0A] flex flex-col items-center justify-center p-6 text-center space-y-4 border border-[#D4AF37]/30 rounded-2xl">
          <div className="w-14 h-14 rounded-full bg-[#151515] border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shadow-xl">
            <Lock className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-md">
            <h4 className="text-lg font-bold text-white">
              {isAr ? "هذا الدرس مخصص للمشتركين" : "This lesson requires enrollment"}
            </h4>
            <p className="text-xs text-gray-400">
              {isAr
                ? "اشترك الآن عبر محفظة Etisalat Cash لمشاهدة جميع دروس الكورس والحصول على الشهادة."
                : "Enroll via Etisalat Cash to access all lessons and verified certificate."}
            </p>
          </div>
          <button
            onClick={() => setActiveView("courses")}
            className="px-6 py-2.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-lg shadow-[#D4AF37]/25 text-xs sm:text-sm cursor-pointer"
          >
            {isAr ? "الاشتراك في الكورس (Etisalat Cash)" : "Enroll in Course"}
          </button>
        </div>
      );
    }

    const url = selectedLesson.videoUrl || "";

    if (url.includes("youtube.com") || url.includes("youtu.be")) {
      let embedUrl = url;
      if (url.includes("watch?v=")) {
        embedUrl = url.replace("watch?v=", "embed/");
      }
      return (
        <div className="relative aspect-video rounded-2xl overflow-hidden bg-[#0A0A0A] border border-white/10 shadow-2xl group select-none">
          {/* Dynamic Floating Watermark */}
          <DynamicVideoWatermark studentIdentifier={user?.email || user?.name || "طالب معتمد"} />

          <iframe
            src={embedUrl}
            title={selectedLesson.title}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
            allowFullScreen
          ></iframe>
        </div>
      );
    }

    // Default HTML5 video for MP4 / Cloud storage with Full DRM and Anti-Download Hardening
    return (
      <div
        onContextMenu={(e) => e.preventDefault()}
        className="relative aspect-video rounded-2xl overflow-hidden bg-[#0A0A0A] border border-white/10 shadow-2xl select-none"
      >
        {/* Dynamic Floating DRM Watermark with Student Identity */}
        <DynamicVideoWatermark studentIdentifier={user?.email || user?.name || "طالب معتمد"} />

        {/* Security Shield Watermark Tag (Bottom Left) */}
        <div className="absolute bottom-3 left-3 z-20 pointer-events-none px-2.5 py-1 rounded-md bg-black/70 border border-white/20 text-[10px] font-mono text-[#D4AF37] flex items-center gap-1.5 backdrop-blur-sm">
          <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>DRM Encrypted • اتعلم ببساطة</span>
        </div>

        <video
          key={selectedLesson.id}
          src={url}
          controls
          autoPlay
          controlsList="nodownload noplaybackrate"
          disablePictureInPicture
          onContextMenu={(e) => e.preventDefault()}
          className="w-full h-full object-contain select-none"
          onEnded={handleMarkComplete}
        >
          {isAr ? "متصفحك لا يدعم تشغيل هذا الفيديو." : "Your browser does not support HTML5 video."}
        </video>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 select-none">
      {/* Top Breadcrumb & Progress Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 rounded-2xl bg-[#151515] border border-white/10 shadow-lg">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveView("courses")}
            className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/5 transition cursor-pointer"
            title={isAr ? "العودة للكورسات" : "Back to courses"}
          >
            {isAr ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          </button>
          <div>
            <span className="text-[11px] text-[#D4AF37] font-bold uppercase tracking-wider">
              {selectedCourse.category}
            </span>
            <h1 className="text-base sm:text-lg font-bold text-white line-clamp-1">
              {selectedCourse.title}
            </h1>
          </div>
        </div>

        {/* Security & DRM Status Badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
          <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span className="text-[11px]">
            {isAr
              ? "المحتوى مشفر ومحمي بالعلامة المائية الرقمية"
              : "DRM Protected & Watermarked"}
          </span>
        </div>

        {/* Progress Display */}
        {isEnrolled && currentEnrollment && (
          <div className="w-full md:w-64 space-y-1.5 bg-[#0A0A0A] p-2.5 rounded-xl border border-white/10">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-300">{isAr ? "نسبة إنجاز الكورس:" : "Progress:"}</span>
              <span className="text-[#D4AF37] font-mono">{currentEnrollment.progress}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] transition-all duration-500 rounded-full"
                style={{ width: `${currentEnrollment.progress}%` }}
              ></div>
            </div>
          </div>
        )}
      </div>

      {/* Main Grid: Video Player + Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Main Column: Video Player & Lesson Info */}
        <div className="lg:col-span-8 space-y-5">
          {/* Player Box */}
          {renderVideoPlayer()}

          {/* Lesson Controls & Description */}
          {selectedLesson && (
            <div className="p-6 rounded-2xl bg-[#151515] border border-white/10 space-y-4 shadow-lg">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#D4AF37] font-mono">
                      {isAr ? "الدرس" : "Lesson"} {currentLessonIndex + 1}
                    </span>
                    {selectedLesson.isFreePreview && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                        {isAr ? "معاينة مجانية" : "Free Preview"}
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl font-bold text-white">
                    {selectedLesson.title}
                  </h2>
                </div>

                {/* Mark as Completed Button */}
                {isEnrolled && (
                  <button
                    onClick={handleMarkComplete}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
                      isCompleted
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                        : "bg-[#0A0A0A] hover:bg-white/5 text-gray-200 border border-white/10"
                    }`}
                  >
                    <CheckCircle2 className={`w-4 h-4 ${isCompleted ? "text-emerald-400" : "text-gray-400"}`} />
                    <span>{isCompleted ? (isAr ? "مكتمل ✓" : "Completed") : (isAr ? "تحديد كمكتمل" : "Mark Complete")}</span>
                  </button>
                )}
              </div>

              {/* Lesson Description */}
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                {selectedLesson.description}
              </p>

              {/* Lesson Homework & Interactive Tools */}
              {(selectedLesson.homeworkFileUrl || selectedLesson.interactiveBoardUrl || (selectedLesson.lessonImages && selectedLesson.lessonImages.length > 0)) && (
                <div className="space-y-3 pt-3 border-t border-white/10">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>{isAr ? "ملحقات وموارد الدرس" : "Lesson Resources & Materials"}</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Homework File Download */}
                    {selectedLesson.homeworkFileUrl && (
                      <div className="p-3.5 rounded-xl bg-[#0A0A0A] border border-blue-500/30 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 flex-shrink-0">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-white truncate">
                              {selectedLesson.homeworkFileName || (isAr ? "ملف واجب الدرس" : "Homework File")}
                            </p>
                            <p className="text-[10px] text-blue-300">
                              {isAr ? "جاهز للتحميل والمذاكرة" : "Downloadable resource"}
                            </p>
                          </div>
                        </div>

                        <a
                          href={selectedLesson.homeworkFileUrl}
                          download
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition flex-shrink-0 cursor-pointer shadow"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>{isAr ? "تحميل" : "Download"}</span>
                        </a>
                      </div>
                    )}

                    {/* Interactive Board Button */}
                    {selectedLesson.interactiveBoardUrl && (
                      <div className="p-3.5 rounded-xl bg-[#0A0A0A] border border-purple-500/30 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 flex-shrink-0">
                            <Layout className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-white truncate">
                              {isAr ? "اللوحة التفاعلية (Interactive Board)" : "Interactive Whiteboard"}
                            </p>
                            <p className="text-[10px] text-purple-300">
                              {isAr ? "فتح في نافذة جديدة" : "Open canvas in new tab"}
                            </p>
                          </div>
                        </div>

                        <a
                          href={selectedLesson.interactiveBoardUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white flex items-center gap-1.5 transition flex-shrink-0 cursor-pointer shadow"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>{isAr ? "فتح اللوحة" : "Open"}</span>
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Lesson Images Gallery */}
                  {selectedLesson.lessonImages && selectedLesson.lessonImages.length > 0 && (
                    <div className="p-3.5 rounded-xl bg-[#0A0A0A] border border-white/10 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{isAr ? "مخططات وصور توضيحية للدرس" : "Lesson Diagrams & Images"}</span>
                        </span>
                        <span className="text-[10px] text-gray-400">
                          {selectedLesson.lessonImages.length} {isAr ? "صور" : "images"}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {selectedLesson.lessonImages.map((img, idx) => (
                          <div
                            key={idx}
                            onClick={() => setSelectedImagePreview(img)}
                            className="aspect-video rounded-lg overflow-hidden bg-black/60 border border-white/10 hover:border-[#D4AF37] transition cursor-pointer relative group"
                          >
                            <img src={img} alt={`Diagram ${idx + 1}`} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-[11px] font-bold">
                              {isAr ? "تكبير" : "Zoom"}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Navigation buttons: Prev / Next */}
              <div className="flex items-center justify-between pt-3 border-t border-white/10">
                <button
                  onClick={handlePrevLesson}
                  disabled={currentLessonIndex === 0}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-300 hover:text-white bg-[#0A0A0A] border border-white/10 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition cursor-pointer"
                >
                  {isAr ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                  <span>{isAr ? "الدرس السابق" : "Previous Lesson"}</span>
                </button>

                <button
                  onClick={handleNextLesson}
                  disabled={currentLessonIndex === lessons.length - 1}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <span>{isAr ? "الدرس التالي" : "Next Lesson"}</span>
                  {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar: Tabs for (Syllabus, AI Tutor, Quiz) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Tab Navigation */}
          <div className="flex items-center gap-1 p-1 rounded-2xl bg-[#151515] border border-white/10">
            <button
              onClick={() => setActiveTab("syllabus")}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === "syllabus"
                  ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-sm"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>{isAr ? "المنهاج" : "Syllabus"}</span>
            </button>

            <button
              onClick={() => setActiveTab("ai-tutor")}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === "ai-tutor"
                  ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-sm"
                  : "text-[#D4AF37] hover:brightness-125"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isAr ? "مساعد AI" : "AI Tutor"}</span>
            </button>

            <button
              onClick={() => setActiveTab("quiz")}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === "quiz"
                  ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-sm"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{isAr ? "اختبار" : "Quiz"}</span>
            </button>
          </div>

          {/* TAB 1: SYLLABUS LIST */}
          {activeTab === "syllabus" && (
            <div className="p-4 rounded-2xl bg-[#151515] border border-white/10 space-y-3 max-h-[550px] overflow-y-auto shadow-lg">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-xs font-bold text-white">
                  {isAr ? "جميع الدروس" : "All Lessons"} ({lessons.length})
                </span>
                <span className="text-[11px] text-gray-400">{selectedCourse.duration}</span>
              </div>

              <div className="space-y-1.5">
                {lessons.map((l, idx) => {
                  const isCurrent = l.id === selectedLesson?.id;
                  const isDone = currentEnrollment?.completedLessons?.includes(l.id);
                  const canAccess = isEnrolled || l.isFreePreview;

                  return (
                    <div
                      key={l.id}
                      onClick={() => canAccess && setSelectedLesson(l)}
                      className={`p-3 rounded-xl flex items-center justify-between gap-2.5 transition cursor-pointer ${
                        isCurrent
                          ? "bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#D4AF37]"
                          : canAccess
                          ? "bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/5 text-gray-300"
                          : "bg-[#0A0A0A]/40 border border-white/5 text-gray-600 opacity-60 cursor-not-allowed"
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                            isDone
                              ? "bg-emerald-500/20 text-emerald-400"
                              : isCurrent
                              ? "bg-[#D4AF37] text-white"
                              : "bg-[#0A0A0A] text-gray-400 border border-white/10"
                          }`}
                        >
                          {isDone ? <CheckCircle2 className="w-3.5 h-3.5" /> : idx + 1}
                        </div>
                        <span className="text-xs font-bold truncate text-white">
                          {l.title}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className="text-[10px] font-mono text-gray-400">{l.duration}</span>
                        {!canAccess && <Lock className="w-3.5 h-3.5 text-gray-600" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: GEMINI AI TUTOR */}
          {activeTab === "ai-tutor" && (
            <div className="p-4 rounded-2xl bg-[#151515] border border-white/10 space-y-4 shadow-lg">
              <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">
                    {isAr ? "مساعد اتعلم ببساطة الذكي (Gemini AI)" : "Gemini Smart Assistant"}
                  </h4>
                  <p className="text-[10px] text-gray-400">
                    {isAr ? "جاهز لشرح أو تلخيص الدرس الحالي" : "Trained on this lesson's topic"}
                  </p>
                </div>
              </div>

              {/* Quick AI Action Pills */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleAiAction("summary")}
                  disabled={aiLoading}
                  className="p-2 rounded-xl bg-[#0A0A0A] border border-white/10 hover:border-[#D4AF37]/40 text-[11px] font-bold text-gray-200 hover:text-[#D4AF37] flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{isAr ? "لخص لي الدرس" : "Summarize"}</span>
                </button>

                <button
                  onClick={() => handleAiAction("explain")}
                  disabled={aiLoading}
                  className="p-2 rounded-xl bg-[#0A0A0A] border border-white/10 hover:border-blue-500/40 text-[11px] font-bold text-gray-200 hover:text-blue-300 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                  <span>{isAr ? "اشرح بالتفصيل" : "Explain Step-by-Step"}</span>
                </button>

                <button
                  onClick={() => handleAiAction("challenge")}
                  disabled={aiLoading}
                  className="p-2 rounded-xl bg-[#0A0A0A] border border-white/10 hover:border-emerald-500/40 text-[11px] font-bold text-gray-200 hover:text-emerald-300 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Code className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{isAr ? "تحدي كود عملي" : "Code Challenge"}</span>
                </button>

                <button
                  onClick={() => handleAiAction("generate-quiz")}
                  disabled={aiLoading}
                  className="p-2 rounded-xl bg-[#0A0A0A] border border-white/10 hover:border-purple-500/40 text-[11px] font-bold text-gray-200 hover:text-purple-300 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Award className="w-3.5 h-3.5 text-purple-400" />
                  <span>{isAr ? "اختبرني بالذكاء" : "Create Quiz"}</span>
                </button>
              </div>

              {/* AI Response Box */}
              {aiLoading ? (
                <div className="p-6 rounded-xl bg-[#0A0A0A] border border-white/10 flex flex-col items-center justify-center gap-2 text-xs text-[#D4AF37]">
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span>{isAr ? "المساعد الذكي يقوم بصياغة الرد..." : "Gemini is analyzing..."}</span>
                </div>
              ) : aiResponse ? (
                <div className="p-3.5 rounded-xl bg-[#0A0A0A] border border-[#D4AF37]/30 text-xs text-gray-200 leading-relaxed max-h-60 overflow-y-auto whitespace-pre-line space-y-2">
                  <p className="font-semibold text-[#D4AF37] text-[11px]">
                    {isAr ? "إجابة المساعد الذكي:" : "AI Response:"}
                  </p>
                  {aiResponse}
                </div>
              ) : null}

              {/* Custom AI Chat Input */}
              <div className="relative pt-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAiAction("chat")}
                  placeholder={
                    isAr
                      ? "اسأل المساعد عن أي نقطة في هذا الدرس..."
                      : "Ask anything about this lesson..."
                  }
                  className="w-full pr-4 pl-10 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
                />
                <button
                  onClick={() => handleAiAction("chat")}
                  disabled={aiLoading || !aiPrompt.trim()}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white hover:brightness-110 disabled:opacity-40 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: QUIZ */}
          {activeTab === "quiz" && (
            <div className="p-4 rounded-2xl bg-[#151515] border border-white/10 space-y-4 max-h-[550px] overflow-y-auto shadow-lg">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-[#D4AF37]" />
                  <span>{isAr ? "اختبار الفهم السريع" : "Quick Lesson Quiz"}</span>
                </h4>
                <button
                  onClick={() => handleAiAction("generate-quiz")}
                  className="text-[11px] text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>{isAr ? "توليد أسئلة جديدة" : "New Questions"}</span>
                </button>
              </div>

              {quizQuestions.length === 0 ? (
                <div className="text-center py-8 space-y-3">
                  <Award className="w-10 h-10 text-[#D4AF37]/60 mx-auto" />
                  <p className="text-xs text-gray-400">
                    {isAr
                      ? "اضغط الزر أدناه لتوليد اختبار فوري لهذا الدرس بالذكاء الاصطناعي!"
                      : "Generate an instant quiz for this lesson with Gemini AI."}
                  </p>
                  <button
                    onClick={() => handleAiAction("generate-quiz")}
                    disabled={aiLoading}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 transition cursor-pointer shadow-md"
                  >
                    {aiLoading ? "جاري التوليد..." : isAr ? "ابدأ الاختبار الآن" : "Generate Quiz"}
                  </button>
                </div>
              ) : (
                <div className="space-y-4 text-xs">
                  {quizQuestions.map((q, qIdx) => (
                    <div key={qIdx} className="p-3 rounded-xl bg-[#0A0A0A] border border-white/10 space-y-2">
                      <p className="font-bold text-white">
                        {qIdx + 1}. {q.question}
                      </p>
                      <div className="space-y-1.5">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = selectedAnswers[qIdx] === optIdx;
                          const isCorrect = q.correctIndex === optIdx;
                          let optStyle = "bg-[#151515] border-white/10 text-gray-300";

                          if (quizSubmitted) {
                            if (isCorrect) {
                              optStyle = "bg-emerald-950/80 border-emerald-500 text-emerald-200";
                            } else if (isSelected && !isCorrect) {
                              optStyle = "bg-red-950/80 border-red-500 text-red-200";
                            }
                          } else if (isSelected) {
                            optStyle = "bg-[#D4AF37]/20 border-[#D4AF37] text-[#D4AF37]";
                          }

                          return (
                            <button
                              key={optIdx}
                              disabled={quizSubmitted}
                              onClick={() =>
                                setSelectedAnswers((prev) => ({ ...prev, [qIdx]: optIdx }))
                              }
                              className={`w-full text-right p-2 rounded-lg border text-xs transition cursor-pointer ${optStyle}`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <p className="text-[11px] text-gray-400 italic pt-1 border-t border-white/5">
                          💡 {q.explanation}
                        </p>
                      )}
                    </div>
                  ))}

                  {!quizSubmitted ? (
                    <button
                      onClick={() => setQuizSubmitted(true)}
                      className="w-full py-2.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 cursor-pointer shadow-md"
                    >
                      {isAr ? "تصحيح الإجابات" : "Submit Answers"}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleAiAction("generate-quiz")}
                      className="w-full py-2.5 rounded-xl font-bold text-gray-200 bg-[#151515] hover:bg-white/5 border border-white/10 cursor-pointer"
                    >
                      {isAr ? "إعادة الاختبار بأسئلة أخرى" : "Try Another Quiz"}
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* LESSON IMAGE LIGHTBOX MODAL */}
      {selectedImagePreview && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedImagePreview(null)}
        >
          <div
            className="max-w-4xl max-h-[90vh] bg-[#151515] border border-white/10 rounded-3xl p-4 sm:p-6 relative space-y-3 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? "معاينة صورة ومخطط الدرس" : "Diagram Full Preview"}</span>
              </h4>
              <button
                onClick={() => setSelectedImagePreview(null)}
                className="p-1.5 rounded-lg bg-[#0A0A0A] text-gray-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <img
              src={selectedImagePreview}
              alt="Lesson Diagram Preview"
              className="max-h-[75vh] w-auto mx-auto object-contain rounded-xl bg-black border border-white/10"
            />
          </div>
        </div>
      )}
    </div>
  );
};
