import React, { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import {
  MessageSquare,
  X,
  Send,
  Bot,
  User,
  Sparkles,
  Headphones,
  Zap,
  Check,
  Minimize2,
  Maximize2,
  RefreshCw,
  Clock,
  Shield,
  HelpCircle,
} from "lucide-react";
import { MessengerMessage } from "../types";

export const InternalMessengerWidget: React.FC = () => {
  const { user, language, setActiveView } = useApp();
  const isAr = language === "ar";

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<MessengerMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [sending, setSending] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [hasGreeted, setHasGreeted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatScrollContainerRef = useRef<HTMLDivElement>(null);
  const isInitialLoadRef = useRef(true);

  const senderId = user ? (user.uid || (user as any).id) : "visitor_" + (typeof window !== "undefined" ? window.sessionStorage?.getItem("chat_guest_id") || (() => {
    const id = "guest_" + Math.random().toString(36).substring(2, 9);
    window.sessionStorage?.setItem("chat_guest_id", id);
    return id;
  })() : "guest_user");

  const senderName = user?.displayName || (user as any)?.name || (isAr ? "طالب زائر" : "Guest Student");
  const conversationId = `conv_internal_${senderId}`;

  // Fetch Conversation History
  const fetchMessages = async () => {
    try {
      const res = await fetch(`/api/messenger/conversation/${conversationId}`);
      if (res.ok) {
        const data = await res.json();
        if (data.conversation?.messages) {
          setMessages(data.conversation.messages);
        }
      }
    } catch (err) {
      console.error("Error fetching internal chat messages:", err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      isInitialLoadRef.current = true;
      fetchMessages();
      setUnreadCount(0);
      const timer = setInterval(fetchMessages, 4000);
      return () => clearInterval(timer);
    }
  }, [isOpen, conversationId]);

  useEffect(() => {
    if (isOpen && chatScrollContainerRef.current) {
      const container = chatScrollContainerRef.current;
      const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 120;
      if (isInitialLoadRef.current || isNearBottom || sending) {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: isInitialLoadRef.current ? "auto" : "smooth",
        });
        isInitialLoadRef.current = false;
      }
    }
  }, [messages, isOpen, sending]);

  // Initial Welcome Message for first time opening if empty
  useEffect(() => {
    if (isOpen && messages.length === 0 && !hasGreeted) {
      setHasGreeted(true);
      setMessages([
        {
          id: "msg_welcome",
          conversationId,
          senderId: "ai_bot",
          senderName: "المساعد الذكي",
          role: "ai",
          source: "ai",
          text: "أهلاً بك في منصة «اتعلم ببساطة» 👋✨\nأنا المساعد الذكي، كيف أستطيع مساعدتك اليوم بخصوص الكورسات البرمجية، الأسعار، أو طريقة الاشتراك والدفع عبر اتصالات كاش (01157783934)؟",
          createdAt: new Date().toISOString(),
          status: "delivered",
        },
      ]);
    }
  }, [isOpen, messages.length, hasGreeted, conversationId]);

  const handleSendMessage = async () => {
    if (!inputText.trim() || sending) return;
    const text = inputText.trim();
    setInputText("");
    setSending(true);

    const tempMsg: MessengerMessage = {
      id: `temp_${Date.now()}`,
      conversationId,
      senderId,
      senderName,
      role: "student",
      source: "internal_chat",
      text,
      createdAt: new Date().toISOString(),
      status: "delivered",
    };

    setMessages((prev) => [...prev, tempMsg]);

    try {
      const res = await fetch("/api/messenger/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId,
          senderId,
          senderName,
          senderEmail: user?.email || "",
          text,
          userRole: user?.role || "student",
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.aiReply) {
          setMessages((prev) => [...prev, data.aiReply]);
        }
      }
    } catch (err) {
      console.error("Error sending message:", err);
    } finally {
      setSending(false);
    }
  };

  const quickQuestions = [
    "كيف أشترك في كورس وأدفع عبر اتصالات كاش؟",
    "هل الشهادات مجانية ومعتمدة؟",
    "أريد التحدث مع المشرف الإداري",
  ];

  return (
    <>
      {/* FLOATING ACTION BUTTON */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 left-6 z-50 p-3.5 sm:px-5 sm:py-3.5 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-black shadow-2xl hover:scale-105 transition-all duration-300 flex items-center gap-2.5 font-black text-sm cursor-pointer group border border-[#D4AF37]/50"
          title="تواصل معنا عبر المراسلة الفورية"
        >
          <div className="relative">
            <MessageSquare className="w-6 h-6 text-black group-hover:rotate-12 transition-transform" />
            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border-2 border-black animate-pulse" />
          </div>
          <span className="hidden sm:inline">
            {isAr ? "مراسلة المنصة والدعم الذكي" : "Chat with Us"}
          </span>
          {unreadCount > 0 && (
            <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center font-bold">
              {unreadCount}
            </span>
          )}
        </button>
      )}

      {/* FLOATING MESSENGER CHAT MODAL */}
      {isOpen && (
        <div className="fixed bottom-6 left-4 sm:left-6 z-50 w-[92vw] sm:w-[390px] h-[560px] max-h-[85vh] bg-[#121212] border border-[#D4AF37]/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300">
          {/* Header */}
          <div className="p-4 bg-[#181818] border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] relative">
                <Bot className="w-5 h-5" />
                <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#181818]" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                  <span>المساعد الذكي لمنصة اتعلم ببساطة</span>
                </h3>
                <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>متصل الآن • رد فوري على مدار 24 ساعة</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  setIsOpen(false);
                  setActiveView("messenger");
                }}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#D4AF37] hover:text-white transition cursor-pointer"
                title="فتح في صفحة كاملة"
              >
                <Maximize2 className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick FAQ / Prompt Chips */}
          <div className="p-2 bg-[#141414] border-b border-white/5 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputText(q);
                }}
                className="px-2.5 py-1 rounded-full bg-[#1F1F1F] hover:bg-[#2A2A2A] text-[10px] text-gray-300 hover:text-white border border-white/10 transition whitespace-nowrap cursor-pointer flex-shrink-0"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Chat Messages Body */}
          <div ref={chatScrollContainerRef} className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#0A0A0A]/60">
            {messages.map((msg, i) => {
              const isStudent = msg.role === "student";
              const isAi = msg.role === "ai";
              const timeStr = new Date(msg.createdAt).toLocaleTimeString("ar-EG", {
                hour: "2-digit",
                minute: "2-digit",
              });

              return (
                <div
                  key={msg.id || i}
                  className={`flex flex-col ${isStudent ? "items-start" : "items-end"}`}
                >
                  <div className="flex items-center gap-1 mb-1 px-1">
                    <span className="text-[10px] font-bold text-gray-400">
                      {isStudent
                        ? "أنت"
                        : isAi
                        ? "المساعد الذكي (Gemini)"
                        : msg.senderName || "المشرف"}
                    </span>
                    <span className="text-[9px] text-gray-500 font-mono">{timeStr}</span>
                  </div>

                  <div
                    className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-md ${
                      isStudent
                        ? "bg-[#202020] text-white border border-white/10 rounded-tr-none"
                        : isAi
                        ? "bg-gradient-to-r from-emerald-950/90 to-[#12241b] text-emerald-100 border border-emerald-500/30 rounded-tl-none"
                        : "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-black font-semibold border border-[#D4AF37]/50 rounded-tl-none"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                  </div>
                </div>
              );
            })}
            {sending && (
              <div className="flex items-center gap-2 text-xs text-gray-400 py-1">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
                <span>جاري كتابة الرد الذكي...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Footer Input Box */}
          <div className="p-3 bg-[#141414] border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              placeholder="اكتب استفسارك هنا..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#1D1D1D] border border-white/10 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-[#D4AF37]"
            />
            <button
              onClick={handleSendMessage}
              disabled={sending || !inputText.trim()}
              className="p-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black transition cursor-pointer disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
