import React, { useState, useRef } from "react";
import { PlatformSettings } from "../../types";
import { uploadFileToPlatform, formatFileSize } from "../../lib/uploadHelper";
import {
  Upload,
  CreditCard,
  Loader2,
  Trash2,
  RefreshCw,
  AlertCircle,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

interface WalletBackgroundSettingsProps {
  settingsForm: PlatformSettings;
  setSettingsForm: React.Dispatch<React.SetStateAction<PlatformSettings>>;
  userEmail?: string;
  userRole?: string;
  isAr: boolean;
}

export const WalletBackgroundSettings: React.FC<WalletBackgroundSettingsProps> = ({
  settingsForm,
  setSettingsForm,
  userEmail,
  userRole,
  isAr,
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState("");
  const [fileInfo, setFileInfo] = useState<{ name: string; size: number } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const walletThemes = [
    {
      id: "gold",
      name: isAr ? "الذهب الفاخر (اتصالات كاش)" : "Gold Luxury",
      gradient: "from-[#1a1505] via-[#2a220a] to-[#120e03]",
      border: "border-[#D4AF37]/40",
      accent: "#D4AF37",
    },
    {
      id: "emerald",
      name: isAr ? "الزمرد الرقمي" : "Emerald Digital",
      gradient: "from-[#031c14] via-[#052b20] to-[#01140e]",
      border: "border-emerald-500/40",
      accent: "#10b981",
    },
    {
      id: "carbon",
      name: isAr ? "كاربون داكن" : "Dark Carbon",
      gradient: "from-[#18181b] via-[#27272a] to-[#09090b]",
      border: "border-gray-600/40",
      accent: "#e4e4e7",
    },
    {
      id: "sapphire",
      name: isAr ? "الياقوت الأزرق" : "Sapphire Royal",
      gradient: "from-[#081b33] via-[#0c2a52] to-[#041021]",
      border: "border-blue-500/40",
      accent: "#38bdf8",
    },
  ];

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
    if (!validTypes.includes(file.type)) {
      setUploadError(
        isAr
          ? "نوع الملف غير مدعوم. يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP."
          : "Invalid image format. Supported: JPG, PNG, WEBP."
      );
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setUploadError(
        isAr
          ? "حجم الصورة كبير جداً، الحد الأقصى 15 ميجابايت."
          : "Image size exceeds 15MB."
      );
      return;
    }

    setUploadError("");
    setIsUploading(true);
    setUploadProgress(10);
    setFileInfo({ name: file.name, size: file.size });

    try {
      const result = await uploadFileToPlatform({
        file,
        category: "wallet-background",
        userEmail,
        userRole,
        onProgress: (p) => setUploadProgress(p),
      });

      setSettingsForm((prev) => ({
        ...prev,
        walletBackgroundUrl: result.url,
      }));
    } catch (err: any) {
      console.error("Wallet background upload error:", err);
      setUploadError(err?.message || (isAr ? "فشل رفع خلفية المحفظة" : "Upload failed"));
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveCustomBg = () => {
    setSettingsForm((prev) => ({
      ...prev,
      walletBackgroundUrl: "",
    }));
    setFileInfo(null);
    setUploadError("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const currentTheme = walletThemes.find((t) => t.id === settingsForm.walletTheme) || walletThemes[0];

  return (
    <div className="p-5 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div>
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-[#D4AF37]" />
            <span>{isAr ? "خلفية ومظهر بطاقة المحفظة (Wallet Background & Theme)" : "Wallet Card Styling"}</span>
          </h4>
          <p className="text-xs text-gray-400 mt-0.5">
            {isAr
              ? "تخصيص مستقل لخلفية ومظهر بطاقة Etisalat Cash المعروضة للطلاب في بوابة الدفع ولوحة الطالب."
              : "Independent customization for the payment card backdrop in student modals."}
          </p>
        </div>

        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/30">
          {settingsForm.walletBackgroundUrl ? "Custom Texture" : `${currentTheme.name}`}
        </span>
      </div>

      {uploadError && (
        <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{uploadError}</span>
        </div>
      )}

      {/* Live Wallet Card Mockup */}
      <div className="p-1 max-w-md mx-auto">
        <div
          className={`relative rounded-2xl p-5 overflow-hidden border shadow-xl bg-gradient-to-br ${currentTheme.gradient} ${currentTheme.border}`}
        >
          {settingsForm.walletBackgroundUrl && (
            <img
              src={settingsForm.walletBackgroundUrl}
              alt="Wallet Card Background"
              className="absolute inset-0 w-full h-full object-cover opacity-35 mix-blend-overlay"
            />
          )}

          <div className="relative z-10 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-black/40 border border-white/10 flex items-center justify-center text-[#D4AF37]">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Etisalat Cash</p>
                  <p className="text-[10px] text-gray-400">اتعلم ببساطة Pay</p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                Official
              </span>
            </div>

            <div className="py-2">
              <p className="text-[10px] text-gray-400 uppercase tracking-wider">{isAr ? "رقم المحفظة المعتمد" : "Wallet Number"}</p>
              <p className="text-lg font-mono font-bold tracking-widest text-[#D4AF37]">
                {settingsForm.etisalatCashNumber || "011XXXXXXXX"}
              </p>
            </div>

            <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-white/10">
              <span>{settingsForm.platformName || "اتعلم ببساطة"}</span>
              <span className="flex items-center gap-1 text-emerald-400">
                <ShieldCheck className="w-3 h-3" />
                <span>{isAr ? "دفع مشفر وآمن" : "Secure"}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Theme Presets */}
      <div className="space-y-2 pt-2">
        <p className="text-xs font-semibold text-gray-300">
          {isAr ? "اختر نمط ولون بطاقة المحفظة:" : "Choose Wallet Theme:"}
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {walletThemes.map((theme) => {
            const isSelected = (settingsForm.walletTheme || "gold") === theme.id;
            return (
              <button
                key={theme.id}
                type="button"
                onClick={() => setSettingsForm((prev) => ({ ...prev, walletTheme: theme.id as any }))}
                className={`p-2.5 rounded-xl text-xs font-bold transition flex flex-col items-center gap-1.5 cursor-pointer border ${
                  isSelected
                    ? "bg-[#D4AF37]/20 border-[#D4AF37] text-white shadow"
                    : "bg-[#151515] border-white/10 text-gray-400 hover:text-white"
                }`}
              >
                <div className={`w-full h-6 rounded-lg bg-gradient-to-r ${theme.gradient} border ${theme.border}`} />
                <span className="text-[11px] truncate">{theme.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom Texture Upload */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-3 border-t border-white/10">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/jpg"
          onChange={handleFileSelect}
          className="hidden"
          id="wallet-bg-file-input"
        />

        <div className="text-xs text-gray-400">
          {settingsForm.walletBackgroundUrl ? (
            <span className="text-emerald-400 font-medium">
              {isAr ? "يتم تطبيق خلفية خاصة لبطاقة المحفظة حالياً." : "Custom texture applied."}
            </span>
          ) : (
            <span>{isAr ? "يمكنك رفع صورة ملمس أو نقش خاص بالبطاقة." : "Upload custom texture/graphic."}</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {settingsForm.walletBackgroundUrl && (
            <button
              type="button"
              onClick={handleRemoveCustomBg}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-red-950/70 text-red-300 border border-red-500/30 hover:bg-red-900 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            type="button"
            disabled={isUploading}
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#D4AF37] hover:bg-[#c49f2e] text-black flex items-center gap-1.5 transition shadow cursor-pointer disabled:opacity-50"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>{isAr ? `جاري الرفع ${uploadProgress}%...` : "Uploading..."}</span>
              </>
            ) : (
              <>
                <Upload className="w-3.5 h-3.5" />
                <span>{isAr ? "رفع خلفية لبطاقة المحفظة" : "Upload Wallet Texture"}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {isUploading && (
        <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-[#D4AF37] h-full transition-all duration-300"
            style={{ width: `${uploadProgress}%` }}
          />
        </div>
      )}
    </div>
  );
};
