import React, { useState, useRef } from "react";
import { Lesson } from "../../types";
import { uploadFileToPlatform, formatFileSize } from "../../lib/uploadHelper";
import {
  X,
  Video,
  Upload,
  FileText,
  Layout,
  Image as ImageIcon,
  Loader2,
  Trash2,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Plus,
  Play,
  ExternalLink,
  HelpCircle,
} from "lucide-react";

interface LessonModalProps {
  isOpen: boolean;
  onClose: () => void;
  courseId: string;
  courseTitle?: string;
  editingLesson?: Lesson | null;
  orderNumber: number;
  onSave: (lessonData: Partial<Lesson>) => Promise<void>;
  userEmail?: string;
  userRole?: string;
  isAr: boolean;
}

export const LessonModal: React.FC<LessonModalProps> = ({
  isOpen,
  onClose,
  courseId,
  courseTitle,
  editingLesson,
  orderNumber,
  onSave,
  userEmail,
  userRole,
  isAr,
}) => {
  const [formData, setFormData] = useState<Partial<Lesson>>({
    title: editingLesson?.title || "",
    description: editingLesson?.description || "",
    videoUrl: editingLesson?.videoUrl || "",
    duration: editingLesson?.duration || "15:00",
    order: editingLesson?.order ?? orderNumber,
    isFreePreview: editingLesson?.isFreePreview ?? false,
    homeworkFileUrl: editingLesson?.homeworkFileUrl || "",
    homeworkFileName: editingLesson?.homeworkFileName || "",
    interactiveBoardUrl: editingLesson?.interactiveBoardUrl || "",
    lessonImages: editingLesson?.lessonImages || [],
  });

  // Video Source Toggle: 'upload' vs 'url'
  const isExistingVideoUploaded =
    editingLesson?.videoUrl?.startsWith("/uploads/") ||
    editingLesson?.videoUrl?.includes(".mp4") ||
    editingLesson?.videoUrl?.includes(".webm");

  const [videoSourceMode, setVideoSourceMode] = useState<"upload" | "url">(
    isExistingVideoUploaded ? "upload" : "url"
  );

  // Video Upload States
  const [isVideoUploading, setIsVideoUploading] = useState(false);
  const [videoUploadProgress, setVideoUploadProgress] = useState(0);
  const [videoUploadError, setVideoUploadError] = useState("");
  const [videoFileInfo, setVideoFileInfo] = useState<{ name: string; size: number } | null>(null);

  // Homework File Upload States
  const [isHomeworkUploading, setIsHomeworkUploading] = useState(false);
  const [homeworkUploadProgress, setHomeworkUploadProgress] = useState(0);
  const [homeworkUploadError, setHomeworkUploadError] = useState("");
  const [homeworkFileInfo, setHomeworkFileInfo] = useState<{ name: string; size: number } | null>(
    editingLesson?.homeworkFileName ? { name: editingLesson.homeworkFileName, size: 0 } : null
  );

  // Lesson Images Upload States
  const [isImageUploading, setIsImageUploading] = useState(false);
  const [imageUploadProgress, setImageUploadProgress] = useState(0);
  const [imageUploadError, setImageUploadError] = useState("");

  const [isSaving, setIsSaving] = useState(false);

  // File Input Refs
  const videoInputRef = useRef<HTMLInputElement>(null);
  const homeworkInputRef = useRef<HTMLInputElement>(null);
  const imagesInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // 1. Handle Video Upload
  const handleVideoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate video types: MP4, WEBM, MOV, MKV
    const validVideoTypes = ["video/mp4", "video/webm", "video/quicktime", "video/x-matroska", "video/ogg"];
    const isExtensionValid = /\.(mp4|webm|mov|mkv)$/i.test(file.name);

    if (!validVideoTypes.includes(file.type) && !isExtensionValid) {
      setVideoUploadError(
        isAr
          ? "نوع الفيديو غير مدعوم. يرجى اختيار ملف بصيغة MP4 أو WEBM أو MOV."
          : "Invalid video format. Please upload MP4, WEBM, or MOV."
      );
      return;
    }

    // Validate size (max 50MB)
    if (file.size > 50 * 1024 * 1024) {
      setVideoUploadError(
        isAr
          ? "حجم ملف الفيديو كبير جداً. الحد الأقصى المسموح به هو 50 ميجابايت."
          : "Video file exceeds 50MB maximum limit."
      );
      return;
    }

    setVideoUploadError("");
    setIsVideoUploading(true);
    setVideoUploadProgress(10);
    setVideoFileInfo({ name: file.name, size: file.size });

    try {
      const result = await uploadFileToPlatform({
        file,
        category: "lesson-video",
        userEmail,
        userRole,
        onProgress: (p) => setVideoUploadProgress(p),
      });

      setFormData((prev) => ({ ...prev, videoUrl: result.url }));
    } catch (err: any) {
      console.error("Video upload error:", err);
      setVideoUploadError(err?.message || (isAr ? "فشل رفع الفيديو" : "Video upload failed"));
    } finally {
      setIsVideoUploading(false);
    }
  };

  // 2. Handle Homework File Upload
  const handleHomeworkSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Supported formats: PDF, DOC, DOCX, XLS, XLSX, ZIP
    const isDocExtension = /\.(pdf|doc|docx|xls|xlsx|zip|rar)$/i.test(file.name);
    if (!isDocExtension) {
      setHomeworkUploadError(
        isAr
          ? "نوع الملف غير مدعوم. الصيغ المقبولة: PDF, DOC, DOCX, XLS, XLSX, ZIP."
          : "Invalid file type. Supported: PDF, DOC, DOCX, XLS, XLSX, ZIP."
      );
      return;
    }

    // Max 35MB
    if (file.size > 35 * 1024 * 1024) {
      setHomeworkUploadError(
        isAr
          ? "حجم الملف كبير جداً. الحد الأقصى لملف الواجب 35 ميجابايت."
          : "File exceeds 35MB limit."
      );
      return;
    }

    setHomeworkUploadError("");
    setIsHomeworkUploading(true);
    setHomeworkUploadProgress(10);
    setHomeworkFileInfo({ name: file.name, size: file.size });

    try {
      const result = await uploadFileToPlatform({
        file,
        category: "homework-file",
        userEmail,
        userRole,
        onProgress: (p) => setHomeworkUploadProgress(p),
      });

      setFormData((prev) => ({
        ...prev,
        homeworkFileUrl: result.url,
        homeworkFileName: file.name,
      }));
    } catch (err: any) {
      console.error("Homework upload error:", err);
      setHomeworkUploadError(err?.message || (isAr ? "فشل رفع ملف الواجب" : "Upload failed"));
    } finally {
      setIsHomeworkUploading(false);
    }
  };

  const handleRemoveHomework = () => {
    setFormData((prev) => ({
      ...prev,
      homeworkFileUrl: "",
      homeworkFileName: "",
    }));
    setHomeworkFileInfo(null);
    setHomeworkUploadError("");
    if (homeworkInputRef.current) homeworkInputRef.current.value = "";
  };

  // 3. Handle Lesson Images Upload (Multi-Upload)
  const handleImagesSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setImageUploadError("");
    setIsImageUploading(true);
    setImageUploadProgress(15);

    try {
      const uploadedUrls: string[] = [];
      const total = files.length;

      for (let i = 0; i < total; i++) {
        const file = files[i];
        if (!file.type.startsWith("image/")) continue;
        if (file.size > 15 * 1024 * 1024) continue;

        const result = await uploadFileToPlatform({
          file,
          category: "lesson-image",
          userEmail,
          userRole,
          onProgress: (p) => {
            const overall = Math.round(((i + p / 100) / total) * 100);
            setImageUploadProgress(overall);
          },
        });

        uploadedUrls.push(result.url);
      }

      setFormData((prev) => ({
        ...prev,
        lessonImages: [...(prev.lessonImages || []), ...uploadedUrls],
      }));
    } catch (err: any) {
      console.error("Image upload error:", err);
      setImageUploadError(err?.message || (isAr ? "فشل رفع بعض الصور" : "Failed to upload some images"));
    } finally {
      setIsImageUploading(false);
      if (imagesInputRef.current) imagesInputRef.current.value = "";
    }
  };

  const handleRemoveImageAtIndex = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      lessonImages: (prev.lessonImages || []).filter((_, idx) => idx !== index),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title?.trim()) return;

    setIsSaving(true);
    try {
      await onSave({
        ...formData,
        courseId,
        order: Number(formData.order) || orderNumber,
      });
      onClose();
    } catch (err) {
      console.error("Failed to save lesson:", err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      id="lesson-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="lesson-modal-container"
        className="w-full max-w-2xl bg-[#151515] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-5 max-h-[90vh] overflow-y-auto shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center font-bold">
              <Video className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                {editingLesson
                  ? isAr
                    ? `تعديل الدرس: ${editingLesson.title}`
                    : `Edit Lesson: ${editingLesson.title}`
                  : isAr
                  ? "إضافة درس جديد للكورس"
                  : "Add New Lesson"}
              </h3>
              {courseTitle && (
                <p className="text-xs text-[#D4AF37] line-clamp-1">{courseTitle}</p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* Lesson Title */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1 text-xs">
              {isAr ? "عنوان الدرس" : "Lesson Title"} *
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder={isAr ? "مثال: الدرس 1 - المدخل الشامل للتقنية" : "Lesson title"}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
            />
          </div>

          {/* ============================================================ */}
          {/* VIDEO SOURCE SECTION (UPLOAD vs URL) */}
          {/* ============================================================ */}
          <div className="space-y-3 p-4 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-white text-xs flex items-center gap-2">
                <Video className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? "مصدر فيديو الدرس" : "Lesson Video Source"} *</span>
              </label>

              {/* Toggle Switcher */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-[#151515] border border-white/10">
                <button
                  type="button"
                  onClick={() => setVideoSourceMode("upload")}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    videoSourceMode === "upload"
                      ? "bg-[#D4AF37] text-black shadow"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isAr ? "رفع فيديو من الجهاز" : "Upload Video"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setVideoSourceMode("url")}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    videoSourceMode === "url"
                      ? "bg-[#D4AF37] text-black shadow"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isAr ? "رابط يوتيوب / مباشر" : "YouTube / URL"}</span>
                </button>
              </div>
            </div>

            {/* Error banner */}
            {videoUploadError && (
              <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{videoUploadError}</span>
              </div>
            )}

            {/* Option A: Upload Video File */}
            {videoSourceMode === "upload" && (
              <div className="p-3 rounded-xl bg-[#151515] border border-white/10 space-y-3">
                <input
                  ref={videoInputRef}
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,video/x-matroska,.mp4,.webm,.mov"
                  onChange={handleVideoSelect}
                  className="hidden"
                  id="lesson-video-file-input"
                />

                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-white">
                      {isAr ? "ملف الفيديو المرفوع للدرس" : "Uploaded Video File"}
                    </p>
                    <p className="text-[11px] text-gray-400">
                      {isAr
                        ? "صيغ مدعومة: MP4, WEBM, MOV (الحد الأقصى: 50 ميجابايت)"
                        : "Formats: MP4, WEBM, MOV (Max 50MB)"}
                    </p>
                    {videoFileInfo && (
                      <p className="text-xs text-[#D4AF37] font-mono">
                        {videoFileInfo.name} ({formatFileSize(videoFileInfo.size)})
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      disabled={isVideoUploading}
                      onClick={() => videoInputRef.current?.click()}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-[#D4AF37] hover:bg-[#c49f2e] text-black flex items-center justify-center gap-1.5 transition shadow cursor-pointer disabled:opacity-50 w-full sm:w-auto"
                    >
                      {isVideoUploading ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>{isAr ? "جاري الرفع..." : "Uploading..."}</span>
                        </>
                      ) : formData.videoUrl ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>{isAr ? "استبدال الفيديو" : "Replace Video"}</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>{isAr ? "اختيار ورفع فيديو" : "Upload Video"}</span>
                        </>
                      )}
                    </button>

                    {formData.videoUrl && (
                      <button
                        type="button"
                        disabled={isVideoUploading}
                        onClick={() => {
                          setFormData((prev) => ({ ...prev, videoUrl: "" }));
                          setVideoFileInfo(null);
                        }}
                        className="p-2 rounded-xl bg-red-950/70 text-red-300 border border-red-500/30 hover:bg-red-900 cursor-pointer"
                        title={isAr ? "حذف الفيديو" : "Remove"}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                {isVideoUploading && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] text-[#D4AF37]">
                      <span>{isAr ? "جاري معالجة وتخزين الفيديو..." : "Uploading..."}</span>
                      <span>{videoUploadProgress}%</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-[#D4AF37] h-full transition-all duration-300 rounded-full"
                        style={{ width: `${videoUploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Video Player Preview if uploaded */}
                {formData.videoUrl && !isVideoUploading && (
                  <div className="rounded-xl overflow-hidden bg-black border border-white/10 aspect-video max-h-48 mt-2 relative">
                    <video
                      src={formData.videoUrl}
                      controls
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Option B: Direct URL / YouTube */}
            {videoSourceMode === "url" && (
              <div className="space-y-2">
                <input
                  type="text"
                  required={videoSourceMode === "url"}
                  value={formData.videoUrl}
                  onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                  placeholder="https://www.youtube.com/watch?v=... أو https://.../video.mp4"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#151515] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono text-xs"
                />
                <p className="text-[11px] text-gray-400">
                  {isAr
                    ? "يدعم روابط YouTube العادية ومقاطع الـ Embed وروابط ملفات MP4 المباشرة."
                    : "Supports YouTube watch links, embed links, and direct MP4 URLs."}
                </p>
              </div>
            )}
          </div>

          {/* Duration & Order */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "مدة الدرس (مثال: 15:30)" : "Duration"}
              </label>
              <input
                type="text"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "ترتيب الدرس في الكورس" : "Lesson Order"}
              </label>
              <input
                type="number"
                min={1}
                value={formData.order}
                onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
              />
            </div>
          </div>

          {/* Free Preview Checkbox */}
          <div className="flex items-center gap-2 p-3 rounded-xl bg-[#0A0A0A] border border-white/10">
            <input
              type="checkbox"
              id="lesson-preview-checkbox"
              checked={formData.isFreePreview}
              onChange={(e) => setFormData({ ...formData, isFreePreview: e.target.checked })}
              className="w-4 h-4 rounded text-[#D4AF37] focus:ring-0 cursor-pointer"
            />
            <label htmlFor="lesson-preview-checkbox" className="text-xs text-gray-300 font-semibold cursor-pointer">
              {isAr ? "جعله درساً مجانياً للمعاينة (Free Preview)" : "Allow Free Preview for All Users"}
            </label>
          </div>

          {/* ============================================================ */}
          {/* HOMEWORK FILE UPLOAD SECTION (ملف الواجب) */}
          {/* ============================================================ */}
          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-white text-xs flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-400" />
                <span>{isAr ? "ملف الواجب والتطبيقات (اختياري)" : "Homework File (Optional)"}</span>
              </label>
              <span className="text-[11px] text-gray-400">PDF, DOC, DOCX, ZIP (Max 35MB)</span>
            </div>

            {homeworkUploadError && (
              <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{homeworkUploadError}</span>
              </div>
            )}

            <input
              ref={homeworkInputRef}
              type="file"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.zip,.rar"
              onChange={handleHomeworkSelect}
              className="hidden"
              id="lesson-homework-file-input"
            />

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl bg-[#151515] border border-white/10">
              <div className="space-y-0.5 min-w-0">
                {formData.homeworkFileUrl ? (
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span className="text-xs font-bold text-emerald-300 truncate">
                      {formData.homeworkFileName || (isAr ? "تم إرفاق ملف الواجب" : "Homework attached")}
                    </span>
                  </div>
                ) : (
                  <p className="text-xs text-gray-400">
                    {isAr ? "لم يتم رفع ملف واجب لهذا الدرس بعد." : "No homework file uploaded yet."}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  disabled={isHomeworkUploading}
                  onClick={() => homeworkInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#0A0A0A] hover:bg-white/10 text-gray-200 border border-white/10 flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50 w-full sm:w-auto"
                >
                  {isHomeworkUploading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />
                      <span>{isAr ? "جاري الرفع..." : "Uploading..."}</span>
                    </>
                  ) : formData.homeworkFileUrl ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>{isAr ? "استبدال الملف" : "Replace File"}</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-3.5 h-3.5" />
                      <span>{isAr ? "رفع ملف الواجب" : "Upload Homework File"}</span>
                    </>
                  )}
                </button>

                {formData.homeworkFileUrl && (
                  <button
                    type="button"
                    disabled={isHomeworkUploading}
                    onClick={handleRemoveHomework}
                    className="p-2 rounded-xl bg-red-950/70 text-red-300 border border-red-500/30 hover:bg-red-900 cursor-pointer"
                    title={isAr ? "إزالة ملف الواجب" : "Remove"}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {isHomeworkUploading && (
              <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-blue-500 h-full transition-all duration-300"
                  style={{ width: `${homeworkUploadProgress}%` }}
                />
              </div>
            )}
          </div>

          {/* ============================================================ */}
          {/* INTERACTIVE BOARD URL (رابط اللوحة التفاعلية) */}
          {/* ============================================================ */}
          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-white text-xs flex items-center gap-2">
                <Layout className="w-4 h-4 text-purple-400" />
                <span>{isAr ? "رابط اللوحة التفاعلية (Interactive Board)" : "Interactive Board URL"}</span>
              </label>
              <span className="text-[11px] text-gray-400">{isAr ? "اختياري" : "Optional"}</span>
            </div>
            <input
              type="url"
              value={formData.interactiveBoardUrl || ""}
              onChange={(e) => setFormData({ ...formData, interactiveBoardUrl: e.target.value })}
              placeholder="https://excalidraw.com/... أو https://miro.com/..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#151515] border border-white/10 text-white focus:outline-none focus:border-purple-500/50 font-mono text-xs"
            />
            <p className="text-[11px] text-gray-400">
              {isAr
                ? "يمكنك وضع رابط لوحة بيضاء تفاعلية (Miro, Excalidraw, Figma) ليتمكن الطالب من فتحها والتفاعل معها مباشرة."
                : "Add whiteboard/canvas links (Excalidraw, Miro) for interactive student engagement."}
            </p>
          </div>

          {/* ============================================================ */}
          {/* LESSON IMAGES GALLERY (صور الدرس) */}
          {/* ============================================================ */}
          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-white text-xs flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span>{isAr ? "صور ومخططات الدرس (Lesson Images)" : "Lesson Images & Diagrams"}</span>
              </label>
              <span className="text-[11px] text-gray-400">
                {(formData.lessonImages?.length || 0)} {isAr ? "صور مرفقة" : "images"}
              </span>
            </div>

            {imageUploadError && (
              <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{imageUploadError}</span>
              </div>
            )}

            <input
              ref={imagesInputRef}
              type="file"
              multiple
              accept="image/jpeg,image/png,image/webp,image/jpg"
              onChange={handleImagesSelect}
              className="hidden"
              id="lesson-images-file-input"
            />

            {/* Images Grid Preview */}
            {formData.lessonImages && formData.lessonImages.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 max-h-48 overflow-y-auto p-2 rounded-xl bg-[#151515] border border-white/10">
                {formData.lessonImages.map((imgUrl, idx) => (
                  <div
                    key={idx}
                    className="relative aspect-video rounded-lg overflow-hidden bg-black/60 border border-white/10 group"
                  >
                    <img src={imgUrl} alt={`Lesson asset ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleRemoveImageAtIndex(idx)}
                      className="absolute top-1 right-1 p-1 rounded bg-black/80 hover:bg-red-600 text-white opacity-0 group-hover:opacity-100 transition cursor-pointer"
                      title={isAr ? "حذف الصورة" : "Delete"}
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Upload Button */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isImageUploading}
                onClick={() => imagesInputRef.current?.click()}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#151515] hover:bg-white/10 text-[#D4AF37] border border-[#D4AF37]/30 flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
              >
                {isImageUploading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{isAr ? "جاري الرفع..." : "Uploading..."}</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAr ? "رفع صور إضافية للدرس" : "Add Lesson Images"}</span>
                  </>
                )}
              </button>
            </div>

            {isImageUploading && (
              <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-300"
                  style={{ width: `${imageUploadProgress}%` }}
                />
              </div>
            )}
          </div>

          {/* Lesson Description */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1 text-xs">
              {isAr ? "ملاحظات وشرح الدرس" : "Lesson Description & Notes"}
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder={isAr ? "اكتب ملخصاً أو نقاط الدرس الأساسية..." : "Notes..."}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
            />
          </div>

          {/* Submit & Cancel */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              disabled={isSaving || isVideoUploading || isHomeworkUploading}
              className="flex-1 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D4AF37]/20 disabled:opacity-50 transition"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isAr ? "جاري الحفظ..." : "Saving..."}</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingLesson ? (isAr ? "تحديث الدرس" : "Update Lesson") : (isAr ? "إضافة الدرس للكورس" : "Add Lesson")}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="py-3 px-5 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] hover:bg-white/5 border border-white/10 cursor-pointer"
            >
              {isAr ? "إلغاء" : "Cancel"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
