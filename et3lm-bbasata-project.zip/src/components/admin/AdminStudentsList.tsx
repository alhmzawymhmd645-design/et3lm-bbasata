import React, { useState, useMemo } from "react";
import { UserProfile } from "../../types";
import { SUPER_ADMIN_EMAIL } from "../../lib/firebase";
import {
  Users,
  Search,
  ShieldCheck,
  Crown,
  Calendar,
  Mail,
  UserCheck,
} from "lucide-react";

interface AdminStudentsListProps {
  allStudents: UserProfile[];
  isAr: boolean;
}

export const AdminStudentsList: React.FC<AdminStudentsListProps> = ({
  allStudents,
  isAr,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | "admin" | "student">("all");

  // Admin Pinning: Admin accounts (role === 'admin' or email === SUPER_ADMIN_EMAIL) are sorted FIRST
  const sortedAndFilteredUsers = useMemo(() => {
    const list = [...allStudents];

    // Primary sorting: Admins first, then by date joined desc
    list.sort((a, b) => {
      const aIsAdmin = a.role === "admin" || a.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
      const bIsAdmin = b.role === "admin" || b.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

      if (aIsAdmin && !bIsAdmin) return -1;
      if (!aIsAdmin && bIsAdmin) return 1;

      // Secondary: creation time newest first
      const timeA = new Date(a.createdAt || 0).getTime();
      const timeB = new Date(b.createdAt || 0).getTime();
      return timeB - timeA;
    });

    // Apply Filter
    return list.filter((user) => {
      const isAdmin = user.role === "admin" || user.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

      if (roleFilter === "admin" && !isAdmin) return false;
      if (roleFilter === "student" && isAdmin) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      const name = (user.displayName || "").toLowerCase();
      const email = (user.email || "").toLowerCase();
      const phone = (user.phone || "").toLowerCase();

      return name.includes(q) || email.includes(q) || phone.includes(q);
    });
  }, [allStudents, searchQuery, roleFilter]);

  const adminCount = allStudents.filter(
    (s) => s.role === "admin" || s.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
  ).length;

  return (
    <div className="space-y-4">
      {/* Top Header & Search Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#151515] border border-white/10 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>{isAr ? "سجل الطلاب والمشرفين" : "Users Directory"}</span>
              <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-white/10 text-gray-300">
                {allStudents.length}
              </span>
            </h3>
            <p className="text-xs text-gray-400">
              {isAr
                ? `يتضمن ${adminCount} حسابات إدارية مثبتة في الصدارة تلقائياً.`
                : `${adminCount} administrator account(s) pinned at top.`}
            </p>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? "بحث بالاسم أو البريد..." : "Search users..."}
              className="w-full pl-3 pr-9 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
            />
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs">
            <button
              onClick={() => setRoleFilter("all")}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                roleFilter === "all" ? "bg-[#D4AF37] text-black" : "text-gray-400 hover:text-white"
              }`}
            >
              {isAr ? "الكل" : "All"}
            </button>
            <button
              onClick={() => setRoleFilter("admin")}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                roleFilter === "admin" ? "bg-red-600 text-white" : "text-gray-400 hover:text-white"
              }`}
            >
              {isAr ? "الأدمن" : "Admins"}
            </button>
            <button
              onClick={() => setRoleFilter("student")}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                roleFilter === "student" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white"
              }`}
            >
              {isAr ? "الطلاب" : "Students"}
            </button>
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-2xl border border-white/10 overflow-hidden bg-[#151515] shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right">
            <thead className="bg-[#0A0A0A] text-gray-400 border-b border-white/10 uppercase tracking-wider">
              <tr>
                <th className="p-4">{isAr ? "المستخدم" : "User"}</th>
                <th className="p-4">{isAr ? "البريد الإلكتروني" : "Email"}</th>
                <th className="p-4">{isAr ? "الصلاحية / الدور" : "Role"}</th>
                <th className="p-4">{isAr ? "تاريخ الانضمام" : "Joined"}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-gray-300">
              {sortedAndFilteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-gray-500 text-xs">
                    {isAr ? "لا توجد نتائج مطابقة لبحثك." : "No users matched your query."}
                  </td>
                </tr>
              ) : (
                sortedAndFilteredUsers.map((s) => {
                  const isSuperAdmin = s.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
                  const isAdminUser = s.role === "admin" || isSuperAdmin;

                  return (
                    <tr
                      key={s.uid}
                      className={`hover:bg-white/5 transition ${
                        isAdminUser ? "bg-[#D4AF37]/5 border-l-2 border-[#D4AF37]" : ""
                      }`}
                    >
                      {/* Name & Avatar */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs border ${
                              isAdminUser
                                ? "bg-gradient-to-br from-[#D4AF37] to-[#8B6508] text-black border-[#D4AF37] shadow-sm shadow-[#D4AF37]/30"
                                : "bg-[#0A0A0A] text-gray-300 border-white/10"
                            }`}
                          >
                            {isAdminUser ? (
                              <Crown className="w-4 h-4 text-black" />
                            ) : (
                              (s.displayName || "U").charAt(0).toUpperCase()
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 font-bold text-white text-xs sm:text-sm">
                              <span>{s.displayName || (isAr ? "طالب منصة" : "Student")}</span>
                              {isAdminUser && (
                                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                                  <ShieldCheck className="w-3 h-3" />
                                  <span>{isSuperAdmin ? (isAr ? "الأدمن الرئيسي" : "SUPER ADMIN") : (isAr ? "أدمن" : "ADMIN")}</span>
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-gray-400 font-mono">{s.uid.slice(0, 10)}...</span>
                          </div>
                        </div>
                      </td>

                      {/* Email */}
                      <td className="p-4 font-mono text-xs text-gray-300">
                        <div className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-gray-500" />
                          <span>{s.email}</span>
                        </div>
                      </td>

                      {/* Role Badge */}
                      <td className="p-4">
                        {isAdminUser ? (
                          <span className="px-3 py-1 rounded-xl text-[11px] font-bold bg-gradient-to-r from-red-500/20 to-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 inline-flex items-center gap-1.5 shadow-sm">
                            <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
                            <span>{isAr ? "مدير المنصة (مثبت)" : "Administrator (Pinned)"}</span>
                          </span>
                        ) : (
                          <span className="px-3 py-1 rounded-xl text-[11px] font-bold bg-blue-500/10 text-blue-300 border border-blue-500/20 inline-flex items-center gap-1.5">
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{isAr ? "طالب مسجل" : "Student"}</span>
                          </span>
                        )}
                      </td>

                      {/* Joined Date */}
                      <td className="p-4 text-gray-400 font-mono text-[11px]">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-gray-500" />
                          <span>
                            {s.createdAt
                              ? new Date(s.createdAt).toLocaleDateString(isAr ? "ar-EG" : "en-US")
                              : isAr ? "غير محدد" : "N/A"}
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
