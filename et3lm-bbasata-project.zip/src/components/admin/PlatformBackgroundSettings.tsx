import React, { useState, useRef } from "react";
import { PlatformSettings } from "../../types";
import { uploadFileToPlatform, formatFileSize } from "../../lib/uploadHelper";
import {
  Upload,
  Image as ImageIcon,
  Loader2,
  Trash2,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Layers,
} from "lucide-react";
import siteBackground from "../../assets/images/site_background_1787091303127.jpg";

interface PlatformBackgroundSettingsProps {
  settingsForm: PlatformSettings;
  setSettingsForm: React.Dispatch<React.SetStateAction<PlatformSettings>>;
  userEmail?: string;
  userRole?: string;
  isAr: boolean;
}

export const PlatformBackgroundSettings: React.FC<PlatformBackgroundSettingsProps> = ({
  settingsForm,
  setSettingsForm,
  userEmail,
  userRole,
  isAr,
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState("");
  const [fileInfo, setFileInfo] = useState<{ name: string; size: number } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const presets = [
    {
      id: "default",
      name: isAr ? "الافتراضي (اتعلم ببساطة)" : "Default Modern",
      url: "",
      gradient: "from-amber-950/40 via-black to-black",
    },
    {
      id: "cyber_slate",
      name: isAr ? "سلايت تقني داكن" : "Cyber Slate",
      url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1920&auto=format&fit=crop&q=80",
      gradient: "from-slate-900 via-black to-black",
    },
    {
      id: "neural_grid",
      name: isAr ? "شبكة الذكاء الاصطناعي" : "Neural Network",
      url: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=1920&auto=format&fit=crop&q=80",
      gradient: "from-indigo-950/50 via-black to-black",
    },
    {
      id: "deep_space",
      name: isAr ? "الفضاء العميق" : "Deep Space",
      url: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1920&auto=format&fit=crop&q=80",
      gradient: "from-blue-950/40 via-black to-black",
    },
    {
      id: "warm_gold",
      name: isAr ? "الذهب الفاخر" : "Warm Luxury Gold",
      url: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=1920&auto=format&fit=crop&q=80",
      gradient: "from-yellow-950/40 via-black to-black",
    },
  ];

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
    if (!validTypes.includes(file.type)) {
      setUploadError(
        isAr
          ? "نوع الملف غير مدعوم. يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP."
          : "Invalid image format. Supported: JPG, PNG, WEBP."
      );
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setUploadError(
        isAr
          ? "حجم الصورة كبير جداً، الحد الأقصى 15 ميجابايت."
          : "Image size exceeds 15MB."
      );
      return;
    }

    setUploadError("");
    setIsUploading(true);
    setUploadProgress(10);
    setFileInfo({ name: file.name, size: file.size });

    try {
      const result = await uploadFileToPlatform({
        file,
        category: "platform-background",
        userEmail,
        userRole,
        onProgress: (p) => setUploadProgress(p),
      });

      setSettingsForm((prev) => ({
        ...prev,
        mainBackgroundUrl: result.url,
        platformBackground: result.url,
        mainBackgroundPreset: "default",
      }));
    } catch (err: any) {
      console.error("Platform background upload error:", err);
      setUploadError(err?.message || (isAr ? "فشل رفع خلفية المنصة" : "Upload failed"));
    } finally {
      setIsUploading(false);
    }
  };

  const handleSelectPreset = (preset: typeof presets[0]) => {
    setSettingsForm((prev) => ({
      ...prev,
      mainBackgroundUrl: preset.url || "",
      platformBackground: preset.url || "",
      mainBackgroundPreset: preset.id as any,
    }));
    setFileInfo(null);
    setUploadError("");
  };

  const handleResetToDefault = () => {
    setSettingsForm((prev) => ({
      ...prev,
      mainBackgroundUrl: "",
      platformBackground: "",
      mainBackgroundPreset: "default",
    }));
    setFileInfo(null);
    setUploadError("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const currentBg = settingsForm.platformBackground || settingsForm.mainBackgroundUrl || siteBackground;

  return (
    <div className="p-5 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div>
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#D4AF37]" />
            <span>{isAr ? "خلفية المنصة الرئيسية (Platform Background)" : "Main Platform Background"}</span>
          </h4>
          <p className="text-xs text-gray-400 mt-0.5">
            {isAr
              ? "تخصيص صورة أو مظهر الخلفية العامة للموقع بالكامل مع طبقة حماية التباين."
              : "Customize site-wide ambient background with automatic contrast protection."}
          </p>
        </div>

        <span className="text-[11px] font-mono text-[#D4AF37] bg-[#D4AF37]/10 px-2.5 py-1 rounded-lg border border-[#D4AF37]/30">
          {settingsForm.mainBackgroundPreset || (settingsForm.mainBackgroundUrl ? "Custom Image" : "Default HD")}
        </span>
      </div>

      {uploadError && (
        <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{uploadError}</span>
        </div>
      )}

      {/* Background Preview Card */}
      <div className="relative rounded-2xl overflow-hidden aspect-[21/9] sm:aspect-[24/7] bg-[#151515] border border-white/10 flex items-center justify-between p-6 shadow-inner">
        <img
          src={currentBg}
          alt="Site Background Preview"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-40 mix-blend-lighten scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/80" />

        <div className="relative z-10 space-y-1 max-w-sm">
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] text-[10px] font-bold">
            <Sparkles className="w-3 h-3" />
            <span>{isAr ? "معاينة حية للمظهر" : "Live Background Preview"}</span>
          </div>
          <p className="text-sm sm:text-base font-bold text-white">اتعلم ببساطة • منصة المستقبل</p>
          <p className="text-[11px] text-gray-300">
            {fileInfo ? `${fileInfo.name} (${formatFileSize(fileInfo.size)})` : isAr ? "خلفية نشطة ومحفوظة" : "Active background"}
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-2">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-black/70 hover:bg-black text-gray-300 hover:text-white border border-white/20 transition cursor-pointer"
          >
            {isAr ? "استعادة الافتراضي" : "Reset Default"}
          </button>
        </div>
      </div>

      {/* Preset Selector + Upload Actions */}
      <div className="space-y-2">
        <p className="text-xs font-semibold text-gray-300">
          {isAr ? "اختر من القوالب الجاهزة أو ارفع صورتك الخاصة:" : "Choose from Presets or Upload Image:"}
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {presets.map((preset) => {
            const isSelected =
              settingsForm.mainBackgroundPreset === preset.id ||
              (!settingsForm.mainBackgroundPreset && !settingsForm.mainBackgroundUrl && preset.id === "default");

            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleSelectPreset(preset)}
                className={`p-2.5 rounded-xl text-xs font-bold transition flex flex-col items-center gap-1.5 cursor-pointer border ${
                  isSelected
                    ? "bg-[#D4AF37]/20 border-[#D4AF37] text-[#D4AF37] shadow"
                    : "bg-[#151515] border-white/10 text-gray-400 hover:text-white hover:border-white/20"
                }`}
              >
                <div className={`w-full h-8 rounded-lg bg-gradient-to-br ${preset.gradient} border border-white/10`} />
                <span className="text-[11px] truncate w-full text-center">{preset.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Upload Custom Background */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2 border-t border-white/10">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/jpg"
          onChange={handleFileSelect}
          className="hidden"
          id="platform-bg-file-input"
        />

        <div className="text-xs text-gray-400">
          {isAr ? "صيغ مدعومة: JPG, PNG, WEBP (الحد الأقصى: 15 ميجابايت)" : "Max size 15MB (JPG, PNG, WEBP)"}
        </div>

        <button
          type="button"
          disabled={isUploading}
          onClick={() => fileInputRef.current?.click()}
          className="px-4 py-2 rounded-xl text-xs font-bold bg-[#D4AF37] hover:bg-[#c49f2e] text-black flex items-center gap-1.5 transition shadow cursor-pointer disabled:opacity-50"
        >
          {isUploading ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>{isAr ? `جاري الرفع ${uploadProgress}%...` : "Uploading..."}</span>
            </>
          ) : (
            <>
              <Upload className="w-3.5 h-3.5" />
              <span>{isAr ? "رفع صورة خلفية خاصة من الجهاز" : "Upload Custom Background"}</span>
            </>
          )}
        </button>
      </div>

      {isUploading && (
        <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-[#D4AF37] h-full transition-all duration-300"
            style={{ width: `${uploadProgress}%` }}
          />
        </div>
      )}
    </div>
  );
};
