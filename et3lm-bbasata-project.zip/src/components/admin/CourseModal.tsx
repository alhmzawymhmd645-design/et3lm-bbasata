import React, { useState, useRef } from "react";
import { Course, CourseCategory, CourseLevelItem } from "../../types";
import { getCategoryAncestry } from "../../lib/categoryUtils";
import { uploadFileToPlatform, formatFileSize } from "../../lib/uploadHelper";
import {
  X,
  Upload,
  Image as ImageIcon,
  Loader2,
  Trash2,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

interface CourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingCourse: Course | null;
  onSave: (formData: Partial<Course>) => Promise<void>;
  categories: CourseCategory[];
  levels: CourseLevelItem[];
  userEmail?: string;
  userRole?: string;
  isAr: boolean;
}

export const CourseModal: React.FC<CourseModalProps> = ({
  isOpen,
  onClose,
  editingCourse,
  onSave,
  categories,
  levels,
  userEmail,
  userRole,
  isAr,
}) => {
  const [formData, setFormData] = useState<Partial<Course>>({
    title: editingCourse?.title || "",
    description: editingCourse?.description || "",
    price: editingCourse?.price ?? 400,
    originalPrice: editingCourse?.originalPrice ?? 700,
    level: editingCourse?.level || levels[0]?.name || "مبتدئ",
    category: editingCourse?.category || categories[0]?.name || "برمجة الويب",
    duration: editingCourse?.duration || "10 ساعات",
    lessonCount: editingCourse?.lessonCount ?? 4,
    thumbnail:
      editingCourse?.thumbnail ||
      "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80",
    published: editingCourse?.published ?? true,
    featured: editingCourse?.featured ?? false,
  });

  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState("");
  const [fileInfo, setFileInfo] = useState<{ name: string; size: number } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate type: JPG, JPEG, PNG, WEBP
    const validTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
    if (!validTypes.includes(file.type)) {
      setUploadError(
        isAr
          ? "نوع الملف غير مدعوم. يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP."
          : "Invalid file type. Please select JPG, PNG, or WEBP."
      );
      return;
    }

    // Validate size (max 15MB)
    if (file.size > 15 * 1024 * 1024) {
      setUploadError(
        isAr
          ? "حجم الصورة كبير جداً، الحد الأقصى 15 ميجابايت."
          : "Image size exceeds 15MB limit."
      );
      return;
    }

    setUploadError("");
    setIsUploading(true);
    setUploadProgress(10);
    setFileInfo({ name: file.name, size: file.size });

    try {
      const result = await uploadFileToPlatform({
        file,
        category: "course-thumbnail",
        userEmail,
        userRole,
        onProgress: (p) => setUploadProgress(p),
      });

      setFormData((prev) => ({ ...prev, thumbnail: result.url }));
    } catch (err: any) {
      console.error("Failed to upload thumbnail:", err);
      setUploadError(err?.message || (isAr ? "فشل رفع الصورة" : "Failed to upload image"));
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveImage = () => {
    setFormData((prev) => ({
      ...prev,
      thumbnail:
        "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80",
    }));
    setFileInfo(null);
    setUploadError("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSave(formData);
      onClose();
    } catch (err) {
      console.error("Save error:", err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      id="course-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="course-modal-container"
        className="w-full max-w-2xl bg-[#151515] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-5 max-h-[90vh] overflow-y-auto shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center font-bold">
              <ImageIcon className="w-4 h-4" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white">
              {editingCourse
                ? isAr
                  ? `تعديل الكورس: ${editingCourse.title}`
                  : `Edit Course: ${editingCourse.title}`
                : isAr
                ? "إضافة كورس جديد"
                : "Add New Course"}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* Title */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1 text-xs">
              {isAr ? "عنوان الكورس" : "Course Title"} *
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder={isAr ? "مثال: المسار الشامل لتطوير تطبيقات الويب" : "Course Title"}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1 text-xs">
              {isAr ? "وصف الكورس" : "Description"} *
            </label>
            <textarea
              rows={3}
              required
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder={isAr ? "نبذة توضيحية عن محتوى الكورس والمهارات المكتسبة..." : "Description..."}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
            />
          </div>

          {/* Price & Original Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "السعر النهائي (ج.م)" : "Price (EGP)"} *
              </label>
              <input
                type="number"
                required
                min={0}
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "السعر قبل الخصم (ج.م)" : "Original Price"}
              </label>
              <input
                type="number"
                min={0}
                value={formData.originalPrice || ""}
                onChange={(e) => setFormData({ ...formData, originalPrice: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
              />
            </div>
          </div>

          {/* Level & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "المستوى" : "Level"} *
              </label>
              <select
                value={formData.level}
                onChange={(e) => setFormData({ ...formData, level: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              >
                {levels.map((lvl) => (
                  <option key={lvl.id} value={lvl.name}>
                    {lvl.name} {lvl.nameEn ? `(${lvl.nameEn})` : ""}
                  </option>
                ))}
                {formData.level && !levels.some((l) => l.name === formData.level) && (
                  <option value={formData.level}>{formData.level}</option>
                )}
              </select>
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "القسم / التصنيف الهرمي" : "Hierarchical Category"} *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              >
                {categories.map((cat) => {
                  const ancestry = getCategoryAncestry(cat.id, categories);
                  const indent = "— ".repeat(Math.max(0, ancestry.length - 1));
                  return (
                    <option key={cat.id} value={cat.name}>
                      {indent}
                      {cat.name} {cat.nameEn ? `(${cat.nameEn})` : ""}
                    </option>
                  );
                })}
                {formData.category && !categories.some((c) => c.name === formData.category) && (
                  <option value={formData.category}>{formData.category}</option>
                )}
              </select>
            </div>
          </div>

          {/* Duration & Lesson Count */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "المدة الإجمالية (مثال: 12 ساعة)" : "Total Duration"}
              </label>
              <input
                type="text"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "عدد الدروس التقديري" : "Estimated Lessons"}
              </label>
              <input
                type="number"
                min={1}
                value={formData.lessonCount}
                onChange={(e) => setFormData({ ...formData, lessonCount: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50 font-mono"
              />
            </div>
          </div>

          {/* ============================================================ */}
          {/* DEDICATED THUMBNAIL UPLOAD SECTION */}
          {/* ============================================================ */}
          <div className="space-y-2 p-4 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-white text-xs flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? "الصورة المصغرة للكورس (Thumbnail)" : "Course Thumbnail"}</span>
              </label>
              <span className="text-[11px] text-gray-400">JPG, PNG, WEBP (Max 15MB)</span>
            </div>

            {/* Error Message */}
            {uploadError && (
              <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            {/* Thumbnail Preview & Actions Box */}
            <div className="flex flex-col sm:flex-row items-center gap-4 p-3 rounded-xl bg-[#151515] border border-white/10">
              {/* Image Preview */}
              <div className="w-full sm:w-44 aspect-video rounded-xl overflow-hidden bg-black/60 border border-white/10 relative flex-shrink-0">
                {formData.thumbnail ? (
                  <img
                    src={formData.thumbnail}
                    alt="Thumbnail Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-500 text-xs">
                    {isAr ? "لا توجد صورة" : "No image"}
                  </div>
                )}
                {isUploading && (
                  <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center gap-1.5 text-[#D4AF37] text-xs">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>{uploadProgress}%</span>
                  </div>
                )}
              </div>

              {/* Upload Controls & Metadata */}
              <div className="flex-1 space-y-2 w-full">
                {fileInfo ? (
                  <div className="text-xs space-y-0.5">
                    <p className="font-bold text-white truncate max-w-xs">{fileInfo.name}</p>
                    <p className="text-[11px] text-gray-400 font-mono">
                      {formatFileSize(fileInfo.size)}
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {isAr
                      ? "اختر صورة عالية الجودة تعبر عن محتوى الكورس لجذب الطلاب."
                      : "Upload a high quality course banner image."}
                  </p>
                )}

                {/* Upload Button + Replace + Delete */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/jpg"
                    onChange={handleFileSelect}
                    className="hidden"
                    id="course-thumbnail-file-input"
                  />

                  <button
                    type="button"
                    disabled={isUploading}
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#D4AF37] hover:bg-[#c49f2e] text-black flex items-center gap-1.5 transition shadow cursor-pointer disabled:opacity-50"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>{isAr ? "جاري الرفع..." : "Uploading..."}</span>
                      </>
                    ) : formData.thumbnail ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>{isAr ? "استبدال الصورة" : "Replace Image"}</span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isAr ? "رفع الصورة المصغرة" : "Upload Thumbnail"}</span>
                      </>
                    )}
                  </button>

                  {formData.thumbnail && (
                    <button
                      type="button"
                      disabled={isUploading}
                      onClick={handleRemoveImage}
                      className="px-3 py-2 rounded-xl text-xs font-bold bg-red-950/70 hover:bg-red-900/80 text-red-300 border border-red-500/30 flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isAr ? "إزالة الصورة" : "Remove"}</span>
                    </button>
                  )}
                </div>

                {isUploading && (
                  <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden mt-2">
                    <div
                      className="bg-[#D4AF37] h-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              disabled={isSaving || isUploading}
              className="flex-1 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D4AF37]/20 disabled:opacity-50 transition"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isAr ? "جاري الحفظ..." : "Saving..."}</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingCourse ? (isAr ? "تحديث بيانات الكورس" : "Update Course") : (isAr ? "إضافة الكورس" : "Add Course")}</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-5 rounded-xl font-semibold text-gray-300 bg-[#0A0A0A] hover:bg-white/5 border border-white/10 cursor-pointer"
            >
              {isAr ? "إلغاء" : "Cancel"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
