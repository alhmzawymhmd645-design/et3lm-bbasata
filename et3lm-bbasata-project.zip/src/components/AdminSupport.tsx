import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import {
  LifeBuoy,
  Bot,
  User,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Send,
  Search,
  RefreshCw,
  ToggleLeft,
  ToggleRight,
  MessageSquare,
  Phone,
  Mail,
  Lock,
  Image as ImageIcon,
  X,
  FileText,
} from "lucide-react";
import { TicketCategory, TicketStatus, SupportTicket } from "../types";

const QUICK_RESPONSES = [
  "تمت مراجعة إيصال التحويل وتفعيل الكورس في حسابك بنجاح! نتمنى لك تجربة تعليمية ممتعة.",
  "يرجى تزويدنا برقم الهاتف المحول منه ولقطة شاشة واضحة لرسالة التحويل من اتصالات كاش.",
  "تم حل المشكلة التقنية، يرجى تحديث الصفحة وتجربة المشاهدة مجدداً.",
  "شهادة إتمام الكورس معتمدة وتصدر تلقائياً في صفحة حسابك عند إكمال 100% من الدروس.",
];

export const AdminSupport: React.FC = () => {
  const {
    allTickets,
    settings,
    updateSettings,
    adminReplyToTicket,
    updateTicketStatus,
  } = useApp();

  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [adminReplyText, setAdminReplyText] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [adminNotesText, setAdminNotesText] = useState("");
  const [isTogglingAi, setIsTogglingAi] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const selectedTicket = allTickets.find((t) => t.id === selectedTicketId) || allTickets[0] || null;

  // Filtered tickets
  const filteredTickets = allTickets.filter((ticket) => {
    const matchesSearch =
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.lastMessageText.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterStatus === "needs_admin") {
      return ticket.needsAdminAttention || ticket.status === "needs_admin";
    }
    if (filterStatus === "open") return ticket.status === "open";
    if (filterStatus === "in_progress") return ticket.status === "in_progress";
    if (filterStatus === "resolved") return ticket.status === "resolved";
    if (filterStatus === "closed") return ticket.status === "closed";

    return true;
  });

  const needsAdminCount = allTickets.filter(
    (t) => t.needsAdminAttention || t.status === "needs_admin"
  ).length;

  const handleSendAdminReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !adminReplyText.trim()) return;

    setIsSending(true);
    try {
      await adminReplyToTicket(selectedTicket.id, adminReplyText, "in_progress");
      setAdminReplyText("");
    } catch (err) {
      console.error("Failed to send admin reply:", err);
    } finally {
      setIsSending(false);
    }
  };

  const handleSaveNotes = async () => {
    if (!selectedTicket) return;
    try {
      await updateTicketStatus(selectedTicket.id, selectedTicket.status, adminNotesText);
    } catch (err) {
      console.error("Failed to save admin notes:", err);
    }
  };

  const handleToggleAiAutoReply = async () => {
    setIsTogglingAi(true);
    try {
      const current = settings.aiAutoReplyEnabled !== false;
      await updateSettings({ aiAutoReplyEnabled: !current });
    } catch (err) {
      console.error("Failed to toggle AI auto reply:", err);
    } finally {
      setIsTogglingAi(false);
    }
  };

  const isAiActive = settings.aiAutoReplyEnabled !== false;

  return (
    <div className="space-y-6">
      {/* Top Banner with AI Toggle & Stats */}
      <div
        id="admin-support-banner"
        className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6"
      >
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <LifeBuoy className="w-6 h-6 text-primary-400" />
            <h2 className="text-xl font-bold text-white">إدارة تذاكر الدعم الفني والمساعد الذكي</h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            متابعة استفسارات الطلاب، التذاكر المحولة، والتحكم في الردود التلقائية لـ Gemini AI.
          </p>
        </div>

        {/* AI Auto-Reply Switch */}
        <div
          id="ai-autoreply-toggle-box"
          className="flex items-center gap-4 bg-slate-800/80 border border-slate-700/60 p-4 rounded-xl shrink-0"
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isAiActive
                  ? "bg-primary-500/10 text-primary-400 border border-primary-500/30"
                  : "bg-slate-700/40 text-slate-500 border border-slate-700"
              }`}
            >
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                الرد الآلي بالذكاء الاصطناعي (Gemini)
                {isAiActive && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAiActive
                  ? "مفعل (يجيب فورياً على رسائل الطلاب ويصعد للضرورة)"
                  : "معطل (تحويل كل التذاكر للدعم البشري)"}
              </div>
            </div>
          </div>

          <button
            id="btn-toggle-ai-support"
            onClick={handleToggleAiAutoReply}
            disabled={isTogglingAi}
            className="p-1 rounded-lg hover:bg-slate-700/50 transition-colors disabled:opacity-50 cursor-pointer"
            title="تبديل تفعيل / تعطيل الرد الآلي"
          >
            {isAiActive ? (
              <ToggleRight className="w-9 h-9 text-primary-400 hover:text-primary-300" />
            ) : (
              <ToggleLeft className="w-9 h-9 text-slate-500 hover:text-slate-400" />
            )}
          </button>
        </div>
      </div>

      {/* Main Grid: Ticket List & Thread View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Tickets List Column */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
              <input
                id="input-admin-search-tickets"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث باسم الطالب، البريد، أو الموضوع..."
                className="w-full pl-3 pr-9 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-primary-500"
              />
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar text-xs">
              <button
                id="btn-filter-all"
                onClick={() => setFilterStatus("all")}
                className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  filterStatus === "all"
                    ? "bg-slate-700 text-white"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                الكل ({allTickets.length})
              </button>
              <button
                id="btn-filter-needs-admin"
                onClick={() => setFilterStatus("needs_admin")}
                className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors flex items-center gap-1 cursor-pointer ${
                  filterStatus === "needs_admin"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                <AlertCircle className="w-3 h-3 text-amber-400" />
                تحتاج تدخل ({needsAdminCount})
              </button>
              <button
                id="btn-filter-open"
                onClick={() => setFilterStatus("open")}
                className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  filterStatus === "open"
                    ? "bg-primary-500/20 text-primary-300 border border-primary-500/40"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                مفتوحة
              </button>
              <button
                id="btn-filter-inprogress"
                onClick={() => setFilterStatus("in_progress")}
                className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  filterStatus === "in_progress"
                    ? "bg-blue-500/20 text-blue-300 border border-blue-500/40"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                قيد المتابعة
              </button>
              <button
                id="btn-filter-resolved"
                onClick={() => setFilterStatus("resolved")}
                className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  filterStatus === "resolved"
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                تم الحل
              </button>
            </div>

            {/* Tickets Scroll List */}
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1 custom-scrollbar">
              {filteredTickets.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  لا توجد تذاكر تطابق معايير البحث.
                </div>
              ) : (
                filteredTickets.map((ticket) => {
                  const isSelected = selectedTicket?.id === ticket.id;
                  const needsAttn = ticket.needsAdminAttention || ticket.status === "needs_admin";

                  return (
                    <button
                      key={ticket.id}
                      id={`btn-admin-ticket-${ticket.id}`}
                      onClick={() => {
                        setSelectedTicketId(ticket.id);
                        setAdminNotesText(ticket.adminNotes || "");
                      }}
                      className={`w-full text-right p-3.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? "bg-primary-500/10 border-primary-500/50 shadow-lg ring-1 ring-primary-500/30"
                          : needsAttn
                          ? "bg-amber-500/5 border-amber-500/30 hover:bg-slate-800"
                          : "bg-slate-800/40 border-slate-800 hover:bg-slate-800"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <span className="font-bold text-xs text-white truncate flex-1">
                          {ticket.subject}
                        </span>
                        <span className="text-[10px] text-slate-400 whitespace-nowrap font-mono">
                          {new Date(ticket.updatedAt || ticket.createdAt).toLocaleDateString(
                            "ar-EG",
                            { month: "short", day: "numeric" }
                          )}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-400 line-clamp-1 mb-2">
                        {ticket.userName} • {ticket.lastMessageText || "لا توجد رسائل"}
                      </div>

                      <div className="flex items-center justify-between gap-1 flex-wrap">
                        <span className="text-[10px] text-slate-500">
                          {ticket.category === "payment"
                            ? "دفع واشتراكات"
                            : ticket.category === "courses"
                            ? "كورسات وشهادات"
                            : ticket.category === "account"
                            ? "حساب"
                            : "تقني/عام"}
                        </span>

                        {needsAttn ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30 animate-pulse">
                            <AlertCircle className="w-3 h-3" />
                            تدخل مطلوب
                          </span>
                        ) : ticket.status === "closed" ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
                            <Lock className="w-3 h-3" />
                            مغلقة
                          </span>
                        ) : ticket.status === "resolved" ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                            <CheckCircle2 className="w-3 h-3" />
                            تم الحل
                          </span>
                        ) : ticket.status === "in_progress" ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-full border border-blue-500/30">
                            <Clock className="w-3 h-3" />
                            قيد المتابعة
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-primary-400 bg-primary-500/10 px-2 py-0.5 rounded-full border border-primary-500/30">
                            <Bot className="w-3 h-3" />
                            مفتوحة
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Ticket Details & Conversation Column */}
        <div className="lg:col-span-7">
          {selectedTicket ? (
            <div
              id="admin-ticket-details-box"
              className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[700px] shadow-2xl overflow-hidden"
            >
              {/* Header Info */}
              <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900 space-y-3 shrink-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-base text-white">
                      {selectedTicket.subject}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 flex-wrap">
                      <span className="flex items-center gap-1 text-slate-300 font-semibold">
                        <User className="w-3.5 h-3.5 text-primary-400" />
                        {selectedTicket.userName}
                      </span>
                      <span className="flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5" />
                        {selectedTicket.userEmail}
                      </span>
                      {selectedTicket.userPhone && (
                        <span className="flex items-center gap-1 text-amber-400 font-mono">
                          <Phone className="w-3.5 h-3.5" />
                          {selectedTicket.userPhone}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Status Action Controls */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <select
                      id="select-ticket-status"
                      value={selectedTicket.status}
                      onChange={(e) =>
                        updateTicketStatus(
                          selectedTicket.id,
                          e.target.value as TicketStatus
                        )
                      }
                      className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-primary-500 font-semibold cursor-pointer"
                    >
                      <option value="open">مفتوحة (Open)</option>
                      <option value="needs_admin">تحتاج تدخل (Needs Admin)</option>
                      <option value="in_progress">قيد المراجعة (In Progress)</option>
                      <option value="resolved">تم الحل (Resolved)</option>
                      <option value="closed">مغلقة (Closed)</option>
                    </select>

                    <button
                      id="btn-mark-resolved"
                      onClick={() => updateTicketStatus(selectedTicket.id, "resolved")}
                      className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      تعليم كمحلول
                    </button>
                  </div>
                </div>
              </div>

              {/* Chat Thread */}
              <div
                id="admin-messages-thread"
                className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4 bg-[#080B11] custom-scrollbar"
              >
                {selectedTicket.messages?.map((msg) => {
                  const isStudent = msg.sender === "student";
                  const isAi = msg.sender === "ai";
                  const isAdmin = msg.sender === "admin";

                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-3 max-w-[90%] ${
                        isAdmin ? "mr-auto flex-row-reverse" : "ml-auto"
                      }`}
                    >
                      {/* Avatar */}
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                          isAdmin
                            ? "bg-amber-500 text-slate-950 shadow-md"
                            : isAi
                            ? "bg-primary-500 text-slate-950 shadow-md"
                            : "bg-slate-700 text-slate-200"
                        }`}
                      >
                        {isAdmin ? (
                          <ShieldCheck className="w-4 h-4" />
                        ) : isAi ? (
                          <Bot className="w-4 h-4" />
                        ) : (
                          <User className="w-4 h-4" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="space-y-1">
                        <div
                          className={`flex items-center gap-2 text-[11px] ${
                            isAdmin ? "justify-end text-slate-400" : "text-slate-400"
                          }`}
                        >
                          <span className="font-semibold text-slate-300">
                            {msg.senderName || (isStudent ? selectedTicket.userName : "المشرف")}
                          </span>
                          {isAi && (
                            <span className="text-[9px] bg-primary-500/20 text-primary-300 px-1.5 py-0.2 rounded border border-primary-500/30">
                              Gemini AI Auto-Reply
                            </span>
                          )}
                          {isAdmin && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30 font-bold">
                              مشرف الدعم
                            </span>
                          )}
                          <span className="text-[10px] text-slate-500 font-mono">
                            {new Date(msg.createdAt).toLocaleTimeString("ar-EG", {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </div>

                        <div
                          className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                            isAdmin
                              ? "bg-gradient-to-br from-amber-950/50 to-slate-900 text-amber-100 rounded-tr-none border border-amber-500/40"
                              : isAi
                              ? "bg-slate-900 text-slate-300 rounded-tl-none border border-primary-500/30"
                              : "bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700"
                          }`}
                        >
                          {msg.text && <p>{msg.text}</p>}

                          {/* Image Attachment */}
                          {msg.attachmentUrl && (
                            <div className="mt-2.5">
                              <img
                                src={msg.attachmentUrl}
                                alt="Attachment"
                                onClick={() => setPreviewImage(msg.attachmentUrl!)}
                                className="max-h-48 max-w-full rounded-xl border border-slate-700 object-cover cursor-pointer hover:opacity-90 transition"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Quick Admin Responses Snippets */}
              <div className="px-4 py-2 border-t border-slate-800 bg-slate-900/90 flex items-center gap-1.5 overflow-x-auto custom-scrollbar shrink-0 text-[11px]">
                <span className="text-slate-400 shrink-0 font-semibold">ردود نموذجية جاهزة:</span>
                {QUICK_RESPONSES.map((resp, i) => (
                  <button
                    key={i}
                    id={`btn-admin-quick-reply-${i}`}
                    type="button"
                    onClick={() => setAdminReplyText(resp)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:border-primary-500 whitespace-nowrap text-ellipsis max-w-[220px] overflow-hidden cursor-pointer"
                  >
                    {resp}
                  </button>
                ))}
              </div>

              {/* Admin Reply Composer */}
              <form
                onSubmit={handleSendAdminReply}
                id="form-admin-reply"
                className="p-3 sm:p-4 border-t border-slate-800 bg-slate-900 flex items-center gap-2 shrink-0"
              >
                <input
                  id="input-admin-reply"
                  type="text"
                  value={adminReplyText}
                  onChange={(e) => setAdminReplyText(e.target.value)}
                  placeholder="اكتب رد الدعم الفني الرسمي للطالب..."
                  className="flex-1 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-primary-500"
                  disabled={isSending}
                />
                <button
                  id="btn-admin-send-reply"
                  type="submit"
                  disabled={isSending || !adminReplyText.trim()}
                  className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-primary-500 hover:from-amber-600 hover:to-primary-600 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all disabled:opacity-40 cursor-pointer shadow-md"
                >
                  {isSending ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  <span>إرسال الرد</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-500 space-y-3">
              <LifeBuoy className="w-12 h-12 mx-auto text-slate-600" />
              <p>اختر تذكرة من القائمة لمراجعتها والرد عليها.</p>
            </div>
          )}
        </div>
      </div>

      {/* Image Preview Lightbox Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="max-w-3xl max-h-[85vh] bg-slate-900 border border-slate-700 rounded-2xl p-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-3 left-3 p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewImage}
              alt="Preview"
              className="max-h-[75vh] w-auto mx-auto object-contain rounded-xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
