import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import appLogo from "../assets/images/app_logo_1787091289735.jpg";
import { AdminSupport } from "./AdminSupport";
import { AdminMessengerBot } from "./AdminMessengerBot";
import { AdminCategoriesLevels } from "./AdminCategoriesLevels";
import { CourseModal } from "./admin/CourseModal";
import { LessonModal } from "./admin/LessonModal";
import { PlatformBackgroundSettings } from "./admin/PlatformBackgroundSettings";
import { WalletBackgroundSettings } from "./admin/WalletBackgroundSettings";
import { AdminStudentsList } from "./admin/AdminStudentsList";
import {
  ShieldCheck,
  CreditCard,
  BookOpen,
  Users,
  Settings as SettingsIcon,
  CheckCircle2,
  AlertCircle,
  Clock,
  Plus,
  Trash2,
  Edit,
  Eye,
  Video,
  Save,
  Check,
  DollarSign,
  TrendingUp,
  X,
  Search,
  Download,
  Image as ImageIcon,
  LifeBuoy,
  Bot,
  MessageSquare,
  AlertTriangle,
  Loader2,
  Layers,
  Tag,
} from "lucide-react";
import { Course, Lesson, PaymentRequest, PlatformSettings } from "../types";
import { getCategoryAncestry } from "../lib/categoryUtils";
import {
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";
import { db } from "../lib/firebase";

export const AdminDashboard: React.FC = () => {
  const {
    user,
    isAdmin,
    settings,
    updateSettings,
    allPayments,
    allStudents,
    allTickets,
    courses,
    categories,
    levels,
    deleteCourse,
    approvePayment,
    rejectPayment,
    language,
    setActiveView,
  } = useApp();

  const isAr = language === "ar";
  const [activeTab, setActiveTab] = useState<
    | "payments"
    | "courses"
    | "lessons"
    | "categories-levels"
    | "settings"
    | "students"
    | "support"
    | "messenger-bot"
  >("payments");

  const needsAdminSupportCount = allTickets?.filter(
    (t) => t.needsAdminAttention || t.status === "needs_admin"
  ).length || 0;

  // Feedback Notification Banner / Toast
  const [feedbackToast, setFeedbackToast] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);

  // Filter Payments
  const [paymentFilter, setPaymentFilter] = useState<"all" | "pending" | "approved" | "rejected">("all");
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Platform Settings Form State
  const [settingsForm, setSettingsForm] = useState<PlatformSettings>(settings);
  const [settingsSaved, setSettingsSaved] = useState(false);

  useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  // Course Management State
  const [isCourseModalOpen, setIsCourseModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [courseToDelete, setCourseToDelete] = useState<Course | null>(null);
  const [isDeletingCourse, setIsDeletingCourse] = useState(false);
  const [courseFormData, setCourseFormData] = useState<Partial<Course>>({
    title: "",
    description: "",
    price: 400,
    originalPrice: 700,
    level: "مبتدئ",
    category: "برمجة الويب",
    duration: "12 ساعة",
    lessonCount: 4,
    thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80",
    published: true,
    featured: false,
  });

  // Lesson Management State
  const [selectedCourseForLessons, setSelectedCourseForLessons] = useState<string>(
    courses[0]?.id || ""
  );
  const [courseLessons, setCourseLessons] = useState<Lesson[]>([]);
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [lessonToDelete, setLessonToDelete] = useState<Lesson | null>(null);
  const [isDeletingLesson, setIsDeletingLesson] = useState(false);
  const [lessonFormData, setLessonFormData] = useState<Partial<Lesson>>({
    title: "",
    description: "",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    duration: "15:00",
    order: 1,
    isFreePreview: false,
    published: true,
  });

  // Keep selectedCourseForLessons valid
  useEffect(() => {
    if (courses.length > 0 && (!selectedCourseForLessons || !courses.some((c) => c.id === selectedCourseForLessons))) {
      setSelectedCourseForLessons(courses[0].id);
    }
  }, [courses, selectedCourseForLessons]);

  // Load Lessons when selectedCourseForLessons changes
  useEffect(() => {
    if (!selectedCourseForLessons) {
      setCourseLessons([]);
      return;
    }
    async function loadLessons() {
      try {
        const q = query(
          collection(db, "lessons"),
          where("courseId", "==", selectedCourseForLessons)
        );
        const snap = await getDocs(q);
        const list: Lesson[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as Lesson);
        });
        list.sort((a, b) => (a.order || 0) - (b.order || 0));
        setCourseLessons(list);
      } catch (err) {
        console.error("Failed to load admin lessons:", err);
      }
    }
    loadLessons();
  }, [selectedCourseForLessons, courses]);

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 rounded-3xl dark-card border border-red-500/30 text-center space-y-4">
        <ShieldCheck className="w-12 h-12 text-red-500 mx-auto" />
        <h3 className="text-xl font-bold text-white">
          {isAr ? "غير مصرح لك بالدخول" : "Unauthorized Access"}
        </h3>
        <p className="text-xs text-slate-400">
          {isAr
            ? "هذه الصفحة مخصصة لمدير ومشرف المنصة فقط."
            : "This control panel is restricted to platform administrators."}
        </p>
        <button
          onClick={() => setActiveView("home")}
          className="px-5 py-2.5 rounded-xl font-bold bg-slate-800 text-white hover:bg-slate-700"
        >
          {isAr ? "العودة للرئيسية" : "Return Home"}
        </button>
      </div>
    );
  }

  // Calculate Metrics
  const pendingPayments = allPayments.filter((p) => p.status === "pending");
  const approvedPayments = allPayments.filter((p) => p.status === "approved");
  const totalRevenue = approvedPayments.reduce((acc, curr) => acc + (curr.amount || 0), 0);

  const filteredPayments = allPayments.filter((p) => {
    if (paymentFilter === "all") return true;
    return p.status === paymentFilter;
  });

  // Handle Payment Approval
  const handleApprove = async (pay: PaymentRequest) => {
    setActionLoading(pay.id);
    try {
      await approvePayment(pay);
      setFeedbackToast({
        type: "success",
        message: isAr ? `تمت الموافقة وتفعيل الكورس للطالب ${pay.userName} بنجاح.` : `Payment approved for ${pay.userName}.`,
      });
      setTimeout(() => setFeedbackToast(null), 4000);
    } catch (err) {
      console.error(err);
      setFeedbackToast({
        type: "error",
        message: isAr ? "حدث خطأ أثناء الموافقة على الدفع" : "Error approving payment",
      });
    } finally {
      setActionLoading(null);
    }
  };

  // Handle Payment Rejection
  const handleReject = async (pay: PaymentRequest) => {
    const reason = prompt(
      isAr ? "اكتب سبب الرفض للطالب:" : "Enter rejection reason for student:",
      "إيصال التحويل غير واضح أو الرقم المحول منه غير مطابق."
    );
    if (reason === null) return;
    setActionLoading(pay.id);
    try {
      await rejectPayment(pay.id, reason);
      setFeedbackToast({
        type: "success",
        message: isAr ? "تم رفض الطلب وإشعار الطالب." : "Payment rejected.",
      });
      setTimeout(() => setFeedbackToast(null), 4000);
    } catch (err) {
      console.error(err);
      setFeedbackToast({
        type: "error",
        message: isAr ? "حدث خطأ أثناء الرفض" : "Error rejecting payment",
      });
    } finally {
      setActionLoading(null);
    }
  };

  // Handle Settings Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateSettings(settingsForm);
      setSettingsSaved(true);
      setFeedbackToast({
        type: "success",
        message: isAr ? "تم حفظ إعدادات المنصة والخلفيات بنجاح." : "Platform & background settings updated successfully.",
      });
      setTimeout(() => {
        setSettingsSaved(false);
        setFeedbackToast(null);
      }, 4000);
    } catch (err: any) {
      console.error("Save settings error:", err);
      setFeedbackToast({
        type: "error",
        message: err?.message || (isAr ? "فشل حفظ الإعدادات" : "Failed to update settings"),
      });
      setTimeout(() => setFeedbackToast(null), 5000);
    }
  };

  // Handle Save Course (Create / Edit)
  const handleSaveCourse = async (data: Partial<Course>) => {
    try {
      // Find matching category to generate hierarchy paths & IDs
      const matchedCat = categories.find((c) => c.name === data.category);
      let catId = matchedCat?.id;
      let catIds: string[] | undefined = undefined;
      let catPath: string[] | undefined = undefined;

      if (matchedCat) {
        const ancestry = getCategoryAncestry(matchedCat.id, categories);
        catIds = ancestry.map((a) => a.id);
        catPath = ancestry.map((a) => a.name);
      }

      if (editingCourse) {
        // Update
        const ref = doc(db, "courses", editingCourse.id);
        await updateDoc(ref, {
          ...data,
          categoryId: catId || null,
          categoryIds: catIds || null,
          categoryPath: catPath || null,
          updatedAt: new Date().toISOString(),
        });
        setFeedbackToast({
          type: "success",
          message: isAr ? `تم تحديث بيانات كورس «${data.title}» بنجاح.` : `Course updated successfully.`,
        });
      } else {
        // Create new
        const newId = `course-${Date.now()}`;
        const newCourse: Course = {
          id: newId,
          title: data.title || "كورس جديد",
          description: data.description || "",
          thumbnail: data.thumbnail || "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80",
          price: Number(data.price) || 400,
          originalPrice: Number(data.originalPrice) || 700,
          level: data.level || "مبتدئ",
          category: data.category || "برمجة الويب",
          categoryId: catId,
          categoryIds: catIds,
          categoryPath: catPath,
          duration: data.duration || "10 ساعات",
          lessonCount: Number(data.lessonCount) || 1,
          published: data.published ?? true,
          featured: data.featured ?? false,
          createdAt: new Date().toISOString(),
        };
        await setDoc(doc(db, "courses", newId), newCourse);
        setFeedbackToast({
          type: "success",
          message: isAr ? `تمت إضافة كورس «${newCourse.title}» بنجاح.` : `Course created successfully.`,
        });
      }
      setIsCourseModalOpen(false);
      setEditingCourse(null);
      setTimeout(() => setFeedbackToast(null), 4000);
    } catch (err) {
      console.error("Course save error:", err);
      setFeedbackToast({
        type: "error",
        message: isAr ? "فشل حفظ بيانات الكورس، يرجى المحاولة مرة أخرى." : "Error saving course.",
      });
    }
  };

  // Handle Confirmed Course Deletion
  const handleConfirmDeleteCourse = async () => {
    if (!courseToDelete) return;
    const deletedTitle = courseToDelete.title;
    setIsDeletingCourse(true);
    try {
      await deleteCourse(courseToDelete.id);
      setCourseToDelete(null);
      setFeedbackToast({
        type: "success",
        message: isAr
          ? `تم حذف كورس «${deletedTitle}» بنجاح.`
          : `Course "${deletedTitle}" was deleted successfully.`,
      });
      setTimeout(() => setFeedbackToast(null), 5000);
    } catch (err: any) {
      console.error("Failed to delete course from Firestore:", err);
      setFeedbackToast({
        type: "error",
        message: isAr
          ? "تعذر حذف الكورس من قاعدة البيانات. يرجى التأكد من صلاحيات المشرف وإعادة المحاولة."
          : "Failed to delete course from database. Please check admin permissions.",
      });
    } finally {
      setIsDeletingCourse(false);
    }
  };

  // Handle Save Lesson (Create / Edit)
  const handleSaveLesson = async (data: Partial<Lesson>) => {
    if (!selectedCourseForLessons) return;
    try {
      if (editingLesson) {
        // Update Lesson
        const ref = doc(db, "lessons", editingLesson.id);
        await updateDoc(ref, {
          ...data,
          updatedAt: new Date().toISOString(),
        });
        setFeedbackToast({
          type: "success",
          message: isAr ? `تم تحديث الدرس «${data.title}» بنجاح.` : `Lesson updated successfully.`,
        });
      } else {
        // Create Lesson
        const newId = `lesson-${Date.now()}`;
        const newLesson: Lesson = {
          id: newId,
          courseId: selectedCourseForLessons,
          title: data.title || "درس جديد",
          description: data.description || "",
          videoUrl: data.videoUrl || "",
          duration: data.duration || "15:00",
          order: Number(data.order) || courseLessons.length + 1,
          isFreePreview: !!data.isFreePreview,
          homeworkFileUrl: data.homeworkFileUrl || undefined,
          homeworkFileName: data.homeworkFileName || undefined,
          interactiveBoardUrl: data.interactiveBoardUrl || undefined,
          lessonImages: data.lessonImages || undefined,
          published: true,
          createdAt: new Date().toISOString(),
        };
        await setDoc(doc(db, "lessons", newId), newLesson);
        setFeedbackToast({
          type: "success",
          message: isAr ? `تمت إضافة الدرس «${newLesson.title}» بنجاح.` : `Lesson added successfully.`,
        });
      }

      setIsLessonModalOpen(false);
      setEditingLesson(null);

      // Refresh list
      const q = query(
        collection(db, "lessons"),
        where("courseId", "==", selectedCourseForLessons)
      );
      const snap = await getDocs(q);
      const list: Lesson[] = [];
      snap.forEach((d) => list.push({ ...d.data(), id: d.id } as Lesson));
      list.sort((a, b) => (a.order || 0) - (b.order || 0));
      setCourseLessons(list);

      setTimeout(() => setFeedbackToast(null), 4000);
    } catch (err) {
      console.error(err);
      setFeedbackToast({
        type: "error",
        message: isAr ? "فشل حفظ الدرس" : "Failed to save lesson.",
      });
    }
  };

  // Handle Confirmed Lesson Deletion
  const handleConfirmDeleteLesson = async () => {
    if (!lessonToDelete) return;
    const deletedLessonTitle = lessonToDelete.title;
    setIsDeletingLesson(true);
    try {
      await deleteDoc(doc(db, "lessons", lessonToDelete.id));
      setCourseLessons((prev) => prev.filter((l) => l.id !== lessonToDelete.id));
      setLessonToDelete(null);
      setFeedbackToast({
        type: "success",
        message: isAr ? `تم حذف الدرس «${deletedLessonTitle}» بنجاح.` : `Lesson deleted successfully.`,
      });
      setTimeout(() => setFeedbackToast(null), 4000);
    } catch (err) {
      console.error("Failed to delete lesson:", err);
      setFeedbackToast({
        type: "error",
        message: isAr ? "فشل حذف الدرس، يرجى التأكد من الصلاحيات والمحاولة مجدداً." : "Failed to delete lesson.",
      });
    } finally {
      setIsDeletingLesson(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Toast Notification Banner */}
      {feedbackToast && (
        <div
          id="admin-feedback-toast"
          className={`p-4 rounded-2xl border flex items-center justify-between gap-4 transition-all duration-300 shadow-xl ${
            feedbackToast.type === "success"
              ? "bg-emerald-950/70 border-emerald-500/30 text-emerald-300"
              : "bg-red-950/70 border-red-500/30 text-red-300"
          }`}
        >
          <div className="flex items-center gap-3">
            {feedbackToast.type === "success" ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
            )}
            <p className="text-xs sm:text-sm font-semibold">{feedbackToast.message}</p>
          </div>
          <button
            onClick={() => setFeedbackToast(null)}
            className="p-1 rounded-lg hover:bg-white/10 text-white/70 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Admin Banner & Stats */}
      <div className="p-6 rounded-3xl bg-[#151515] border border-white/10 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">
                {isAr ? "لوحة إدارة منصة «اتعلم ببساطة»" : "Master Admin Control Panel"}
              </h1>
              <p className="text-xs text-gray-400">
                {isAr
                  ? "مراجعة إيصالات Etisalat Cash، إدارة الكورسات والدروس، وتحديث محفظة الدفع."
                  : "Verify payments, manage curriculum, and edit platform wallet."}
              </p>
            </div>
          </div>

          <div className="px-3.5 py-1.5 rounded-xl bg-[#0A0A0A] border border-[#D4AF37]/30 text-xs font-mono text-[#D4AF37] font-bold flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            <span>{isAr ? "المحفظة الحالية:" : "Active Wallet:"} {settings.etisalatCashNumber}</span>
          </div>
        </div>

        {/* Stat Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 space-y-1">
            <p className="text-xs text-gray-400">{isAr ? "طلبات قيد المراجعة" : "Pending Receipts"}</p>
            <p className="text-2xl font-bold text-[#D4AF37] font-mono">{pendingPayments.length}</p>
          </div>

          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-emerald-500/30 space-y-1">
            <p className="text-xs text-gray-400">{isAr ? "الاشتراكات المفعلة" : "Approved Enrollments"}</p>
            <p className="text-2xl font-bold text-emerald-400 font-mono">{approvedPayments.length}</p>
          </div>

          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-blue-500/30 space-y-1">
            <p className="text-xs text-gray-400">{isAr ? "إجمالي الإيرادات" : "Total Revenue"}</p>
            <p className="text-2xl font-bold text-blue-400 font-mono">
              {totalRevenue} <span className="text-xs">{isAr ? "ج.م" : "EGP"}</span>
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-purple-500/30 space-y-1">
            <p className="text-xs text-gray-400">{isAr ? "إجمالي الطلاب" : "Total Users"}</p>
            <p className="text-2xl font-bold text-purple-400 font-mono">{allStudents.length}</p>
          </div>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab("payments")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "payments"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>{isAr ? "طلبات تحويل Etisalat Cash" : "Payment Requests"}</span>
          {pendingPayments.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-red-600 text-white">
              {pendingPayments.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab("courses")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "courses"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>{isAr ? "إدارة الكورسات" : "Courses Manager"}</span>
        </button>

        <button
          onClick={() => setActiveTab("lessons")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "lessons"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <Video className="w-4 h-4" />
          <span>{isAr ? "إدارة الدروس والفيديوهات" : "Lessons Manager"}</span>
        </button>

        <button
          id="btn-admin-tab-categories-levels"
          onClick={() => setActiveTab("categories-levels")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "categories-levels"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>{isAr ? "إدارة التصنيفات والمستويات" : "Categories & Levels"}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-black/40 text-[#D4AF37] border border-[#D4AF37]/30">
            {categories.length + levels.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab("settings")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "settings"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <SettingsIcon className="w-4 h-4" />
          <span>{isAr ? "إعدادات المنصة والمحفظة" : "Settings & Wallet"}</span>
        </button>

        <button
          onClick={() => setActiveTab("students")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "students"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{isAr ? "الطلاب المسجلين" : "Students"}</span>
        </button>

        <button
          id="btn-admin-tab-support"
          onClick={() => setActiveTab("support")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "support"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <LifeBuoy className="w-4 h-4" />
          <span>{isAr ? "تذاكر الدعم الفني" : "Support Tickets"}</span>
          {needsAdminSupportCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-500 text-slate-950 animate-pulse">
              {needsAdminSupportCount}
            </span>
          )}
        </button>

        <button
          id="btn-admin-tab-messenger"
          onClick={() => setActiveTab("messenger-bot")}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-2 transition cursor-pointer ${
            activeTab === "messenger-bot"
              ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-black shadow-md shadow-[#D4AF37]/20 font-black"
              : "bg-[#151515] text-gray-300 hover:text-white border border-white/10"
          }`}
        >
          <Bot className="w-4 h-4 text-[#D4AF37]" />
          <span>{isAr ? "نظام المراسلة والمساعد الذكي" : "Internal Messenger Hub"}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
            Gemini AI
          </span>
        </button>
      </div>

      {/* TAB 1: PAYMENTS & RECEIPT APPROVAL */}
      {activeTab === "payments" && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {(["all", "pending", "approved", "rejected"] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setPaymentFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    paymentFilter === filter
                      ? "bg-[#151515] text-[#D4AF37] border border-[#D4AF37]/40"
                      : "bg-[#0A0A0A] text-gray-400 hover:text-gray-200 border border-white/5"
                  }`}
                >
                  {filter === "all" && (isAr ? "الكل" : "All")}
                  {filter === "pending" && (isAr ? "قيد المراجعة" : "Pending")}
                  {filter === "approved" && (isAr ? "المقبولة" : "Approved")}
                  {filter === "rejected" && (isAr ? "المرفوضة" : "Rejected")}
                </button>
              ))}
            </div>

            <span className="text-xs text-gray-400">
              {filteredPayments.length} {isAr ? "طلب معروض" : "items"}
            </span>
          </div>

          {filteredPayments.length > 0 ? (
            <div className="rounded-2xl border border-white/10 overflow-hidden bg-[#151515] shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#0A0A0A] text-gray-400 border-b border-white/10 uppercase tracking-wider">
                    <tr>
                      <th className="p-3.5">{isAr ? "الطالب" : "Student"}</th>
                      <th className="p-3.5">{isAr ? "الكورس" : "Course"}</th>
                      <th className="p-3.5">{isAr ? "المبلغ" : "Amount"}</th>
                      <th className="p-3.5">{isAr ? "رقم التحويل" : "Sender Phone"}</th>
                      <th className="p-3.5">{isAr ? "الإيصال" : "Receipt"}</th>
                      <th className="p-3.5">{isAr ? "الحالة" : "Status"}</th>
                      <th className="p-3.5">{isAr ? "الإجراءات" : "Actions"}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-gray-300">
                    {filteredPayments.map((pay) => (
                      <tr key={pay.id} className="hover:bg-white/5 transition">
                        <td className="p-3.5">
                          <p className="font-bold text-white">{pay.userName}</p>
                          <p className="text-[11px] text-gray-400">{pay.userEmail}</p>
                        </td>
                        <td className="p-3.5 font-semibold text-gray-200">{pay.courseTitle}</td>
                        <td className="p-3.5 font-mono font-bold text-[#D4AF37]">
                          {pay.amount} {isAr ? "ج.م" : "EGP"}
                        </td>
                        <td className="p-3.5 font-mono font-bold text-blue-400">{pay.senderPhone}</td>
                        <td className="p-3.5">
                          {pay.receiptUrl ? (
                            <button
                              onClick={() => setSelectedReceipt(pay.receiptUrl)}
                              className="px-2.5 py-1 rounded-lg bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 text-gray-200 flex items-center gap-1.5 transition cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5 text-[#D4AF37]" />
                              <span>{isAr ? "فحص الإيصال" : "Inspect"}</span>
                            </button>
                          ) : (
                            <span className="text-gray-500">{isAr ? "لا يوجد صورة" : "No image"}</span>
                          )}
                        </td>
                        <td className="p-3.5">
                          {pay.status === "approved" && (
                            <span className="px-2 py-0.5 rounded-full font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px]">
                              {isAr ? "مقبول ومفعل" : "Approved"}
                            </span>
                          )}
                          {pay.status === "pending" && (
                            <span className="px-2 py-0.5 rounded-full font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30 text-[11px] animate-pulse">
                              {isAr ? "قيد المراجعة" : "Pending"}
                            </span>
                          )}
                          {pay.status === "rejected" && (
                            <span className="px-2 py-0.5 rounded-full font-bold bg-red-500/20 text-red-400 border border-red-500/30 text-[11px]">
                              {isAr ? "مرفوض" : "Rejected"}
                            </span>
                          )}
                        </td>
                        <td className="p-3.5">
                          {pay.status === "pending" ? (
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => handleApprove(pay)}
                                disabled={actionLoading === pay.id}
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 transition shadow cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>{isAr ? "تفعيل الكورس" : "Approve"}</span>
                              </button>
                              <button
                                onClick={() => handleReject(pay)}
                                disabled={actionLoading === pay.id}
                                className="px-2.5 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 text-red-300 font-bold text-xs border border-red-500/30 transition cursor-pointer"
                              >
                                ✕ {isAr ? "رفض" : "Reject"}
                              </button>
                            </div>
                          ) : (
                            <span className="text-[11px] text-gray-500">
                              {isAr ? "تم اتخاذ الإجراء" : "Processed"}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-[#151515] border border-white/10 text-center text-xs text-gray-400 shadow-lg">
              {isAr ? "لا توجد طلبات في هذا القسم." : "No requests found for this filter."}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: COURSES MANAGEMENT */}
      {activeTab === "courses" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">
              {isAr ? "قائمة الكورسات المتاحة في المنصة" : "Platform Courses"} ({courses.length})
            </h3>
            <button
              onClick={() => {
                setEditingCourse(null);
                setCourseFormData({
                  title: "",
                  description: "",
                  price: 400,
                  originalPrice: 700,
                  level: levels[0]?.name || "مبتدئ",
                  category: categories[0]?.name || "برمجة الويب",
                  duration: "10 ساعات",
                  lessonCount: 4,
                  thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80",
                  published: true,
                });
                setIsCourseModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white flex items-center gap-1.5 transition cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? "إضافة كورس جديد" : "Add Course"}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {courses.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-[#151515] border border-white/10 flex flex-col justify-between space-y-3 shadow-lg"
              >
                <div className="space-y-2">
                  <div className="aspect-video rounded-xl overflow-hidden bg-[#0A0A0A] relative">
                    <img src={c.thumbnail} alt={c.title} className="w-full h-full object-cover" />
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-bold bg-[#0A0A0A]/90 text-[#D4AF37] border border-[#D4AF37]/30">
                      {c.price} ج.م
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white line-clamp-1">{c.title}</h4>
                  <p className="text-[11px] text-gray-400 line-clamp-2">{c.description}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
                  <span className="text-gray-400">{c.level}</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setEditingCourse(c);
                        setCourseFormData(c);
                        setIsCourseModalOpen(true);
                      }}
                      className="p-1.5 rounded-lg bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 text-[#D4AF37] cursor-pointer"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      id={`delete-course-${c.id}`}
                      onClick={() => setCourseToDelete(c)}
                      className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/80 text-red-400 border border-red-500/20 hover:border-red-500/40 transition cursor-pointer"
                      title={isAr ? "حذف الكورس" : "Delete Course"}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: LESSONS & VIDEO MANAGEMENT */}
      {activeTab === "lessons" && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#151515] border border-white/10 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-300 font-bold">
                {isAr ? "اختر الكورس لإدارة دروسه:" : "Select Course:"}
              </span>
              <select
                value={selectedCourseForLessons}
                onChange={(e) => setSelectedCourseForLessons(e.target.value)}
                className="px-3 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-white focus:outline-none focus:border-[#D4AF37]/50"
              >
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => {
                setEditingLesson(null);
                setIsLessonModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 text-white flex items-center gap-1.5 transition cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? "إضافة درس جديد لهذا الكورس" : "Add Lesson"}</span>
            </button>
          </div>

          <div className="space-y-2">
            {courseLessons.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-[#151515] border border-white/10 text-gray-400 text-xs">
                {isAr ? "لا توجد دروس مضافة لهذا الكورس حتى الآن. اضغط «إضافة درس جديد» بالأعلى." : "No lessons found for this course yet."}
              </div>
            ) : (
              courseLessons.map((l, idx) => (
                <div
                  key={l.id}
                  className="p-4 rounded-2xl bg-[#151515] border border-white/10 flex items-center justify-between gap-4 shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#0A0A0A] border border-white/10 flex items-center justify-center text-xs font-bold text-[#D4AF37] flex-shrink-0">
                      {idx + 1}
                    </div>
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-xs sm:text-sm font-bold text-white">{l.title}</p>
                        {l.isFreePreview && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                            {isAr ? "معاينة مجانية" : "Free Preview"}
                          </span>
                        )}
                        {l.homeworkFileUrl && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            {isAr ? "ملف واجب" : "Homework"}
                          </span>
                        )}
                        {l.interactiveBoardUrl && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                            {isAr ? "لوحة تفاعلية" : "Board"}
                          </span>
                        )}
                        {l.lessonImages && l.lessonImages.length > 0 && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            {l.lessonImages.length} {isAr ? "صور ومخططات" : "images"}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-gray-400 line-clamp-1">{l.videoUrl || (isAr ? "بدون فيديو" : "No video")}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                    <span className="text-xs font-mono text-gray-400">{l.duration}</span>
                    <button
                      onClick={() => {
                        setEditingLesson(l);
                        setIsLessonModalOpen(true);
                      }}
                      className="p-1.5 rounded-lg bg-[#0A0A0A] hover:bg-[#1A1A1A] border border-white/10 text-[#D4AF37] cursor-pointer transition"
                      title={isAr ? "تعديل الدرس" : "Edit Lesson"}
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      id={`delete-lesson-${l.id}`}
                      onClick={() => setLessonToDelete(l)}
                      className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-400 border border-red-500/20 hover:border-red-500/40 transition cursor-pointer"
                      title={isAr ? "حذف الدرس" : "Delete Lesson"}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 4: CATEGORIES & LEVELS MANAGEMENT */}
      {activeTab === "categories-levels" && <AdminCategoriesLevels />}

      {/* TAB 5: PLATFORM SETTINGS & WALLET */}
      {activeTab === "settings" && (
        <form onSubmit={handleSaveSettings} className="p-6 rounded-3xl bg-[#151515] border border-white/10 space-y-6 max-w-3xl shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-base font-bold text-white">
                {isAr ? "إعدادات منصة اتعلم ببساطة ورقم المحفظة" : "Platform Settings"}
              </h3>
              <p className="text-xs text-gray-400">
                {isAr ? "تعديل رقم محفظة Etisalat Cash والمعلومات العامة" : "Edit official wallet and brand details"}
              </p>
            </div>
            {settingsSaved && (
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>{isAr ? "تم الحفظ بنجاح!" : "Saved!"}</span>
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
            {/* Logo HD Preview & Download Card */}
            <div className="sm:col-span-2 p-5 rounded-2xl bg-[#181818] border border-[#D4AF37]/30 flex flex-col sm:flex-row items-center justify-between gap-5">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-[#D4AF37] shadow-lg shadow-[#D4AF37]/20 bg-black flex-shrink-0">
                  <img
                    src={settings.logoUrl || appLogo}
                    alt="Official Logo"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
                    <span>{isAr ? "الشعار الرسمي لمنصة اتعلم ببساطة (HD)" : "Official Platform Logo (HD)"}</span>
                  </h4>
                  <p className="text-xs text-gray-400 mt-1">
                    {isAr
                      ? "شعار عالي الدقة بقبعة التخرج الذهبية والمسارات الذكية."
                      : "High resolution emblem with golden graduation cap and neural nodes."}
                  </p>
                </div>
              </div>

              <a
                href={settings.logoUrl || appLogo}
                download="et3lem-bebasata-logo.jpg"
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-black bg-[#D4AF37] hover:bg-[#c49f2e] transition flex items-center justify-center gap-2 shadow-md shadow-[#D4AF37]/30 text-xs flex-shrink-0 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{isAr ? "تحميل الشعار كصورة (Download)" : "Download Logo Image"}</span>
              </a>
            </div>

            {/* Etisalat Cash Wallet (High Priority) */}
            <div className="sm:col-span-2 p-4 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 space-y-2">
              <label className="block font-bold text-[#D4AF37] text-xs">
                {isAr ? "رقم محفظة Etisalat Cash الرسمي لتحويلات الطلاب:" : "Official Etisalat Cash Wallet Number:"}
              </label>
              <input
                type="text"
                required
                value={settingsForm.etisalatCashNumber}
                onChange={(e) => setSettingsForm({ ...settingsForm, etisalatCashNumber: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-[#D4AF37]/40 font-mono text-base font-bold text-[#D4AF37] focus:outline-none focus:border-[#D4AF37]"
              />
              <p className="text-[11px] text-gray-400">
                {isAr
                  ? "تغيير هذا الرقم هنا سيحدثه فوراً في جميع صفحات المنصة ومودال الدفع."
                  : "Updating this wallet number applies immediately to all checkout modals."}
              </p>
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "اسم المنصة (بالعربية)" : "Platform Name (Arabic)"}
              </label>
              <input
                type="text"
                value={settingsForm.platformName}
                onChange={(e) => setSettingsForm({ ...settingsForm, platformName: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "اسم المنصة (بالإنجليزية)" : "Platform Name (English)"}
              </label>
              <input
                type="text"
                value={settingsForm.platformNameEn}
                onChange={(e) => setSettingsForm({ ...settingsForm, platformNameEn: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "بريد التواصل والدعم" : "Support Email"}
              </label>
              <input
                type="email"
                value={settingsForm.contactEmail}
                onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "هاتف التواصل / الواتساب" : "Support Phone / WhatsApp"}
              </label>
              <input
                type="text"
                value={settingsForm.contactPhone || ""}
                onChange={(e) => setSettingsForm({ ...settingsForm, contactPhone: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "شريط الإعلانات أعلى الصفحة (Announcement Bar)" : "Top Announcement Bar"}
              </label>
              <input
                type="text"
                value={settingsForm.announcement || ""}
                onChange={(e) => setSettingsForm({ ...settingsForm, announcement: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                {isAr ? "وصف المنصة" : "Platform Description"}
              </label>
              <textarea
                rows={3}
                value={settingsForm.description}
                onChange={(e) => setSettingsForm({ ...settingsForm, description: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]/50"
              />
            </div>

            {/* Background & Platform Customization Settings */}
            <div className="sm:col-span-2">
              <PlatformBackgroundSettings
                settingsForm={settingsForm}
                setSettingsForm={setSettingsForm}
                userEmail={user?.email}
                userRole={user?.role}
                isAr={isAr}
              />
            </div>

            <div className="sm:col-span-2">
              <WalletBackgroundSettings
                settingsForm={settingsForm}
                setSettingsForm={setSettingsForm}
                userEmail={user?.email}
                userRole={user?.role}
                isAr={isAr}
              />
            </div>

            {/* AI Support Auto-Reply Toggle in Settings */}
            <div className="sm:col-span-2 p-4 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">
                    {isAr ? "تفعيل الرد الآلي بالذكاء الاصطناعي (Gemini AI Support)" : "AI Support Auto-Reply"}
                  </h4>
                  <p className="text-[11px] text-gray-400">
                    {isAr
                      ? "يقوم بالرد الفوري على رسائل وتذاكر الطلاب وتصعيد المشاكل التي تتطلب تدخلاً بشرياً."
                      : "Automatically replies to student queries and escalates critical issues to admin."}
                  </p>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.aiAutoReplyEnabled !== false}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      aiAutoReplyEnabled: e.target.checked,
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D4AF37]"></div>
              </label>
            </div>
          </div>

          <button
            type="submit"
            className="py-3 px-6 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 flex items-center gap-2 shadow-lg shadow-[#D4AF37]/20 transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isAr ? "حفظ التغييرات في المنصة" : "Save Settings"}</span>
          </button>
        </form>
      )}

      {/* TAB 5: REGISTERED STUDENTS WITH ADMIN PINNING */}
      {activeTab === "students" && (
        <AdminStudentsList allStudents={allStudents} isAr={isAr} />
      )}

      {/* TAB 6: TECHNICAL SUPPORT & AI CHATS */}
      {activeTab === "support" && <AdminSupport />}

      {/* TAB 7: FACEBOOK MESSENGER BOT */}
      {activeTab === "messenger-bot" && <AdminMessengerBot />}

      {/* RECEIPT INSPECT MODAL */}
      {selectedReceipt && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedReceipt(null)}
        >
          <div
            className="max-w-2xl max-h-[85vh] bg-[#151515] border border-white/10 rounded-3xl p-6 relative space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? "معاينة إيصال تحويل Etisalat Cash" : "Receipt Image Preview"}</span>
              </h4>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="p-1.5 rounded-lg bg-[#0A0A0A] text-gray-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <img
              src={selectedReceipt}
              alt="Receipt Inspection"
              className="max-h-[65vh] w-auto mx-auto object-contain rounded-xl bg-[#0A0A0A] border border-white/10"
            />
          </div>
        </div>
      )}

      {/* MODULAR COURSE CREATE/EDIT MODAL WITH THUMBNAIL UPLOAD */}
      <CourseModal
        isOpen={isCourseModalOpen}
        onClose={() => {
          setIsCourseModalOpen(false);
          setEditingCourse(null);
        }}
        onSave={handleSaveCourse}
        editingCourse={editingCourse}
        categories={categories}
        levels={levels}
        isAr={isAr}
      />

      {/* MODULAR LESSON CREATE/EDIT MODAL WITH VIDEO, HOMEWORK, BOARD & IMAGE UPLOADS */}
      <LessonModal
        isOpen={isLessonModalOpen}
        onClose={() => {
          setIsLessonModalOpen(false);
          setEditingLesson(null);
        }}
        onSave={handleSaveLesson}
        editingLesson={editingLesson}
        courseLessonsCount={courseLessons.length}
        isAr={isAr}
      />

      {/* CONFIRM DELETE COURSE MODAL */}
      {courseToDelete && (
        <div
          id="delete-course-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => !isDeletingCourse && setCourseToDelete(null)}
        >
          <div
            id="delete-course-modal-container"
            className="w-full max-w-md bg-[#151515] border border-red-500/30 rounded-3xl p-6 sm:p-7 space-y-5 shadow-2xl relative animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Close Button */}
            <button
              id="cancel-delete-course-x-btn"
              disabled={isDeletingCourse}
              onClick={() => setCourseToDelete(null)}
              className="absolute top-4 left-4 p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer disabled:opacity-50"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header with Danger Icon */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400 flex-shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">
                  {isAr ? "تأكيد حذف الكورس" : "Confirm Course Deletion"}
                </h3>
                <p className="text-xs text-red-400/90 font-medium">
                  {isAr ? "إجراء إداري دائم لا رجعة فيه" : "Irreversible action"}
                </p>
              </div>
            </div>

            {/* Course Preview Box */}
            <div className="p-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 flex items-center gap-3">
              <div className="w-16 h-12 rounded-xl overflow-hidden bg-black/40 flex-shrink-0 border border-white/10">
                <img
                  src={courseToDelete.thumbnail}
                  alt={courseToDelete.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-white truncate">{courseToDelete.title}</p>
                <div className="flex items-center gap-2 mt-1 text-[11px] text-gray-400">
                  <span className="font-mono text-[#D4AF37] font-bold">{courseToDelete.price} ج.م</span>
                  <span>•</span>
                  <span>{courseToDelete.category || (isAr ? "كورس تعليمي" : "Course")}</span>
                </div>
              </div>
            </div>

            {/* Warning Body */}
            <div className="text-xs text-gray-300 space-y-2 bg-red-950/30 border border-red-500/20 p-3.5 rounded-2xl">
              <p className="leading-relaxed">
                {isAr
                  ? `هل أنت متأكد من رغبتك في حذف كورس «${courseToDelete.title}»؟`
                  : `Are you sure you want to permanently delete "${courseToDelete.title}"?`}
              </p>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                {isAr
                  ? "سيتم حذف بيانات الكورس وجميع الدروس والفيديوهات التابعة له من قاعدة البيانات فوراً ولن يتمكن الطلاب من الوصول إليه."
                  : "The course and all associated lessons and videos will be completely removed from the database."}
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center gap-3 pt-2">
              <button
                id="confirm-delete-course-btn"
                disabled={isDeletingCourse}
                onClick={handleConfirmDeleteCourse}
                className="flex-1 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm bg-red-600 hover:bg-red-500 text-white flex items-center justify-center gap-2 transition shadow-lg shadow-red-600/30 cursor-pointer disabled:opacity-50"
              >
                {isDeletingCourse ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{isAr ? "جاري الحذف..." : "Deleting..."}</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>{isAr ? "نعم، احذف الكورس" : "Yes, Delete Course"}</span>
                  </>
                )}
              </button>
              <button
                id="cancel-delete-course-btn"
                disabled={isDeletingCourse}
                onClick={() => setCourseToDelete(null)}
                className="py-2.5 px-4 rounded-xl font-semibold text-xs sm:text-sm bg-[#1A1A1A] hover:bg-[#252525] text-gray-300 hover:text-white border border-white/10 transition cursor-pointer disabled:opacity-50"
              >
                {isAr ? "إلغاء" : "Cancel"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE LESSON MODAL */}
      {lessonToDelete && (
        <div
          id="delete-lesson-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => !isDeletingLesson && setLessonToDelete(null)}
        >
          <div
            id="delete-lesson-modal-container"
            className="w-full max-w-md bg-[#151515] border border-red-500/30 rounded-3xl p-6 sm:p-7 space-y-5 shadow-2xl relative animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Close Button */}
            <button
              id="cancel-delete-lesson-x-btn"
              disabled={isDeletingLesson}
              onClick={() => setLessonToDelete(null)}
              className="absolute top-4 left-4 p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer disabled:opacity-50"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header with Danger Icon */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400 flex-shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">
                  {isAr ? "تأكيد حذف الدرس" : "Confirm Lesson Deletion"}
                </h3>
                <p className="text-xs text-red-400/90 font-medium">
                  {isAr ? "سيتم حذف رابط الفيديو والدرس من الكورس" : "Lesson will be deleted"}
                </p>
              </div>
            </div>

            {/* Lesson Preview Box */}
            <div className="p-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-1">
              <p className="text-xs font-bold text-white">{lessonToDelete.title}</p>
              <p className="text-[11px] text-gray-400 font-mono truncate">{lessonToDelete.videoUrl}</p>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center gap-3 pt-2">
              <button
                id="confirm-delete-lesson-btn"
                disabled={isDeletingLesson}
                onClick={handleConfirmDeleteLesson}
                className="flex-1 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm bg-red-600 hover:bg-red-500 text-white flex items-center justify-center gap-2 transition shadow-lg shadow-red-600/30 cursor-pointer disabled:opacity-50"
              >
                {isDeletingLesson ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{isAr ? "جاري الحذف..." : "Deleting..."}</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>{isAr ? "نعم، احذف الدرس" : "Yes, Delete Lesson"}</span>
                  </>
                )}
              </button>
              <button
                id="cancel-delete-lesson-btn"
                disabled={isDeletingLesson}
                onClick={() => setLessonToDelete(null)}
                className="py-2.5 px-4 rounded-xl font-semibold text-xs sm:text-sm bg-[#1A1A1A] hover:bg-[#252525] text-gray-300 hover:text-white border border-white/10 transition cursor-pointer disabled:opacity-50"
              >
                {isAr ? "إلغاء" : "Cancel"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
