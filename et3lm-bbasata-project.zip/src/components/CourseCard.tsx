import React from "react";
import { Course } from "../types";
import { useApp } from "../context/AppContext";
import {
  Clock,
  BookOpen,
  Star,
  Users,
  CreditCard,
  CheckCircle2,
  ArrowLeft,
  Sparkles,
  Lock,
  PlayCircle,
} from "lucide-react";

interface CourseCardProps {
  course: Course;
  onSelect: (course: Course) => void;
  onEnroll: (course: Course) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({
  course,
  onSelect,
  onEnroll,
}) => {
  const { isEnrolledInCourse, language, setActiveView, setSelectedCourse } =
    useApp();
  const isAr = language === "ar";
  const enrolled = isEnrolledInCourse(course.id);

  const discountPercent = course.originalPrice
    ? Math.round(
        ((course.originalPrice - course.price) / course.originalPrice) * 100
      )
    : null;

  return (
    <div
      id={`course-card-${course.id}`}
      className="rounded-2xl bg-[#151515] border border-white/10 overflow-hidden flex flex-col justify-between transition-all duration-300 group hover:border-[#D4AF37]/50"
    >
      <div>
        {/* Course Thumbnail Image */}
        <div className="relative aspect-video overflow-hidden bg-[#0A0A0A]">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#151515] via-transparent to-transparent opacity-90"></div>

          {/* Level Badge */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-black/70 backdrop-blur border border-white/10 text-gray-200">
              {course.level}
            </span>
            {course.featured && (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white flex items-center gap-1 shadow-sm">
                <Sparkles className="w-3 h-3 text-[#F3E5AB]" />
                <span>{isAr ? "مميز" : "Featured"}</span>
              </span>
            )}
          </div>

          {/* Category Pill */}
          <div className="absolute bottom-3 right-3">
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-black/80 backdrop-blur text-gray-300 border border-white/10">
              {course.category}
            </span>
          </div>

          {/* Enrolled Status Overlay if applicable */}
          {enrolled && (
            <div className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1 shadow-lg border border-emerald-400/40">
              <CheckCircle2 className="w-3 h-3" />
              <span>{isAr ? "مشترك بالفعل" : "Enrolled"}</span>
            </div>
          )}
        </div>

        {/* Course Details Body */}
        <div className="p-5 space-y-3">
          <span className="text-[10px] uppercase tracking-wider text-gray-500 block">
            {course.level === "مبتدئ"
              ? isAr
                ? "مستوى المبتدئين"
                : "Beginner Level"
              : course.level === "متوسط"
              ? isAr
                ? "مستوى متوسط"
                : "Intermediate Level"
              : isAr
              ? "مستوى متقدم"
              : "Advanced Level"}
          </span>

          <h3 className="text-base font-bold text-white group-hover:text-[#D4AF37] transition line-clamp-1 leading-snug">
            {isAr ? course.title : course.titleEn || course.title}
          </h3>

          <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
            {isAr ? course.description : course.descriptionEn || course.description}
          </p>

          {/* Meta specs: duration, lesson count, rating */}
          <div className="flex items-center justify-between text-xs text-gray-400 pt-2 border-t border-white/5">
            <div className="flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="text-[11px]">
                {course.lessonCount} {isAr ? "درس" : "lessons"}
              </span>
            </div>

            <div className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-[11px]">{course.duration}</span>
            </div>

            <div className="flex items-center gap-1 font-bold text-[#D4AF37]">
              <Star className="w-3.5 h-3.5 fill-[#D4AF37]" />
              <span className="text-[11px]">{course.rating || 4.9}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer / Price & Actions */}
      <div className="p-5 pt-0">
        <div className="p-3 rounded-xl bg-[#1A1A1A] border border-white/5 flex items-center justify-between gap-3">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-bold text-[#D4AF37] font-mono">
                {course.price}
              </span>
              <span className="text-[11px] font-bold text-gray-400">
                {isAr ? "ج.م" : "EGP"}
              </span>
              {course.originalPrice && (
                <span className="text-[10px] text-gray-600 line-through font-mono">
                  {course.originalPrice}
                </span>
              )}
            </div>
            <p className="text-[10px] text-gray-500 font-semibold flex items-center gap-1">
              <CreditCard className="w-3 h-3 text-blue-400" />
              <span>Etisalat Cash</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id={`details-btn-${course.id}`}
              onClick={() => onSelect(course)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-gray-300 hover:text-white bg-white/5 border border-white/10 hover:bg-white/10 transition"
            >
              {isAr ? "التفاصيل" : "Details"}
            </button>

            {enrolled ? (
              <button
                id={`watch-btn-${course.id}`}
                onClick={() => {
                  setSelectedCourse(course);
                  setActiveView("player");
                }}
                className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow flex items-center gap-1 transition cursor-pointer"
              >
                <PlayCircle className="w-3.5 h-3.5" />
                <span>{isAr ? "شاهد" : "Start"}</span>
              </button>
            ) : (
              <button
                id={`enroll-btn-${course.id}`}
                onClick={() => onEnroll(course)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-md shadow-[#D4AF37]/20 transition flex items-center gap-1 cursor-pointer"
              >
                <span>{isAr ? "اشترك" : "Enroll"}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
