import React, { useState, useRef } from "react";
import { useApp } from "../context/AppContext";
import { Course } from "../types";
import {
  X,
  CreditCard,
  Copy,
  Check,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Phone,
  ArrowLeft,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

interface EtisalatCashModalProps {
  course: Course | null;
  isOpen: boolean;
  onClose: () => void;
}

export const EtisalatCashModal: React.FC<EtisalatCashModalProps> = ({
  course,
  isOpen,
  onClose,
}) => {
  const {
    settings,
    user,
    submitEtisalatPayment,
    setIsAuthModalOpen,
    setAuthModalMode,
    setActiveView,
    language,
  } = useApp();

  const isAr = language === "ar";
  const [copied, setCopied] = useState(false);
  const [senderPhone, setSenderPhone] = useState(user?.phone || "");
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [receiptFileName, setReceiptFileName] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const fileInputRef = useRef<HTMLInputElement>(null);

  const walletThemes: Record<string, { gradient: string; border: string; accent: string }> = {
    gold: {
      gradient: "from-[#1a1505] via-[#2a220a] to-[#120e03]",
      border: "border-[#D4AF37]/40",
      accent: "#D4AF37",
    },
    emerald: {
      gradient: "from-[#031c14] via-[#052b20] to-[#01140e]",
      border: "border-emerald-500/40",
      accent: "#10b981",
    },
    carbon: {
      gradient: "from-[#18181b] via-[#27272a] to-[#09090b]",
      border: "border-gray-600/40",
      accent: "#e4e4e7",
    },
    sapphire: {
      gradient: "from-[#081b33] via-[#0c2a52] to-[#041021]",
      border: "border-blue-500/40",
      accent: "#38bdf8",
    },
  };

  const currentWalletTheme =
    walletThemes[settings?.walletTheme || "gold"] || walletThemes.gold;

  if (!isOpen || !course) return null;

  const walletNumber = settings.etisalatCashNumber || "01157783934";

  const handleCopyWallet = () => {
    navigator.clipboard.writeText(walletNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        setErrorMsg(isAr ? "حجم الصورة كبير جداً، الحد الأقصى 8 ميجابايت" : "Image size too large (max 8MB)");
        return;
      }
      setReceiptFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setReceiptImage(reader.result as string);
        setErrorMsg("");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (!user) {
      setAuthModalMode("login");
      setIsAuthModalOpen(true);
      return;
    }

    if (!senderPhone.trim()) {
      setErrorMsg(isAr ? "يرجى كتابة رقم الهاتف المحول منه" : "Please enter your sender phone number");
      return;
    }

    if (!receiptImage) {
      setErrorMsg(isAr ? "يرجى إرفاق صورة إيصال التحويل" : "Please upload your payment receipt screenshot");
      return;
    }

    setSubmitting(true);
    try {
      await submitEtisalatPayment(course, senderPhone, receiptImage);
      setSubmittedSuccess(true);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || (isAr ? "فشل إرسال طلب الدفع" : "Failed to submit payment"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      id="etisalat-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="etisalat-modal-container"
        className="w-full max-w-xl bg-[#151515] border border-white/10 rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          id="etisalat-modal-close-btn"
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {submittedSuccess ? (
          /* Success Screen */
          <div className="text-center py-6 space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-white">
                {isAr ? "تم استلام طلب اشتراكك بنجاح!" : "Payment Request Submitted!"}
              </h3>
              <p className="text-sm text-gray-300 max-w-md mx-auto leading-relaxed">
                {isAr
                  ? `تم تسجيل طلب دفع كورس «${course.title}» بحالة (قيد المراجعة). سيقوم مشرف المنصة بمراجعة إيصال التحويل وتفعيل الكورس في حسابك فوراً.`
                  : `Your request has been submitted with status (Pending). Our admin will verify your receipt and unlock the course shortly.`}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/20 text-right text-xs space-y-2 max-w-md mx-auto">
              <div className="flex justify-between text-gray-400">
                <span>{isAr ? "الكورس:" : "Course:"}</span>
                <span className="text-white font-bold">{course.title}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>{isAr ? "المبلغ المطلوب:" : "Amount:"}</span>
                <span className="text-[#D4AF37] font-bold font-mono">{course.price} ج.م</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>{isAr ? "حالة الطلب:" : "Status:"}</span>
                <span className="text-[#D4AF37] font-bold bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/30">
                  {isAr ? "قيد المراجعة (Pending)" : "Pending Review"}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <button
                onClick={() => {
                  onClose();
                  setActiveView("student-dashboard");
                }}
                className="px-6 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-lg shadow-[#D4AF37]/25 transition cursor-pointer"
              >
                {isAr ? "متابعة الطلبات في لوحة الطالب" : "Go to My Dashboard"}
              </button>
              <button
                onClick={onClose}
                className="px-5 py-3 rounded-xl font-semibold text-gray-300 hover:text-white bg-[#0A0A0A] border border-white/10 hover:bg-white/10 transition cursor-pointer"
              >
                {isAr ? "إغلاق النافذة" : "Close"}
              </button>
            </div>
          </div>
        ) : (
          /* Payment Form */
          <>
            {/* Modal Header */}
            <div className="text-center space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-bold">
                <CreditCard className="w-4 h-4" />
                <span>{isAr ? "الدفع عبر محفظة Etisalat Cash" : "Pay with Etisalat Cash"}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-white">
                {isAr ? "الاشتراك في كورس" : "Enroll in Course"}: {course.title}
              </h3>
              <p className="text-xs text-gray-400">
                {isAr
                  ? "اتبع الخطوات البسيطة التالية لتحويل المبلغ وتأكيد اشتراكك"
                  : "Follow these 4 simple steps to complete your registration"}
              </p>
            </div>

            {/* Error Message Alert */}
            {errorMsg && (
              <div className="p-3.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Step 1: Wallet Info & Price */}
            <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-[#D4AF37]/30 space-y-3">
              <div className="flex items-center justify-between text-xs text-gray-300 border-b border-white/10 pb-2">
                <span>{isAr ? "قيمة الاشتراك الإجمالية:" : "Course Total Price:"}</span>
                <span className="text-lg font-bold text-[#D4AF37] font-mono">
                  {course.price} <span className="text-xs font-bold text-gray-300">{isAr ? "جنيه مصري" : "EGP"}</span>
                </span>
              </div>

              <div className="space-y-1">
                <p className="text-[11px] text-gray-400">
                  {isAr
                    ? "الخطوة 1: حوّل المبلغ أعلاه إلى رقم محفظة اتصالات كاش التالي:"
                    : "Step 1: Transfer the amount to this official Etisalat Cash wallet:"}
                </p>

                <div className={`relative overflow-hidden flex items-center justify-between gap-2 p-3 rounded-xl bg-gradient-to-r ${currentWalletTheme.gradient} border ${currentWalletTheme.border} shadow-lg`}>
                  {settings.walletBackgroundUrl && (
                    <img
                      src={settings.walletBackgroundUrl}
                      alt=""
                      referrerPolicy="no-referrer"
                      className="absolute inset-0 w-full h-full object-cover opacity-35 mix-blend-overlay pointer-events-none"
                    />
                  )}
                  <div className="relative z-10 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-black/40 border border-white/10 text-[#D4AF37] flex items-center justify-center font-bold">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <span className="font-mono text-base sm:text-lg font-bold text-[#D4AF37] tracking-wider">
                      {walletNumber}
                    </span>
                  </div>

                  <button
                    id="copy-wallet-btn"
                    type="button"
                    onClick={handleCopyWallet}
                    className="relative z-10 px-3 py-1.5 rounded-lg bg-black/50 hover:bg-black/80 border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">{isAr ? "تم النسخ" : "Copied"}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>{isAr ? "نسخ الرقم" : "Copy"}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Auth Check Prompt if guest */}
            {!user && (
              <div className="p-3.5 rounded-xl bg-blue-950/60 border border-blue-500/30 text-blue-200 text-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-blue-400 flex-shrink-0" />
                  <span>{isAr ? "يجب تسجيل الدخول لربط الكورس بحسابك" : "Please login to link this course"}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setAuthModalMode("login");
                    setIsAuthModalOpen(true);
                  }}
                  className="px-3 py-1 rounded-lg bg-blue-600 text-white font-bold text-xs whitespace-nowrap hover:bg-blue-500 transition cursor-pointer"
                >
                  {isAr ? "دخول / تسجيل" : "Sign In"}
                </button>
              </div>
            )}

            {/* Form: Sender Phone + Receipt Screenshot Upload */}
            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              {/* Step 2: Sender Phone */}
              <div>
                <label className="block text-gray-200 font-bold mb-1.5 text-xs">
                  {isAr ? "الخطوة 2: رقم هاتفك / المحفظة التي قمت بالتحويل منها:" : "Step 2: Your Wallet / Sender Phone Number:"}
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-500 absolute right-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    placeholder="011XXXXXXXX / 010XXXXXXXX"
                    className="w-full pr-10 pl-3 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50"
                  />
                </div>
              </div>

              {/* Step 3: Receipt Screenshot */}
              <div>
                <label className="block text-gray-200 font-bold mb-1.5 text-xs">
                  {isAr ? "الخطوة 3: صورة إيصال التحويل (Screenshot):" : "Step 3: Upload Transfer Receipt Screenshot:"}
                </label>

                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />

                {receiptImage ? (
                  <div className="relative rounded-2xl overflow-hidden border border-[#D4AF37]/40 bg-[#0A0A0A] p-2 space-y-2">
                    <img
                      src={receiptImage}
                      alt="Receipt Preview"
                      className="w-full max-h-48 object-contain rounded-xl bg-[#151515]"
                    />
                    <div className="flex items-center justify-between px-2 text-xs">
                      <span className="text-gray-300 font-medium truncate max-w-[200px]">
                        {receiptFileName || "receipt.png"}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setReceiptImage(null);
                          setReceiptFileName("");
                        }}
                        className="text-red-400 hover:underline font-semibold cursor-pointer"
                      >
                        {isAr ? "حذف وتغيير الصورة" : "Remove"}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-white/10 hover:border-[#D4AF37]/50 rounded-2xl p-6 text-center bg-[#0A0A0A]/60 hover:bg-[#0A0A0A] cursor-pointer transition space-y-2 group"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 group-hover:bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center mx-auto transition">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white group-hover:text-[#D4AF37]">
                        {isAr ? "اضغط هنا لاختيار أو سحب صورة الإيصال" : "Click to select or drop receipt screenshot"}
                      </p>
                      <p className="text-[11px] text-gray-500">
                        {isAr ? "صيغ PNG, JPG, JPEG (حد أقصى 8 ميجابايت)" : "PNG, JPG, JPEG up to 8MB"}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:brightness-110 shadow-xl shadow-[#D4AF37]/25 transition flex items-center justify-center gap-2 mt-4 cursor-pointer"
              >
                {submitting ? (
                  <span className="animate-spin text-sm">⏳ {isAr ? "جاري إرسال الطلب..." : "Submitting..."}</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span>{isAr ? "إرسال طلب التحويل والمراجعة" : "Submit Payment for Review"}</span>
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
