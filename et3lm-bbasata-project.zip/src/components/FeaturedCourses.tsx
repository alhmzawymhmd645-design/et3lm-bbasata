import React, { useState, useMemo } from "react";
import { useApp } from "../context/AppContext";
import { CourseCard } from "./CourseCard";
import { Course, CourseCategory } from "../types";
import {
  isCourseInSelectedCategory,
  getCategoryAncestry,
  buildCategoryTree,
} from "../lib/categoryUtils";
import {
  Search,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Layers,
  X,
  GraduationCap,
  Code,
  Palette,
  Bot,
  Terminal,
  Globe,
  Flame,
  Cpu,
  Database,
  Smartphone,
  BookMarked,
  Tag,
} from "lucide-react";

export const CATEGORY_ICONS: Record<string, React.FC<{ className?: string }>> = {
  GraduationCap,
  BookOpen,
  Code,
  Globe,
  Bot,
  Terminal,
  Palette,
  Flame,
  Sparkles,
  Cpu,
  Database,
  Smartphone,
  Layers,
  BookMarked,
  Tag,
};

interface FeaturedCoursesProps {
  onOpenDetails: (course: Course) => void;
  onOpenEnroll: (course: Course) => void;
  title?: string;
  subtitle?: string;
  limit?: number;
}

export const FeaturedCourses: React.FC<FeaturedCoursesProps> = ({
  onOpenDetails,
  onOpenEnroll,
  title,
  subtitle,
  limit,
}) => {
  const { courses, categories, levels, language } = useApp();
  const isAr = language === "ar";

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("all");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");

  // Dynamic active categories sorted by order
  const activeCategories = useMemo(() => {
    return (categories || [])
      .filter((c) => c.active !== false)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [categories]);

  // Dynamic active levels sorted by order
  const activeLevels = useMemo(() => {
    return (levels || [])
      .filter((l) => l.active !== false)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [levels]);

  // Main Tier Categories (parentId is null/undefined)
  const mainCategories = useMemo(() => {
    return activeCategories.filter((c) => !c.parentId);
  }, [activeCategories]);

  // Selected Category Ancestry
  const currentAncestry = useMemo(() => {
    if (selectedCategoryId === "all") return [];
    return getCategoryAncestry(selectedCategoryId, activeCategories);
  }, [selectedCategoryId, activeCategories]);

  // Current active main category (Root of selection)
  const activeMainCat = currentAncestry[0] || null;

  // Subcategories for current active main category (Tier 2)
  const subCategories = useMemo(() => {
    if (!activeMainCat) return [];
    return activeCategories.filter((c) => c.parentId === activeMainCat.id);
  }, [activeMainCat, activeCategories]);

  // Current active tier 2 category
  const activeSubCat = currentAncestry.length > 1 ? currentAncestry[1] : null;

  // Tertiary categories (Tier 3: Subjects/Tracks) under selected subcategory
  const tertiaryCategories = useMemo(() => {
    if (!activeSubCat) return [];
    return activeCategories.filter((c) => c.parentId === activeSubCat.id);
  }, [activeSubCat, activeCategories]);

  // Filter courses using search, hierarchy matching, and level
  const filteredCourses = useMemo(() => {
    return courses.filter((c) => {
      if (!c.published) return false;

      // Search match
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        c.title.toLowerCase().includes(q) ||
        (c.description && c.description.toLowerCase().includes(q)) ||
        (c.titleEn && c.titleEn.toLowerCase().includes(q));

      // Category match (Hierarchical)
      const matchCategory =
        selectedCategoryId === "all" ||
        isCourseInSelectedCategory(c, selectedCategoryId, categories);

      // Level match
      const matchLevel = selectedLevel === "all" || c.level === selectedLevel;

      return matchSearch && matchCategory && matchLevel;
    });
  }, [courses, searchQuery, selectedCategoryId, selectedLevel, categories]);

  const displayedCourses = limit ? filteredCourses.slice(0, limit) : filteredCourses;

  return (
    <section id="courses-section" className="py-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-bold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>{isAr ? "المسارات والتصنيفات التعليمية" : "Educational Tracks & Categories"}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            {title || (isAr ? "اختر مسارك التعليمي وابدأ التعلم ببساطة" : "Explore Courses & Tracks")}
          </h2>

          <p className="text-sm sm:text-base text-gray-400">
            {subtitle ||
              (isAr
                ? "تصفح حسب فئتك الدراسية أو تخصصك البرمجي والتصميمي مع فيديوهات منظمة وتمارين وتسهيلات دفع كاش."
                : "Browse by your academic stage, tech specialty, or design track.")}
          </p>
        </div>

        {/* Search & Hierarchical Filter Container */}
        <div className="bg-[#151515] border border-white/10 p-5 rounded-3xl mb-8 shadow-xl space-y-4">
          {/* Top Bar: Search Input & Level Selector */}
          <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
            {/* Search Input */}
            <div className="relative w-full md:w-96">
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  isAr
                    ? "ابحث عن كورس، مادة دراسية، أو مهارة برمجية..."
                    : "Search courses, subjects, skills..."
                }
                className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs sm:text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#D4AF37]/50 transition"
              />
            </div>

            {/* Level Selector */}
            <div className="flex items-center gap-2 w-full md:w-auto self-end md:self-auto">
              <span className="text-xs text-gray-400 font-semibold whitespace-nowrap">
                {isAr ? "المستوى:" : "Level:"}
              </span>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="px-3.5 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-gray-200 focus:outline-none focus:border-[#D4AF37]/50"
              >
                <option value="all">{isAr ? "جميع المستويات" : "All Levels"}</option>
                {activeLevels.map((lvl) => (
                  <option key={lvl.id} value={lvl.name}>
                    {lvl.name} {lvl.nameEn ? `(${lvl.nameEn})` : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Tier 1: Main Category Pills */}
          <div className="space-y-2 pt-1 border-t border-white/5">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              <button
                onClick={() => setSelectedCategoryId("all")}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  selectedCategoryId === "all"
                    ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
                    : "bg-[#1A1A1A] text-gray-400 border border-white/5 hover:border-white/20 hover:text-white"
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{isAr ? "جميع الأقسام" : "All Categories"}</span>
              </button>

              {mainCategories.map((cat) => {
                const isSelected =
                  selectedCategoryId === cat.id ||
                  (activeMainCat && activeMainCat.id === cat.id);
                const IconComp = CATEGORY_ICONS[cat.icon || "GraduationCap"] || GraduationCap;

                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategoryId(cat.id)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-2 ${
                      isSelected
                        ? "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white shadow-md shadow-[#D4AF37]/20"
                        : "bg-[#1A1A1A] text-gray-400 border border-white/5 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    <IconComp className="w-3.5 h-3.5" />
                    <span>{cat.name}</span>
                  </button>
                );
              })}
            </div>

            {/* Tier 2: Subcategory Pills if main category has children */}
            {subCategories.length > 0 && (
              <div className="p-3 rounded-2xl bg-[#0A0A0A] border border-blue-500/20 space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between text-[11px] text-gray-400 font-semibold px-1">
                  <span>
                    {isAr
                      ? `الأقسام الفرعية لـ «${activeMainCat?.name}»:`
                      : `Subcategories for "${activeMainCat?.name}":`}
                  </span>
                  {selectedCategoryId !== activeMainCat?.id && (
                    <button
                      onClick={() => setSelectedCategoryId(activeMainCat!.id)}
                      className="text-blue-400 hover:underline cursor-pointer"
                    >
                      {isAr ? "عرض الكل في هذا القسم" : "View all in this category"}
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                  <button
                    onClick={() => setSelectedCategoryId(activeMainCat!.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                      selectedCategoryId === activeMainCat?.id
                        ? "bg-blue-600 text-white font-bold"
                        : "bg-[#151515] text-gray-400 border border-white/10 hover:text-white"
                    }`}
                  >
                    {isAr ? "الكل" : "All"}
                  </button>

                  {subCategories.map((sub) => {
                    const isSelected =
                      selectedCategoryId === sub.id ||
                      (activeSubCat && activeSubCat.id === sub.id);
                    return (
                      <button
                        key={sub.id}
                        onClick={() => setSelectedCategoryId(sub.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                          isSelected
                            ? "bg-blue-600 text-white font-bold shadow-sm"
                            : "bg-[#151515] text-gray-400 border border-white/10 hover:text-white"
                        }`}
                      >
                        {sub.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tier 3: Tertiary Subject/Track Pills */}
            {tertiaryCategories.length > 0 && (
              <div className="p-3 rounded-2xl bg-[#0A0A0A] border border-emerald-500/20 space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between text-[11px] text-gray-400 font-semibold px-1">
                  <span>
                    {isAr
                      ? `المواد والتصنيفات في «${activeSubCat?.name}»:`
                      : `Tracks in "${activeSubCat?.name}":`}
                  </span>
                  {selectedCategoryId !== activeSubCat?.id && (
                    <button
                      onClick={() => setSelectedCategoryId(activeSubCat!.id)}
                      className="text-emerald-400 hover:underline cursor-pointer"
                    >
                      {isAr ? "عرض جميع مواد هذا القسم" : "View all subjects"}
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                  <button
                    onClick={() => setSelectedCategoryId(activeSubCat!.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                      selectedCategoryId === activeSubCat?.id
                        ? "bg-emerald-600 text-white font-bold"
                        : "bg-[#151515] text-gray-400 border border-white/10 hover:text-white"
                    }`}
                  >
                    {isAr ? "الكل" : "All"}
                  </button>

                  {tertiaryCategories.map((tert) => {
                    const isSelected = selectedCategoryId === tert.id;
                    return (
                      <button
                        key={tert.id}
                        onClick={() => setSelectedCategoryId(tert.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                          isSelected
                            ? "bg-emerald-600 text-white font-bold shadow-sm"
                            : "bg-[#151515] text-gray-400 border border-white/10 hover:text-white"
                        }`}
                      >
                        {tert.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Active Breadcrumbs Bar with Reset */}
            {selectedCategoryId !== "all" && (
              <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-xs text-gray-300">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-gray-500 font-semibold">
                    {isAr ? "المسار المختار:" : "Active Trail:"}
                  </span>
                  <button
                    onClick={() => setSelectedCategoryId("all")}
                    className="text-gray-400 hover:text-white hover:underline cursor-pointer"
                  >
                    {isAr ? "الرئيسية" : "Home"}
                  </button>
                  {currentAncestry.map((anc, idx) => (
                    <React.Fragment key={anc.id}>
                      <span className="text-gray-600">/</span>
                      <button
                        onClick={() => setSelectedCategoryId(anc.id)}
                        className={`hover:underline cursor-pointer ${
                          idx === currentAncestry.length - 1
                            ? "font-bold text-[#D4AF37]"
                            : "text-gray-400 hover:text-white"
                        }`}
                      >
                        {anc.name}
                      </button>
                    </React.Fragment>
                  ))}
                </div>

                <button
                  onClick={() => setSelectedCategoryId("all")}
                  className="px-2 py-1 rounded-md text-[10px] font-bold bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white flex items-center gap-1 transition cursor-pointer"
                >
                  <X className="w-3 h-3" />
                  <span>{isAr ? "إعادة ضبط الفلتر" : "Clear Filter"}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Courses Count Bar */}
        <div className="flex items-center justify-between text-xs text-gray-400 mb-4 px-1">
          <span>
            {isAr
              ? `عرض (${displayedCourses.length}) كورس مطابق`
              : `Showing ${displayedCourses.length} matching courses`}
          </span>
        </div>

        {/* Courses Grid */}
        {displayedCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayedCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                onSelect={onOpenDetails}
                onEnroll={onOpenEnroll}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 px-4 rounded-3xl bg-[#151515] border border-white/10 space-y-3">
            <BookOpen className="w-12 h-12 text-gray-600 mx-auto" />
            <h3 className="text-base font-bold text-white">
              {isAr ? "لم نجد كورسات مطابقة لهذا التصنيف حالياً" : "No courses matching this filter"}
            </h3>
            <p className="text-xs text-gray-400 max-w-sm mx-auto">
              {isAr
                ? "يمكنك تغيير التصنيف أو مسح كلمات البحث للاطلاع على جميع الكورسات المتاحة."
                : "Try selecting a higher category level or clearing your search keywords."}
            </p>
            <button
              onClick={() => {
                setSelectedCategoryId("all");
                setSearchQuery("");
                setSelectedLevel("all");
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#D4AF37] text-black hover:brightness-110 cursor-pointer shadow-md"
            >
              {isAr ? "عرض جميع الكورسات" : "View All Courses"}
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
