import React, { useEffect, useState } from "react";
import { useApp } from "../context/AppContext";
import { ShieldAlert, ShieldCheck, Lock, EyeOff, AlertTriangle } from "lucide-react";

export const ContentProtection: React.FC = () => {
  const { user, language, activeView } = useApp();
  const isAr = language === "ar";

  const [isScreenBlurred, setIsScreenBlurred] = useState(false);
  const [securityWarning, setSecurityWarning] = useState<string | null>(null);

  // Dynamic Floating Watermark Coordinates
  const [watermarkPos, setWatermarkPos] = useState({ top: 20, left: 30, opacity: 0.45 });
  const [timestamp, setTimestamp] = useState(new Date().toLocaleTimeString());

  // Periodically update watermark position and timestamp to prevent masking/cropping
  useEffect(() => {
    const interval = setInterval(() => {
      const randomTop = Math.floor(Math.random() * 65) + 15; // 15% to 80%
      const randomLeft = Math.floor(Math.random() * 60) + 15; // 15% to 75%
      const randomOpacity = (Math.random() * 0.25 + 0.35).toFixed(2); // 0.35 to 0.60
      setWatermarkPos({
        top: randomTop,
        left: randomLeft,
        opacity: parseFloat(randomOpacity),
      });
      setTimestamp(new Date().toLocaleTimeString());
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  // Prevent Right Click, Copy, Print, DevTools, and Screen Capture Keys
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      // Allow right click on input/textarea elements for user convenience, but block on general content/videos
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") {
        return;
      }
      e.preventDefault();
      triggerSecurityNotice(
        isAr
          ? "⚠️ عذرًا، القائمة السريعة معطلة لحماية المحتوى التعليمي من النسخ غير المصرح به."
          : "⚠️ Context menu is disabled to protect educational copyright."
      );
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();

      // Block F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C (DevTools)
      if (
        e.key === "F12" ||
        (e.ctrlKey && e.shiftKey && (key === "i" || key === "j" || key === "c")) ||
        (e.metaKey && e.altKey && (key === "i" || key === "j" || key === "c"))
      ) {
        e.preventDefault();
        triggerSecurityNotice(
          isAr
            ? "🔒 تم تعطيل أدوات المطورين لحماية حقوق الملكية الفكرية."
            : "🔒 Developer tools are disabled to protect copyright."
        );
        return;
      }

      // Block Ctrl+S / Cmd+S (Save Page)
      if ((e.ctrlKey || e.metaKey) && key === "s") {
        e.preventDefault();
        triggerSecurityNotice(
          isAr
            ? "🚫 ممنوع حفظ أو تحميل صفحات وفيديوهات الكورس."
            : "🚫 Page saving is disabled."
        );
        return;
      }

      // Block Ctrl+P / Cmd+P (Print)
      if ((e.ctrlKey || e.metaKey) && key === "p") {
        e.preventDefault();
        triggerSecurityNotice(
          isAr
            ? "🚫 الطباعة وتصدير المحتوى محظورة لحماية المادة العلمية."
            : "🚫 Printing is disabled."
        );
        return;
      }

      // Block Ctrl+U / Cmd+U (View Source)
      if ((e.ctrlKey || e.metaKey) && key === "u") {
        e.preventDefault();
        return;
      }

      // Block PrintScreen / Screen Capture keys
      if (
        e.key === "PrintScreen" ||
        e.key === "PrtScn" ||
        e.key === "Snapshot" ||
        ((e.ctrlKey || e.metaKey) && e.shiftKey && (key === "s" || key === "3" || key === "4"))
      ) {
        // Clear clipboard immediately
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText("");
        }
        setIsScreenBlurred(true);
        triggerSecurityNotice(
          isAr
            ? "🚫 تم منع لقطة الشاشة وتسجيل الفيديو! الحساب مرتبط بالعلامة المائية الرقمية."
            : "🚫 Screen recording/capture is prohibited! DRM Active."
        );
        setTimeout(() => setIsScreenBlurred(false), 2500);
      }
    };

    // Block Dragging of Images / Videos
    const handleDragStart = (e: DragEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "IMG" || target.tagName === "VIDEO" || target.closest("video")) {
        e.preventDefault();
      }
    };

    // Window Blur & Visibility Change (Anti-Screen Capture / Recording Overlay)
    const handleVisibilityChange = () => {
      if (document.hidden && activeView === "player") {
        setIsScreenBlurred(true);
      } else {
        setIsScreenBlurred(false);
      }
    };

    const handleWindowBlur = () => {
      if (activeView === "player") {
        setIsScreenBlurred(true);
      }
    };

    const handleWindowFocus = () => {
      setIsScreenBlurred(false);
    };

    // Attach global listeners
    document.addEventListener("contextmenu", handleContextMenu);
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("dragstart", handleDragStart);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("blur", handleWindowBlur);
    window.addEventListener("focus", handleWindowFocus);

    return () => {
      document.removeEventListener("contextmenu", handleContextMenu);
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("dragstart", handleDragStart);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("blur", handleWindowBlur);
      window.removeEventListener("focus", handleWindowFocus);
    };
  }, [isAr, activeView]);

  const triggerSecurityNotice = (msg: string) => {
    setSecurityWarning(msg);
    setTimeout(() => {
      setSecurityWarning((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  return (
    <>
      {/* Dynamic Security Toast Notice */}
      {securityWarning && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md p-4 rounded-2xl bg-[#1A0A0A] border-2 border-red-500/80 text-white shadow-2xl shadow-red-900/50 flex items-start gap-3 animate-bounce">
          <ShieldAlert className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <p className="font-bold text-red-300">
              {isAr ? "نظام حماية المحتوى والملكية الفكرية" : "DRM Copyright Protection"}
            </p>
            <p className="text-gray-300 leading-relaxed">{securityWarning}</p>
          </div>
        </div>
      )}

      {/* Anti-Screen Recording Blur Shield (When tab loses focus during lesson viewing) */}
      {isScreenBlurred && activeView === "player" && (
        <div className="fixed inset-0 z-50 bg-[#050505]/95 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center text-white space-y-4 select-none">
          <div className="w-16 h-16 rounded-3xl bg-red-950/60 border border-red-500/50 flex items-center justify-center text-red-400 shadow-2xl shadow-red-900/40">
            <EyeOff className="w-8 h-8 animate-pulse" />
          </div>
          <div className="space-y-2 max-w-md">
            <h3 className="text-xl font-extrabold text-white">
              {isAr ? "تم إيقاف العرض مؤقتًا لدواعي الأمان" : "Display Paused for Security"}
            </h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              {isAr
                ? "يتم حجب محتوى الكورس أثناء مغادرة النافذة أو تشغيل برامج التسجيل والتقاط الشاشة لحماية حقوق المنصة."
                : "Course playback is paused while outside window to prevent unauthorized screen recording."}
            </p>
          </div>
          <button
            onClick={() => setIsScreenBlurred(false)}
            className="px-6 py-2.5 rounded-xl font-bold bg-[#D4AF37] text-black hover:bg-[#c49f2e] text-xs transition cursor-pointer shadow-lg shadow-[#D4AF37]/20"
          >
            {isAr ? "العودة ومتابعة المشاهدة" : "Resume Watching"}
          </button>
        </div>
      )}
    </>
  );
};

// Reusable Floating DRM Watermark overlay for Video Players and Protected Lesson Views
export const DynamicVideoWatermark: React.FC<{ studentIdentifier?: string }> = ({
  studentIdentifier,
}) => {
  const { user, language } = useApp();
  const isAr = language === "ar";
  const [pos, setPos] = useState({ top: 25, left: 35, opacity: 0.35 });
  const [time, setTime] = useState(new Date().toLocaleTimeString());

  const identifier =
    studentIdentifier ||
    user?.email ||
    user?.name ||
    (user?.id ? `ID: ${user.id.slice(0, 8)}` : "طالب مصرح له");

  useEffect(() => {
    const timer = setInterval(() => {
      const t = Math.floor(Math.random() * 65) + 15;
      const l = Math.floor(Math.random() * 55) + 15;
      const op = (Math.random() * 0.2 + 0.25).toFixed(2);
      setPos({ top: t, left: l, opacity: parseFloat(op) });
      setTime(new Date().toLocaleTimeString());
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div
      aria-hidden="true"
      style={{
        top: `${pos.top}%`,
        left: `${pos.left}%`,
        opacity: pos.opacity,
      }}
      className="absolute pointer-events-none z-30 select-none transition-all duration-1000 ease-in-out transform -translate-x-1/2 -translate-y-1/2"
    >
      <div className="px-3 py-1.5 rounded-lg bg-black/60 border border-white/20 text-white font-mono text-[10px] sm:text-xs font-semibold backdrop-blur-[2px] shadow-lg flex flex-col items-center gap-0.5 leading-tight">
        <span className="text-[#D4AF37] font-bold tracking-wide">
          اتعلم ببساطة © DRM Protected
        </span>
        <span className="text-gray-200">{identifier}</span>
        <span className="text-[9px] text-gray-400 font-sans">
          {time} • يمنع التصوير والتسجيل
        </span>
      </div>
    </div>
  );
};
