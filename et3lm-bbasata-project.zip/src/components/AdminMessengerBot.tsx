import React, { useState, useEffect, useRef } from "react";
import appLogo from "../assets/images/app_logo_1787091289735.jpg";
import { AdminMessengerPermissions } from "./AdminMessengerPermissions";
import {
  Bot,
  MessageSquare,
  Power,
  RefreshCw,
  Send,
  Users,
  AlertCircle,
  CheckCircle2,
  Copy,
  Check,
  Headphones,
  Sparkles,
  Zap,
  Clock,
  UserCheck,
  ShieldCheck,
  ChevronLeft,
  Search,
  Filter,
  Pin,
  PinOff,
  Archive,
  Tag,
  Phone,
  FileText,
  Settings,
  BarChart3,
  FlaskConical,
  Plus,
  Trash2,
  Sliders,
  AlertTriangle,
  Info,
  Layers,
  ArrowRight,
  Smile,
  Shield,
  Activity,
  User,
  Inbox,
  Volume2,
  Radio,
  CheckCheck,
  Lock,
} from "lucide-react";
import {
  MessengerConversation,
  MessengerMessage,
  MessengerMode,
  MessengerConversationStatus,
  MessengerAiSettings,
  InternalSystemDiagnosticResult,
  MessengerBotStats,
  MessengerAutoReplySettings,
  MessengerSettingsConfig,
} from "../types";

export const AdminMessengerBot: React.FC = () => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<
    "inbox" | "permissions" | "ai" | "auto_replies" | "analytics" | "simulator" | "diagnostics"
  >("inbox");

  // Core Data States
  const [loading, setLoading] = useState(true);
  const [conversations, setConversations] = useState<
    (MessengerConversation & { messages: MessengerMessage[] })[]
  >([]);
  const [selectedConvId, setSelectedConvId] = useState<string | null>(null);
  const [botEnabled, setBotEnabled] = useState(true);
  const [stats, setStats] = useState<MessengerBotStats>({
    totalConversations: 0,
    totalMessages: 0,
    activeWithAi: 0,
    humanSupportCount: 0,
    hybridCount: 0,
    unreadCount: 0,
    isBotGloballyEnabled: true,
    geminiConfigured: false,
    avgResponseTimeSec: 1.2,
    connectionStatus: "connected",
    connectionStatusAr: "متصل ونشط",
    lastConnectionAt: null,
  });

  // Messenger Settings & Auto-Replies State
  const [messengerSettings, setMessengerSettings] = useState<MessengerSettingsConfig>({
    systemName: "Internal Messenger Hub",
    connectionStatus: "connected",
    connectionStatusAr: "متصل",
    lastConnectionAt: null,
    autoReplies: {
      autoReplyEnabled: true,
      welcomeMessage:
        "أهلاً بك في منصة «اتعلم ببساطة» 👋✨\nأنا المساعد الذكي، كيف أستطيع مساعدتك اليوم بخصوص الكورسات البرمجية، الأسعار، أو طريقة الاشتراك والدفع عبر اتصالات كاش (01157783934)؟",
      welcomeMessageEnabled: true,
      awayMessage:
        "شكراً لتواصلك مع «اتعلم ببساطة» 🤍! فريق العمل والمشرفين خارج أوقات العمل الرسمية حالياً. تم تسجيل استفسارك وسيقوم المشرف بالرد عليك فوراً مع بداية ساعات العمل. يمكنك سؤال المساعد الذكي عن أي تفاصيل وسيجيبك فوراً!",
      awayMessageEnabled: false,
      aiEducationalEnabled: true,
      businessHoursStart: "09:00",
      businessHoursEnd: "23:00",
    },
  });

  const [savingAutoReplies, setSavingAutoReplies] = useState(false);
  const [autoRepliesSavedMsg, setAutoRepliesSavedMsg] = useState(false);

  // Filters and Search for Inbox
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<
    "all" | "new" | "open" | "pending" | "resolved" | "archived"
  >("all");
  const [modeFilter, setModeFilter] = useState<"all" | "ai" | "human" | "hybrid">("all");
  const [selectedTagFilter, setSelectedTagFilter] = useState<string | null>(null);

  // Chat & Reply State
  const [adminReplyText, setAdminReplyText] = useState("");
  const [sendingReply, setSendingReply] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const adminChatScrollContainerRef = useRef<HTMLDivElement>(null);
  const isAdminInitialLoadRef = useRef(true);

  // CRM / Note State
  const [newNoteText, setNewNoteText] = useState("");
  const [addingNote, setAddingNote] = useState(false);
  const [newTagInput, setNewTagInput] = useState("");
  const [showTagInput, setShowTagInput] = useState(false);

  // AI Settings State
  const [aiSettings, setAiSettings] = useState<MessengerAiSettings>({
    enabled: true,
    model: "gemini-3.7-flash",
    systemPrompt: `أنت المساعد الذكي الرسمي لمنصة «اتعلم ببساطة» التعليمية.
اسم المنصة: «اتعلم ببساطة»
رقم محفظة اتصالات كاش الرسمية: 01157783934
مهمتك: مساعدة الطلاب والإجابة على استفسارات الكورسات والأسعار والتسجيل والدفع وشرح المفاهيم البرمجية بأسلوب سهل وبسيط ومباشر وباللغة العربية الفصحى المبسطة أو اللهجة المصرية الودودة.
التزم بالحقائق الدقيقة، وإذا طلب المستخدم التحدث مع المشرف أو واجه مشكلة معقدة، قم بطمأنته بأنه تم تصعيد المحادثة لفريق الدعم البشري.`,
    temperature: 0.4,
    maxTokens: 600,
    fallbackMessage:
      "أهلاً بك في منصة «اتعلم ببساطة» 🤍 تلقينا رسالتك وسيقوم فريق الدعم الفني بمساعدتك في أسرع وقت. يمكنك أيضاً الاستفسار عن أي كورس أو طريقة الدفع عبر اتصالات كاش (01157783934).",
    humanHandoffEnabled: true,
    handoffKeywords: [
      "عايز اكلم حد",
      "عايز موظف",
      "عايز دعم",
      "كلمني حد",
      "خدمة العملاء",
      "بشري",
      "الادمن",
      "الأدمن",
      "حولني للأدمن",
      "مش راضي يشتغل",
      "المشكلة لسه موجودة",
      "فلوسي",
      "المحول",
    ],
  });
  const [savingAiSettings, setSavingAiSettings] = useState(false);
  const [aiSettingsSavedMessage, setAiSettingsSavedMessage] = useState(false);
  const [newHandoffKeyword, setNewHandoffKeyword] = useState("");

  // Simulator State
  const [simMessage, setSimMessage] = useState("");
  const [simLoading, setSimLoading] = useState(false);
  const [simResponse, setSimResponse] = useState<any>(null);

  // Analytics State
  const [analyticsData, setAnalyticsData] = useState<any>(null);

  // Diagnostics State
  const [diagLoading, setDiagLoading] = useState(false);
  const [diagResult, setDiagResult] = useState<InternalSystemDiagnosticResult | null>(null);

  // Quick Canned Replies
  const cannedReplies = [
    {
      label: "تفاصيل الكورسات والأسعار",
      text: "أهلاً بك 👋 يمكنك الاطلاع على جميع الكورسات المتاحة عبر المنصة:\n1. كورس برمجة الويب الشامل (400 ج.م)\n2. كورس بايثون وتحليل البيانات (350 ج.م)\n3. كورس الذكاء الاصطناعي (500 ج.م)\n4. كورس تطبيقات الهاتف (450 ج.م)\nكل كورس يشمل مشاريع عملية وشهادة معتمدة مجانية 🌟",
    },
    {
      label: "بيانات محفظة اتصالات كاش",
      text: "رقم محفظة الدفع الرسمية المعتمدة للمنصة هو: 01157783934 (اتصالات كاش).\nبعد إتمام التحويل يرجى رفع صورة الإيصال في الموقع لتفعيل الكورس فوراً 💳",
    },
    {
      label: "تأكيد تفعيل الكورس",
      text: "تمت مراجعة عملية التحويل وتفعيل الكورس في حسابك بنجاح! يمكنك الآن الدخول ومشاهدة الدروس فوراً، بالتوفيق دائماً يا بطل 🚀",
    },
    {
      label: "استلام الشهادة",
      text: "تظهر الشهادة المعتمدة تلقائياً في حسابك فور إتمام جميع دروس الكورس 100%، ويمكنك تحميلها وطباعتها مجاناً من تبويب (شهاداتي) 📜",
    },
  ];

  // Available pre-defined tags
  const defaultTags = [
    "طالب جديد",
    "استفسار عن كورس",
    "مشكلة دفع",
    "دعم فني عاجل",
    "استفسار شهادة",
    "طلب مدرس",
    "مهم",
  ];

  // Fetch All Internal Messenger Data
  const fetchData = async () => {
    try {
      const [statusRes, convsRes, aiRes, analyticsRes, settingsRes] = await Promise.all([
        fetch("/api/messenger/status"),
        fetch("/api/messenger/conversations"),
        fetch("/api/messenger/ai-settings"),
        fetch("/api/messenger/analytics"),
        fetch("/api/messenger/settings"),
      ]);

      if (statusRes.ok) {
        const statusData = await statusRes.json();
        setBotEnabled(statusData.isBotGloballyEnabled);
        if (statusData.stats) {
          setStats(statusData.stats);
        }
      }

      if (settingsRes.ok) {
        const sData = await settingsRes.json();
        if (sData.settings) {
          setMessengerSettings(sData.settings);
        }
      }

      if (convsRes.ok) {
        const convsData = await convsRes.json();
        if (convsData.conversations) {
          setConversations(convsData.conversations);
          if (!selectedConvId && convsData.conversations.length > 0) {
            setSelectedConvId(convsData.conversations[0].id);
          }
        }
      }

      if (aiRes.ok) {
        const aiData = await aiRes.json();
        if (aiData.settings) {
          setAiSettings(aiData.settings);
        }
      }

      if (analyticsRes.ok) {
        const aData = await analyticsRes.json();
        setAnalyticsData(aData.stats);
      }
    } catch (err) {
      console.error("Error fetching Messenger data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  // Auto-scroll chat inside its container only
  useEffect(() => {
    if (adminChatScrollContainerRef.current) {
      const container = adminChatScrollContainerRef.current;
      const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 150;
      if (isAdminInitialLoadRef.current || isNearBottom || sendingReply) {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: isAdminInitialLoadRef.current ? "auto" : "smooth",
        });
        isAdminInitialLoadRef.current = false;
      }
    }
  }, [conversations, selectedConvId, sendingReply]);

  useEffect(() => {
    isAdminInitialLoadRef.current = true;
  }, [selectedConvId]);

  // Selected Conversation Object
  const selectedConversation =
    conversations.find((c) => c.id === selectedConvId) || conversations[0];

  // Filtered Conversations List
  const filteredConversations = conversations.filter((c) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = c.senderName?.toLowerCase().includes(q);
      const matchId = c.senderId?.toLowerCase().includes(q);
      const matchLastMsg = c.lastMessageText?.toLowerCase().includes(q);
      const matchEmail = c.senderEmail?.toLowerCase().includes(q);
      if (!matchName && !matchId && !matchLastMsg && !matchEmail) return false;
    }

    if (statusFilter !== "all" && c.status !== statusFilter) return false;
    if (modeFilter !== "all" && c.mode !== modeFilter) return false;
    if (selectedTagFilter && !c.tags?.includes(selectedTagFilter)) return false;

    return true;
  });

  // Toggle Global Bot
  const handleToggleBot = async () => {
    try {
      const res = await fetch("/api/messenger/toggle-bot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: !botEnabled }),
      });
      if (res.ok) {
        const data = await res.json();
        setBotEnabled(data.isBotGloballyEnabled);
      }
    } catch (err) {
      console.error("Error toggling bot:", err);
    }
  };

  // Switch Conversation Mode (AI / Human / Hybrid)
  const handleUpdateMode = async (conversationId: string, newMode: MessengerMode) => {
    try {
      const res = await fetch("/api/messenger/conversation-mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, mode: newMode }),
      });
      if (res.ok) {
        setConversations((prev) =>
          prev.map((c) => (c.id === conversationId ? { ...c, mode: newMode } : c))
        );
      }
    } catch (err) {
      console.error("Error updating mode:", err);
    }
  };

  // Update Conversation Status
  const handleUpdateStatus = async (
    conversationId: string,
    newStatus: MessengerConversationStatus
  ) => {
    try {
      const res = await fetch("/api/messenger/update-conversation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, status: newStatus }),
      });
      if (res.ok) {
        setConversations((prev) =>
          prev.map((c) => (c.id === conversationId ? { ...c, status: newStatus } : c))
        );
      }
    } catch (err) {
      console.error("Error updating status:", err);
    }
  };

  // Toggle Pinned status
  const handleTogglePin = async (conversationId: string, currentPin?: boolean) => {
    try {
      const res = await fetch("/api/messenger/update-conversation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, pinned: !currentPin }),
      });
      if (res.ok) {
        setConversations((prev) =>
          prev.map((c) => (c.id === conversationId ? { ...c, pinned: !currentPin } : c))
        );
      }
    } catch (err) {
      console.error("Error toggling pin:", err);
    }
  };

  // Add Tag
  const handleAddTag = async (conversationId: string, tagToAdd: string) => {
    if (!tagToAdd.trim()) return;
    const currentTags = selectedConversation?.tags || [];
    if (currentTags.includes(tagToAdd.trim())) return;

    const newTags = [...currentTags, tagToAdd.trim()];
    try {
      const res = await fetch("/api/messenger/update-conversation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, tags: newTags }),
      });
      if (res.ok) {
        setConversations((prev) =>
          prev.map((c) => (c.id === conversationId ? { ...c, tags: newTags } : c))
        );
        setNewTagInput("");
        setShowTagInput(false);
      }
    } catch (err) {
      console.error("Error adding tag:", err);
    }
  };

  // Remove Tag
  const handleRemoveTag = async (conversationId: string, tagToRemove: string) => {
    const currentTags = selectedConversation?.tags || [];
    const newTags = currentTags.filter((t) => t !== tagToRemove);
    try {
      const res = await fetch("/api/messenger/update-conversation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, tags: newTags }),
      });
      if (res.ok) {
        setConversations((prev) =>
          prev.map((c) => (c.id === conversationId ? { ...c, tags: newTags } : c))
        );
      }
    } catch (err) {
      console.error("Error removing tag:", err);
    }
  };

  // Add Internal Note
  const handleAddNote = async () => {
    if (!selectedConvId || !newNoteText.trim() || addingNote) return;
    try {
      setAddingNote(true);
      const res = await fetch("/api/messenger/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: selectedConvId,
          noteText: newNoteText.trim(),
          authorName: "المشرف الإداري",
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setConversations((prev) =>
          prev.map((c) =>
            c.id === selectedConvId
              ? { ...c, notesList: data.notesList, notes: newNoteText.trim() }
              : c
          )
        );
        setNewNoteText("");
      }
    } catch (err) {
      console.error("Error adding note:", err);
    } finally {
      setAddingNote(false);
    }
  };

  // Send Admin Reply
  const handleSendAdminReply = async () => {
    if (!selectedConvId || !adminReplyText.trim() || sendingReply) return;
    try {
      setSendingReply(true);
      const text = adminReplyText.trim();
      const res = await fetch("/api/messenger/send-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: selectedConvId,
          text,
          adminName: "المشرف",
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setAdminReplyText("");
        if (data.messageRecord) {
          setConversations((prev) =>
            prev.map((c) => {
              if (c.id === selectedConvId) {
                const currentMsgs = c.messages || [];
                return {
                  ...c,
                  messages: [...currentMsgs, data.messageRecord],
                  lastMessageAt: new Date().toISOString(),
                  lastMessageText: text,
                  lastSender: "admin",
                  unreadCount: 0,
                };
              }
              return c;
            })
          );
        }
      }
    } catch (err) {
      console.error("Error sending admin reply:", err);
    } finally {
      setSendingReply(false);
    }
  };

  // Save Auto-Replies
  const handleSaveAutoReplies = async (
    newAutoReplies?: Partial<MessengerAutoReplySettings>
  ) => {
    try {
      setSavingAutoReplies(true);
      const updated = newAutoReplies
        ? { ...messengerSettings.autoReplies, ...newAutoReplies }
        : messengerSettings.autoReplies;
      const res = await fetch("/api/messenger/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ autoReplies: updated }),
      });
      if (res.ok) {
        const data = await res.json();
        setMessengerSettings((prev) => ({
          ...prev,
          autoReplies: data.autoReplies || updated,
        }));
        setAutoRepliesSavedMsg(true);
        setTimeout(() => setAutoRepliesSavedMsg(false), 4000);
      }
    } catch (err) {
      console.error("Error saving auto replies:", err);
    } finally {
      setSavingAutoReplies(false);
    }
  };

  // Save AI Settings
  const handleSaveAiSettings = async () => {
    try {
      setSavingAiSettings(true);
      const res = await fetch("/api/messenger/ai-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(aiSettings),
      });
      if (res.ok) {
        setAiSettingsSavedMessage(true);
        setTimeout(() => setAiSettingsSavedMessage(false), 4000);
      }
    } catch (err) {
      console.error("Error saving AI settings:", err);
    } finally {
      setSavingAiSettings(false);
    }
  };

  // Run Simulator Test
  const handleRunSimulator = async () => {
    if (!simMessage.trim() || simLoading) return;
    try {
      setSimLoading(true);
      const res = await fetch("/api/messenger/test-simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageText: simMessage.trim(),
          senderName: "طالب تجريبي",
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setSimResponse(data);
      }
    } catch (err) {
      console.error("Error simulating message:", err);
    } finally {
      setSimLoading(false);
    }
  };

  // Run System Diagnostics
  const handleRunDiagnostics = async () => {
    try {
      setDiagLoading(true);
      setDiagResult(null);
      const res = await fetch("/api/messenger/test-connection", {
        method: "POST",
      });
      const data = await res.json();
      setDiagResult(data);
    } catch (err) {
      console.error("Error running diagnostics:", err);
    } finally {
      setDiagLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* HEADER & GLOBAL BANNER */}
      <div className="p-6 rounded-3xl bg-[#141414] border border-[#D4AF37]/30 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] relative flex-shrink-0 shadow-lg">
            <MessageSquare className="w-7 h-7" />
            <span
              className={`absolute -top-1 -right-1 w-4 h-4 rounded-full border-2 border-[#141414] ${
                botEnabled ? "bg-emerald-500 animate-pulse" : "bg-gray-500"
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                نظام المراسلة والمساعد الذكي
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30 flex items-center gap-1">
                <Shield className="w-3 h-3" /> نظام داخلي مستقل 100%
              </span>
            </div>
            <p className="text-xs sm:text-sm text-gray-400 mt-1">
              إدارة المحادثات المباشرة بين الطلاب والمشرفين، والرد الآلي الذكي بمحرك Gemini AI وتصعيد الحالات الحساسة
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <button
            onClick={handleToggleBot}
            className={`flex-1 md:flex-none px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-lg ${
              botEnabled
                ? "bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30"
                : "bg-red-600/20 text-red-400 border border-red-500/30 hover:bg-red-600/30"
            }`}
          >
            <Power className="w-4 h-4" />
            <span>{botEnabled ? "المساعد الذكي نشط (Auto-Pilot On)" : "المساعد متوقف (معطل)"}</span>
          </button>

          <button
            onClick={fetchData}
            disabled={loading}
            className="p-2.5 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] text-gray-300 hover:text-white border border-white/10 transition cursor-pointer disabled:opacity-50"
            title="تحديث البيانات"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin text-[#D4AF37]" : ""}`} />
          </button>
        </div>
      </div>

      {/* QUICK STATUS METRICS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#141414] border border-white/10 flex items-center justify-between shadow-lg">
          <div className="space-y-1">
            <p className="text-[11px] text-gray-400 font-semibold">إجمالي المحادثات</p>
            <p className="text-xl font-mono font-black text-white">{conversations.length}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-950/80 text-blue-400 border border-blue-500/30 flex items-center justify-center">
            <Inbox className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border border-white/10 flex items-center justify-between shadow-lg">
          <div className="space-y-1">
            <p className="text-[11px] text-gray-400 font-semibold">محادثات بالذكاء الاصطناعي</p>
            <p className="text-xl font-mono font-black text-emerald-400">{stats.activeWithAi || 0}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
            <Bot className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border border-white/10 flex items-center justify-between shadow-lg">
          <div className="space-y-1">
            <p className="text-[11px] text-gray-400 font-semibold">تحتاج دعم بشري عاجل</p>
            <p className="text-xl font-mono font-black text-amber-400">
              {stats.humanSupportCount || 0}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-950/80 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <Headphones className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border border-white/10 flex items-center justify-between shadow-lg">
          <div className="space-y-1">
            <p className="text-[11px] text-gray-400 font-semibold">سرعة الاستجابة المقدرة</p>
            <p className="text-xl font-mono font-black text-[#D4AF37]">1.2 ثانية</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 flex items-center justify-center">
            <Zap className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* NAVIGATION TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-white/10 no-scrollbar">
        <button
          onClick={() => setActiveTab("inbox")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "inbox"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>صندوق المحادثات (Inbox)</span>
          {stats.unreadCount && stats.unreadCount > 0 ? (
            <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold">
              {stats.unreadCount}
            </span>
          ) : null}
        </button>

        <button
          onClick={() => setActiveTab("permissions")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "permissions"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <Lock className="w-4 h-4 text-[#D4AF37]" />
          <span>صلاحيات المراسلة والتراخيص</span>
        </button>

        <button
          onClick={() => setActiveTab("ai")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "ai"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>محرك الذكاء الاصطناعي (Gemini AI)</span>
        </button>

        <button
          onClick={() => setActiveTab("auto_replies")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "auto_replies"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <Radio className="w-4 h-4 text-emerald-400" />
          <span>الردود التلقائية والترحيب</span>
        </button>

        <button
          onClick={() => setActiveTab("analytics")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "analytics"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>الإحصائيات والتقارير</span>
        </button>

        <button
          onClick={() => setActiveTab("simulator")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "simulator"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <FlaskConical className="w-4 h-4" />
          <span>مختبر المحاكاة (Simulator)</span>
        </button>

        <button
          onClick={() => setActiveTab("diagnostics")}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
            activeTab === "diagnostics"
              ? "bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20 font-black"
              : "bg-[#141414] text-gray-400 hover:text-white hover:bg-white/5 border border-white/5"
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>تشخيص وفحص النظام</span>
        </button>
      </div>

      {/* ========================================== */}
      {/* TAB 1: 3-COLUMN MESSENGER INBOX            */}
      {/* ========================================== */}
      {activeTab === "inbox" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 h-[760px] bg-[#0E0E0E] rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
          {/* COLUMN 1: CONVERSATIONS LIST (4 cols) */}
          <div className="lg:col-span-4 border-l border-white/10 flex flex-col bg-[#121212] overflow-hidden">
            {/* Search and Filters Header */}
            <div className="p-3.5 space-y-3 border-b border-white/10 bg-[#151515]">
              <div className="relative">
                <Search className="w-4 h-4 absolute right-3 top-3 text-gray-400" />
                <input
                  type="text"
                  placeholder="بحث بالاسم، المعرّف، أو الرسالة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-3 pr-9 py-2 rounded-xl bg-[#1D1D1D] border border-white/10 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              {/* Status Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-[11px]">
                <button
                  onClick={() => setStatusFilter("all")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                    statusFilter === "all"
                      ? "bg-[#D4AF37] text-black font-black"
                      : "bg-[#1C1C1C] text-gray-400 hover:text-white"
                  }`}
                >
                  الكل ({conversations.length})
                </button>
                <button
                  onClick={() => setStatusFilter("new")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                    statusFilter === "new"
                      ? "bg-blue-600 text-white"
                      : "bg-[#1C1C1C] text-gray-400 hover:text-white"
                  }`}
                >
                  جديدة
                </button>
                <button
                  onClick={() => setStatusFilter("open")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                    statusFilter === "open"
                      ? "bg-emerald-600 text-white"
                      : "bg-[#1C1C1C] text-gray-400 hover:text-white"
                  }`}
                >
                  مفتوحة
                </button>
                <button
                  onClick={() => setStatusFilter("pending")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                    statusFilter === "pending"
                      ? "bg-amber-600 text-white"
                      : "bg-[#1C1C1C] text-gray-400 hover:text-white"
                  }`}
                >
                  تحتاج دعم
                </button>
                <button
                  onClick={() => setStatusFilter("resolved")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                    statusFilter === "resolved"
                      ? "bg-purple-600 text-white"
                      : "bg-[#1C1C1C] text-gray-400 hover:text-white"
                  }`}
                >
                  تم الحل
                </button>
              </div>

              {/* Mode Filter */}
              <div className="flex items-center justify-between text-[11px] bg-[#0A0A0A] p-1 rounded-xl border border-white/5">
                <button
                  onClick={() => setModeFilter("all")}
                  className={`flex-1 py-1 rounded-lg font-semibold transition ${
                    modeFilter === "all"
                      ? "bg-[#252525] text-white"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  الجميع
                </button>
                <button
                  onClick={() => setModeFilter("ai")}
                  className={`flex-1 py-1 rounded-lg font-semibold flex items-center justify-center gap-1 transition ${
                    modeFilter === "ai"
                      ? "bg-[#252525] text-emerald-400 font-bold"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Bot className="w-3 h-3" /> AI
                </button>
                <button
                  onClick={() => setModeFilter("human")}
                  className={`flex-1 py-1 rounded-lg font-semibold flex items-center justify-center gap-1 transition ${
                    modeFilter === "human"
                      ? "bg-[#252525] text-amber-400 font-bold"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Headphones className="w-3 h-3" /> بشري
                </button>
                <button
                  onClick={() => setModeFilter("hybrid")}
                  className={`flex-1 py-1 rounded-lg font-semibold flex items-center justify-center gap-1 transition ${
                    modeFilter === "hybrid"
                      ? "bg-[#252525] text-blue-400 font-bold"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Zap className="w-3 h-3" /> هجين
                </button>
              </div>
            </div>

            {/* Conversation Items List */}
            <div className="flex-1 overflow-y-auto divide-y divide-white/5">
              {filteredConversations.length === 0 ? (
                <div className="p-8 text-center text-gray-500 text-xs space-y-2">
                  <MessageSquare className="w-8 h-8 mx-auto opacity-30 text-gray-400" />
                  <p>لا توجد محادثات مطابقة للتصفية الحالية</p>
                </div>
              ) : (
                filteredConversations.map((conv) => {
                  const isSelected = selectedConvId === conv.id;
                  const timeFormatted = new Date(conv.lastMessageAt).toLocaleTimeString("ar-EG", {
                    hour: "2-digit",
                    minute: "2-digit",
                  });

                  return (
                    <div
                      key={conv.id}
                      onClick={() => setSelectedConvId(conv.id)}
                      className={`p-3.5 flex items-start gap-3 transition cursor-pointer hover:bg-white/[0.03] relative ${
                        isSelected ? "bg-white/[0.06] border-r-4 border-r-[#D4AF37]" : ""
                      }`}
                    >
                      {/* Avatar */}
                      <div className="relative flex-shrink-0">
                        {conv.profilePic ? (
                          <img
                            src={conv.profilePic}
                            alt={conv.senderName}
                            className="w-11 h-11 rounded-2xl object-cover border border-white/10 shadow"
                          />
                        ) : (
                          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-700 to-yellow-900 border border-white/10 flex items-center justify-center text-white font-bold text-sm shadow">
                            {conv.senderName?.charAt(0) || "ط"}
                          </div>
                        )}
                        <span className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-[#D4AF37] border-2 border-[#121212] flex items-center justify-center text-black text-[8px] font-black">
                          ✓
                        </span>
                      </div>

                      {/* Info & Last Msg */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <p className="text-xs font-bold text-white truncate">
                              {conv.senderName}
                            </p>
                            {conv.pinned && (
                              <Pin className="w-3 h-3 text-[#D4AF37] flex-shrink-0 fill-[#D4AF37]" />
                            )}
                          </div>
                          <span className="text-[10px] text-gray-500 font-mono flex-shrink-0">
                            {timeFormatted}
                          </span>
                        </div>

                        <p className="text-[11px] text-gray-400 truncate mt-1 leading-snug">
                          {conv.lastSender === "admin" && (
                            <span className="text-[#D4AF37] font-semibold">المشرف: </span>
                          )}
                          {conv.lastSender === "ai" && (
                            <span className="text-emerald-400 font-semibold">البوت: </span>
                          )}
                          {conv.lastMessageText}
                        </p>

                        {/* Badges & Mode Chips */}
                        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                          {/* Mode Badge */}
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold flex items-center gap-1 ${
                              conv.mode === "ai"
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                : conv.mode === "human"
                                ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                            }`}
                          >
                            {conv.mode === "ai" && <Bot className="w-2.5 h-2.5" />}
                            {conv.mode === "human" && <Headphones className="w-2.5 h-2.5" />}
                            {conv.mode === "hybrid" && <Zap className="w-2.5 h-2.5" />}
                            <span>
                              {conv.mode === "ai"
                                ? "AI"
                                : conv.mode === "human"
                                ? "بشري"
                                : "هجين"}
                            </span>
                          </span>

                          {/* Status Badge */}
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                              conv.status === "new"
                                ? "bg-blue-500/20 text-blue-300"
                                : conv.status === "open"
                                ? "bg-emerald-500/20 text-emerald-300"
                                : conv.status === "pending"
                                ? "bg-amber-500/20 text-amber-300"
                                : "bg-purple-500/20 text-purple-300"
                            }`}
                          >
                            {conv.status === "new"
                              ? "جديدة"
                              : conv.status === "open"
                              ? "مفتوحة"
                              : conv.status === "pending"
                              ? "دعم عاجل"
                              : "تم الحل"}
                          </span>

                          {/* Unread Badge */}
                          {conv.unreadCount && conv.unreadCount > 0 ? (
                            <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[9px] font-bold">
                              {conv.unreadCount} جديد
                            </span>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* COLUMN 2: ACTIVE CHAT VIEWPORT (5 cols) */}
          <div className="lg:col-span-5 flex flex-col bg-[#0F0F0F] overflow-hidden">
            {selectedConversation ? (
              <>
                {/* Chat Top Bar */}
                <div className="p-3.5 border-b border-white/10 bg-[#141414] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-700 to-yellow-900 border border-white/10 flex items-center justify-center text-white font-bold text-xs shadow">
                      {selectedConversation.senderName?.charAt(0) || "ط"}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xs sm:text-sm font-bold text-white">
                          {selectedConversation.senderName}
                        </h3>
                        <span
                          className={`w-2 h-2 rounded-full ${
                            selectedConversation.mode === "ai"
                              ? "bg-emerald-400"
                              : selectedConversation.mode === "human"
                              ? "bg-amber-400"
                              : "bg-blue-400"
                          }`}
                        />
                      </div>
                      <p className="text-[10px] text-gray-400 font-mono">
                        معرّف الطالب: {selectedConversation.senderId}
                      </p>
                    </div>
                  </div>

                  {/* Top Bar Actions */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        handleTogglePin(
                          selectedConversation.id,
                          selectedConversation.pinned
                        )
                      }
                      className={`p-2 rounded-lg border transition cursor-pointer ${
                        selectedConversation.pinned
                          ? "bg-[#D4AF37]/20 text-[#D4AF37] border-[#D4AF37]/40"
                          : "bg-[#1F1F1F] text-gray-400 hover:text-white border-white/5"
                      }`}
                      title={selectedConversation.pinned ? "إلغاء التثبيت" : "تثبيت المحادثة"}
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() =>
                        handleUpdateStatus(
                          selectedConversation.id,
                          selectedConversation.status === "resolved" ? "open" : "resolved"
                        )
                      }
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer flex items-center gap-1 ${
                        selectedConversation.status === "resolved"
                          ? "bg-purple-600/20 text-purple-400 border-purple-500/30"
                          : "bg-emerald-600/20 text-emerald-400 border-emerald-500/30 hover:bg-emerald-600/30"
                      }`}
                    >
                      <Check className="w-3 h-3" />
                      <span>
                        {selectedConversation.status === "resolved" ? "محلولة" : "تم الحل"}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Mode Switching Banner */}
                <div className="px-4 py-2 bg-[#121212] border-b border-white/5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1 text-gray-400">
                    <span>وضع التحكم بالمحادثة:</span>
                  </div>
                  <div className="flex items-center gap-1 bg-[#0A0A0A] p-0.5 rounded-lg border border-white/5">
                    <button
                      onClick={() => handleUpdateMode(selectedConversation.id, "ai")}
                      className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 transition ${
                        selectedConversation.mode === "ai"
                          ? "bg-emerald-600 text-white shadow"
                          : "text-gray-400 hover:text-white"
                      }`}
                    >
                      <Bot className="w-3 h-3" /> AI
                    </button>
                    <button
                      onClick={() => handleUpdateMode(selectedConversation.id, "human")}
                      className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 transition ${
                        selectedConversation.mode === "human"
                          ? "bg-amber-600 text-white shadow"
                          : "text-gray-400 hover:text-white"
                      }`}
                    >
                      <Headphones className="w-3 h-3" /> بشري
                    </button>
                    <button
                      onClick={() => handleUpdateMode(selectedConversation.id, "hybrid")}
                      className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 transition ${
                        selectedConversation.mode === "hybrid"
                          ? "bg-blue-600 text-white shadow"
                          : "text-gray-400 hover:text-white"
                      }`}
                    >
                      <Zap className="w-3 h-3" /> هجين
                    </button>
                  </div>
                </div>

                {/* Messages Stream */}
                <div ref={adminChatScrollContainerRef} className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[#0A0A0A]/40">
                  {selectedConversation.messages && selectedConversation.messages.length > 0 ? (
                    selectedConversation.messages.map((msg, index) => {
                      const isStudent = msg.role === "student";
                      const isAi = msg.role === "ai";
                      const isAdmin = msg.role === "admin";
                      const timeStr = new Date(msg.createdAt).toLocaleTimeString("ar-EG", {
                        hour: "2-digit",
                        minute: "2-digit",
                      });

                      return (
                        <div
                          key={msg.id || index}
                          className={`flex flex-col ${
                            isStudent ? "items-start" : "items-end"
                          }`}
                        >
                          <div className="flex items-center gap-1.5 mb-1 px-1">
                            <span className="text-[10px] font-bold text-gray-400">
                              {isStudent
                                ? selectedConversation.senderName
                                : isAi
                                ? "المساعد الذكي (Gemini AI)"
                                : msg.senderName || "المشرف"}
                            </span>
                            <span className="text-[9px] text-gray-500 font-mono">
                              {timeStr}
                            </span>
                          </div>

                          <div
                            className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs sm:text-sm leading-relaxed shadow-md relative ${
                              isStudent
                                ? "bg-[#1E1E1E] text-white border border-white/10 rounded-tr-none"
                                : isAi
                                ? "bg-gradient-to-r from-emerald-950/80 to-[#12241b] text-emerald-100 border border-emerald-500/30 rounded-tl-none"
                                : "bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-black font-medium border border-[#D4AF37]/50 rounded-tl-none"
                            }`}
                          >
                            <p className="whitespace-pre-wrap">{msg.text}</p>
                            {msg.attachmentUrl && (
                              <img
                                src={msg.attachmentUrl}
                                alt="Attachment"
                                className="mt-2 rounded-xl max-h-48 object-cover border border-white/10"
                              />
                            )}
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="p-8 text-center text-gray-500 text-xs">
                      لا توجد رسائل سابقة في هذه المحادثة.
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Canned Quick Replies Carousel */}
                <div className="p-2 bg-[#121212] border-t border-white/5 flex items-center gap-2 overflow-x-auto no-scrollbar">
                  <span className="text-[10px] text-gray-500 font-bold whitespace-nowrap px-1">
                    ردود سريعة:
                  </span>
                  {cannedReplies.map((cr, idx) => (
                    <button
                      key={idx}
                      onClick={() => setAdminReplyText(cr.text)}
                      className="px-2.5 py-1 rounded-lg bg-[#1A1A1A] hover:bg-[#252525] text-[11px] text-gray-300 hover:text-white border border-white/10 transition whitespace-nowrap cursor-pointer flex-shrink-0"
                    >
                      {cr.label}
                    </button>
                  ))}
                </div>

                {/* Admin Reply Input Box */}
                <div className="p-3 bg-[#141414] border-t border-white/10 flex items-center gap-2">
                  <textarea
                    rows={1}
                    placeholder="اكتب ردك المباشر للطالب هنا..."
                    value={adminReplyText}
                    onChange={(e) => setAdminReplyText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendAdminReply();
                      }
                    }}
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#1F1F1F] border border-white/10 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-[#D4AF37] resize-none"
                  />
                  <button
                    onClick={handleSendAdminReply}
                    disabled={sendingReply || !adminReplyText.trim()}
                    className="px-4 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50 shadow-md"
                  >
                    {sendingReply ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                    <span>إرسال</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-gray-500 text-xs p-8 space-y-3">
                <MessageSquare className="w-12 h-12 opacity-30 text-[#D4AF37]" />
                <p>اختر محادثة من القائمة لعرض تفاصيلها والرد المباشر</p>
              </div>
            )}
          </div>

          {/* COLUMN 3: STUDENT CRM & NOTES SIDEBAR (3 cols) */}
          <div className="lg:col-span-3 border-r border-white/10 flex flex-col bg-[#121212] overflow-y-auto p-4 space-y-5">
            {selectedConversation ? (
              <>
                {/* Student Profile Card */}
                <div className="p-3.5 rounded-2xl bg-[#171717] border border-white/10 text-center space-y-2">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-amber-700 to-yellow-900 border border-white/10 flex items-center justify-center text-white font-bold text-lg shadow-md">
                    {selectedConversation.senderName?.charAt(0) || "ط"}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {selectedConversation.senderName}
                    </h4>
                    <p className="text-[11px] text-gray-400 truncate">
                      {selectedConversation.senderEmail || "طالب مسجل بالمنصة"}
                    </p>
                  </div>
                  <div className="pt-2 border-t border-white/10 flex justify-between text-[11px] text-gray-400">
                    <span>عدد الرسائل:</span>
                    <span className="font-mono text-white font-bold">
                      {selectedConversation.messageCount || 0}
                    </span>
                  </div>
                </div>

                {/* Tags Management */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-[#D4AF37]" /> الوسوم والتصنيف
                    </span>
                    <button
                      onClick={() => setShowTagInput(!showTagInput)}
                      className="p-1 rounded bg-[#1F1F1F] hover:bg-[#2A2A2A] text-gray-300 text-[10px] flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> وسم
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {selectedConversation.tags && selectedConversation.tags.length > 0 ? (
                      selectedConversation.tags.map((t, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-lg bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 text-[10px] font-bold flex items-center gap-1"
                        >
                          <span>{t}</span>
                          <button
                            onClick={() => handleRemoveTag(selectedConversation.id, t)}
                            className="hover:text-red-400 transition"
                          >
                            ×
                          </button>
                        </span>
                      ))
                    ) : (
                      <span className="text-[11px] text-gray-500">لا توجد وسوم مضافة</span>
                    )}
                  </div>

                  {showTagInput && (
                    <div className="flex items-center gap-1.5 pt-1">
                      <input
                        type="text"
                        placeholder="أدخل وسماً جديداً..."
                        value={newTagInput}
                        onChange={(e) => setNewTagInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            handleAddTag(selectedConversation.id, newTagInput);
                          }
                        }}
                        className="flex-1 px-2.5 py-1 rounded-lg bg-[#1F1F1F] border border-white/10 text-white text-xs"
                      />
                      <button
                        onClick={() => handleAddTag(selectedConversation.id, newTagInput)}
                        className="px-2.5 py-1 rounded-lg bg-[#D4AF37] text-black font-bold text-xs"
                      >
                        إضافة
                      </button>
                    </div>
                  )}
                </div>

                {/* Internal Team CRM Notes */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-[#D4AF37]" /> ملاحظات المشرفين (خاصة)
                  </span>

                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {selectedConversation.notesList && selectedConversation.notesList.length > 0 ? (
                      selectedConversation.notesList.map((n, i) => (
                        <div
                          key={n.id || i}
                          className="p-2.5 rounded-xl bg-[#171717] border border-white/5 text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between text-[10px] text-gray-400">
                            <span className="font-bold text-[#D4AF37]">{n.authorName}</span>
                            <span className="font-mono">
                              {new Date(n.createdAt).toLocaleDateString("ar-EG")}
                            </span>
                          </div>
                          <p className="text-gray-300 text-[11px] leading-snug">{n.text}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-[11px] text-gray-500">لا توجد ملاحظات داخلية بعد.</p>
                    )}
                  </div>

                  <div className="space-y-1.5 pt-1">
                    <textarea
                      rows={2}
                      placeholder="أضف ملاحظة سرية لفريق العمل..."
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      className="w-full p-2 rounded-xl bg-[#1F1F1F] border border-white/10 text-xs text-white placeholder-gray-500 resize-none focus:outline-none focus:border-[#D4AF37]"
                    />
                    <button
                      onClick={handleAddNote}
                      disabled={addingNote || !newNoteText.trim()}
                      className="w-full py-1.5 rounded-xl bg-[#252525] hover:bg-[#303030] text-gray-200 text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>حفظ الملاحظة</span>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center text-gray-500 text-xs py-8">
                اختر محادثة لعرض بيانات الطالب والملاحظات
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* TAB: MESSAGING PERMISSIONS MANAGEMENT      */}
      {/* ========================================== */}
      {activeTab === "permissions" && (
        <AdminMessengerPermissions />
      )}

      {/* ========================================== */}
      {/* TAB 2: AI BOT ENGINE SETTINGS (GEMINI AI)  */}
      {/* ========================================== */}
      {activeTab === "ai" && (
        <div className="p-6 rounded-3xl bg-[#141414] border border-white/10 space-y-6 shadow-xl max-w-4xl">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-[#D4AF37]" />
                <span>إعدادات وتخصيص محرك الذكاء الاصطناعي (Gemini AI)</span>
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                توجيه المساعد الذكي، وضبط أسلوب الرد، والكلمات المفتاحية للتحويل التلقائي للدعم البشري
              </p>
            </div>
            {aiSettingsSavedMessage && (
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> تم الحفظ بنجاح!
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                نموذج الذكاء الاصطناعي (Gemini Model)
              </label>
              <select
                value={aiSettings.model}
                onChange={(e) => setAiSettings({ ...aiSettings, model: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="gemini-3.7-flash">Gemini 3.7 Flash (الأسرع والأحدث - موصى به)</option>
                <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (خفيف وفائق السرعة)</option>
                <option value="gemini-flash-latest">Gemini Flash Latest</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                درجة حرارة الإبداع (Temperature: {aiSettings.temperature})
              </label>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.1"
                value={aiSettings.temperature}
                onChange={(e) =>
                  setAiSettings({ ...aiSettings, temperature: parseFloat(e.target.value) })
                }
                className="w-full accent-[#D4AF37] cursor-pointer mt-3"
              />
              <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                <span>دقيق وملتزم بالحقائق (0.1)</span>
                <span>إبداعي ومسهب (1.0)</span>
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                التعليمات البرمجية وهوية المساعد (System Instruction Prompt)
              </label>
              <textarea
                rows={5}
                value={aiSettings.systemPrompt}
                onChange={(e) => setAiSettings({ ...aiSettings, systemPrompt: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-sans leading-relaxed focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1 text-xs">
                رسالة الإخفاق البديلة (Fallback Message)
              </label>
              <input
                type="text"
                value={aiSettings.fallbackMessage}
                onChange={(e) =>
                  setAiSettings({ ...aiSettings, fallbackMessage: e.target.value })
                }
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            {/* Human Handoff Keywords */}
            <div className="md:col-span-2 space-y-2 p-4 rounded-2xl bg-[#0A0A0A] border border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Headphones className="w-4 h-4 text-amber-400" /> الكلمات المفتاحية للتحويل للدعم
                  البشري (Handoff Triggers)
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="أضف كلمة..."
                    value={newHandoffKeyword}
                    onChange={(e) => setNewHandoffKeyword(e.target.value)}
                    className="px-3 py-1 rounded-lg bg-[#141414] border border-white/10 text-white text-xs"
                  />
                  <button
                    onClick={() => {
                      if (newHandoffKeyword.trim()) {
                        setAiSettings({
                          ...aiSettings,
                          handoffKeywords: [
                            ...aiSettings.handoffKeywords,
                            newHandoffKeyword.trim(),
                          ],
                        });
                        setNewHandoffKeyword("");
                      }
                    }}
                    className="px-3 py-1 rounded-lg bg-[#D4AF37] text-black font-bold text-xs"
                  >
                    إضافة
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 pt-2">
                {aiSettings.handoffKeywords.map((kw, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/20 text-xs flex items-center gap-1.5 font-mono"
                  >
                    <span>{kw}</span>
                    <button
                      onClick={() =>
                        setAiSettings({
                          ...aiSettings,
                          handoffKeywords: aiSettings.handoffKeywords.filter((_, idx) => idx !== i),
                        })
                      }
                      className="hover:text-red-400 transition cursor-pointer"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={handleSaveAiSettings}
              disabled={savingAiSettings}
              className="px-6 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs flex items-center gap-2 transition cursor-pointer shadow-lg"
            >
              {savingAiSettings ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              <span>حفظ إعدادات المساعد الذكي</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* TAB 3: AUTO REPLIES & WELCOME CONFIG       */}
      {/* ========================================== */}
      {activeTab === "auto_replies" && (
        <div className="p-6 rounded-3xl bg-[#141414] border border-white/10 space-y-6 shadow-xl max-w-4xl">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Radio className="w-5 h-5 text-emerald-400" />
                <span>الرسائل الترحيبية والردود التلقائية</span>
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                تخصيص الرسالة الترحيبية الأولى للطلاب ورسائل خارج أوقات العمل
              </p>
            </div>
            {autoRepliesSavedMsg && (
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> تم الحفظ بنجاح!
              </span>
            )}
          </div>

          <div className="space-y-4">
            {/* Welcome Message */}
            <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-xs font-bold text-white">الرسالة الترحيبية الفورية</span>
                </div>
                <input
                  type="checkbox"
                  checked={messengerSettings.autoReplies.welcomeMessageEnabled}
                  onChange={(e) =>
                    handleSaveAutoReplies({ welcomeMessageEnabled: e.target.checked })
                  }
                  className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
                />
              </div>
              <textarea
                rows={3}
                value={messengerSettings.autoReplies.welcomeMessage}
                onChange={(e) =>
                  setMessengerSettings({
                    ...messengerSettings,
                    autoReplies: {
                      ...messengerSettings.autoReplies,
                      welcomeMessage: e.target.value,
                    },
                  })
                }
                className="w-full px-3.5 py-2 rounded-xl bg-[#141414] border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            {/* Away Message */}
            <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">
                    رسالة خارج ساعات العمل الرسمية
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={messengerSettings.autoReplies.awayMessageEnabled}
                  onChange={(e) => handleSaveAutoReplies({ awayMessageEnabled: e.target.checked })}
                  className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
                />
              </div>
              <textarea
                rows={3}
                value={messengerSettings.autoReplies.awayMessage}
                onChange={(e) =>
                  setMessengerSettings({
                    ...messengerSettings,
                    autoReplies: {
                      ...messengerSettings.autoReplies,
                      awayMessage: e.target.value,
                    },
                  })
                }
                className="w-full px-3.5 py-2 rounded-xl bg-[#141414] border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={() => handleSaveAutoReplies()}
              disabled={savingAutoReplies}
              className="px-6 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs flex items-center gap-2 transition cursor-pointer shadow-lg"
            >
              {savingAutoReplies ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              <span>حفظ الردود التلقائية</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* TAB 4: ANALYTICS & REPORTS                 */}
      {/* ========================================== */}
      {activeTab === "analytics" && (
        <div className="space-y-6 max-w-4xl">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-[#141414] border border-white/10 space-y-2">
              <p className="text-xs text-gray-400 font-semibold">نسبة حل الاستفسارات تلقائياً</p>
              <p className="text-3xl font-mono font-black text-emerald-400">
                {analyticsData?.resolutionRate || 94}%
              </p>
              <p className="text-[11px] text-gray-500">تم الرد عليها وحلها بدون الحاجة لتدخل بشري</p>
            </div>

            <div className="p-5 rounded-3xl bg-[#141414] border border-white/10 space-y-2">
              <p className="text-xs text-gray-400 font-semibold">متوسط وقت الرد بالذكاء الاصطناعي</p>
              <p className="text-3xl font-mono font-black text-[#D4AF37]">1.2 ثانية</p>
              <p className="text-[11px] text-gray-500">سرعة استجابة فورية للطلاب على مدار 24 ساعة</p>
            </div>

            <div className="p-5 rounded-3xl bg-[#141414] border border-white/10 space-y-2">
              <p className="text-xs text-gray-400 font-semibold">رسائل اليوم الإجمالية</p>
              <p className="text-3xl font-mono font-black text-blue-400">
                {analyticsData?.todayMessages || 34}
              </p>
              <p className="text-[11px] text-gray-500">نشاط واستفسارات مباشرة عبر المنصة</p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* TAB 5: SIMULATOR & TESTING LAB             */}
      {/* ========================================== */}
      {activeTab === "simulator" && (
        <div className="p-6 rounded-3xl bg-[#141414] border border-white/10 space-y-5 shadow-xl max-w-3xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-[#D4AF37]" />
              <span>مختبر المحاكاة الفوري لاختبار ردود الذكاء الاصطناعي</span>
            </h3>
            <p className="text-xs text-gray-400 mt-1">
              اكتب أي رسالة كما يكتبها الطالب لاختبار سرعة وجودة الرد وفحص تصعيد الحالات الحساسة
            </p>
          </div>

          <div className="space-y-3">
            <textarea
              rows={3}
              placeholder="مثال: كم سعر كورس الويب الشامل وما هي طريقة الدفع؟ أو: عايز اكلم المشرف فوراً..."
              value={simMessage}
              onChange={(e) => setSimMessage(e.target.value)}
              className="w-full p-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
            />
            <button
              onClick={handleRunSimulator}
              disabled={simLoading || !simMessage.trim()}
              className="px-6 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
            >
              {simLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>تجربة واختبار الرد الآن</span>
            </button>
          </div>

          {simResponse && (
            <div className="p-4 rounded-2xl bg-[#0A0A0A] border border-emerald-500/30 space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> نتيجة المحاكاة:
                </span>
                <span className="text-[10px] font-mono text-gray-400">
                  Model: {simResponse.modelUsed}
                </span>
              </div>
              <p className="text-xs text-gray-200 whitespace-pre-wrap leading-relaxed bg-[#141414] p-3 rounded-xl border border-white/5">
                {simResponse.reply}
              </p>
              {simResponse.shouldHandoff && (
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>تم تفعيل شرط التحويل للدعم البشري (Handoff Trigger Active)</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================== */}
      {/* TAB 6: DIAGNOSTICS & SYSTEM HEALTH         */}
      {/* ========================================== */}
      {activeTab === "diagnostics" && (
        <div className="p-6 rounded-3xl bg-[#141414] border border-white/10 space-y-6 shadow-xl max-w-3xl">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#D4AF37]" />
                <span>تشخيص وفحص سلامة نظام المراسلة الداخلي</span>
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                فحص فوري لاتصال قاعدة البيانات، ومحرك الذكاء الاصطناعي، واستقلالية النظام
              </p>
            </div>
            <button
              onClick={handleRunDiagnostics}
              disabled={diagLoading}
              className="px-4 py-2 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-black font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${diagLoading ? "animate-spin" : ""}`} />
              <span>فحص النظام الآن</span>
            </button>
          </div>

          <div className="space-y-3">
            {diagResult ? (
              diagResult.checks.map((c, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl bg-[#0A0A0A] border border-white/10 flex items-start gap-3"
                >
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      c.status === "success"
                        ? "bg-emerald-950/80 text-emerald-400 border border-emerald-500/30"
                        : "bg-amber-950/80 text-amber-400 border border-amber-500/30"
                    }`}
                  >
                    {c.status === "success" ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <AlertTriangle className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{c.name}</h4>
                    <p className="text-[11px] text-gray-400 mt-0.5">{c.message}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-gray-500 text-xs">
                انقر على زر (فحص النظام الآن) للتحقق من جميع المكونات
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
