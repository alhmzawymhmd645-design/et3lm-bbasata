import React from "react";
import { useApp } from "../context/AppContext";
import appLogo from "../assets/images/app_logo_1787091289735.jpg";
import {
  Sparkles,
  BookOpen,
  CreditCard,
  CheckCircle2,
  PlayCircle,
  Users,
  Award,
  Zap,
  ArrowLeft,
  ArrowRight,
  ShieldAlert,
} from "lucide-react";

export const Hero: React.FC = () => {
  const { settings, setActiveView, language, setIsAuthModalOpen, user } = useApp();
  const isAr = language === "ar";

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-12 lg:pb-24">
      {/* Background Decorative Gradients */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-[#D4AF37]/5 blur-[140px] rounded-full pointer-events-none"></div>
      <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-blue-900/10 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left / Main Text Column */}
          <div className="lg:col-span-7 text-center lg:text-right space-y-6">
            {/* Top Badge with Logo */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-[#16140E] text-[#F3E5AB] text-xs rounded-full border border-[#D4AF37]/40 shadow-sm shadow-[#D4AF37]/10">
              <div className="w-5 h-5 rounded-full overflow-hidden border border-[#D4AF37]/60 flex-shrink-0">
                <img
                  src={settings.logoUrl || appLogo}
                  alt="Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="font-semibold text-[#D4AF37]">
                {isAr ? "المنصة الرسمية المعتمدة" : "Official Platform"}
              </span>
              <span className="text-gray-500">•</span>
              <span className="text-gray-300">
                {isAr
                  ? "مرحباً بك في مستقبل التعليم"
                  : "Welcome to the Future of Learning"}
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold leading-tight sm:leading-tight tracking-tight">
              {isAr ? (
                <>
                  <span className="text-white">مرحبًا بكم في </span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F59E0B] via-[#FBBF24] to-[#FDE68A] drop-shadow-[0_2px_12px_rgba(245,158,11,0.3)]">
                    اتعلم ببساطة
                  </span>{" "}
                  <span className="inline-block text-3xl sm:text-4xl lg:text-5xl align-middle">🎓✨</span>
                </>
              ) : (
                <>
                  <span className="text-white">Welcome to </span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F59E0B] via-[#FBBF24] to-[#FDE68A]">
                    Learn Simply
                  </span>{" "}
                  🎓✨
                </>
              )}
            </h1>

            {/* Description / Subtitle in Crisp Bright White */}
            <p className="text-white text-lg sm:text-xl lg:text-2xl font-bold leading-relaxed max-w-2xl mx-auto lg:mx-0">
              {isAr
                ? "منصتك الذكية للتعلم بسهولة، واكتساب المعرفة، وتحقيق التميز."
                : "Your smart platform for easy learning, gaining knowledge, and achieving excellence."}
            </p>

            {/* Etisalat Cash Highlights Banner */}
            <div className="p-4 rounded-2xl bg-[#151515] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs max-w-xl mx-auto lg:mx-0">
              <div className="flex items-center gap-3 text-gray-200">
                <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white">
                    {isAr ? "الدفع متاح عبر محفظة Etisalat Cash" : "Pay easily with Etisalat Cash"}
                  </p>
                  <p className="text-gray-400 text-[11px]">
                    {isAr ? "تحويل آمن، تفعيل سريع، وإيصال مؤكد" : "Quick review & instant course unlock"}
                  </p>
                </div>
              </div>
              <div className="bg-[#0A0A0A] px-3.5 py-1.5 rounded-xl border border-[#D4AF37]/30 font-mono text-[#D4AF37] font-bold text-xs tracking-wider">
                {settings.etisalatCashNumber}
              </div>
            </div>

            {/* Call to Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                id="hero-browse-courses-btn"
                onClick={() => setActiveView("courses")}
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 px-8 py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 text-white shadow-lg shadow-blue-600/20 transition-colors"
              >
                <span>{isAr ? "تصفح الكورسات" : "Browse Courses"}</span>
                <span className="text-lg">←</span>
              </button>

              <button
                id="hero-try-ai-btn"
                onClick={() => setActiveView("ai-assistant")}
                className="w-full sm:w-auto bg-white/5 border border-white/10 hover:bg-white/10 px-8 py-3.5 rounded-xl font-bold text-white flex items-center justify-center gap-2 transition"
              >
                <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? "مساعد الذكاء الاصطناعي" : "AI Smart Tutor"}</span>
              </button>
            </div>

            {/* Quick Guarantees */}
            <div className="grid grid-cols-3 gap-2 pt-4 border-t border-white/5 text-gray-400 text-xs sm:text-sm">
              <div className="flex items-center gap-1.5 justify-center lg:justify-start">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{isAr ? "مشاريع عملية حقيقية" : "Real Projects"}</span>
              </div>
              <div className="flex items-center gap-1.5 justify-center lg:justify-start">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{isAr ? "وصول مدى الحياة" : "Lifetime Access"}</span>
              </div>
              <div className="flex items-center gap-1.5 justify-center lg:justify-start">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] flex-shrink-0" />
                <span>{isAr ? "مساعد ذكاء اصطناعي" : "AI Powered"}</span>
              </div>
            </div>
          </div>

          {/* Right Floating Card / Visual Bento */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Visual Card */}
              <div className="rounded-2xl bg-[#151515] border border-white/10 p-6 shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-between pb-4 border-b border-white/10">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center font-bold">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        {isAr ? "تجربة تعلم تفاعلية ذكية" : "Smart Interactive Learning"}
                      </h4>
                      <p className="text-[11px] text-gray-400">
                        {isAr ? "مشغل فيديو متطور + أسئلة فورية" : "Video player & instant quiz"}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {isAr ? "مباشر ومحدث" : "Updated"}
                  </span>
                </div>

                {/* Course Sneak Peek Mockup */}
                <div className="mt-4 space-y-3">
                  <div className="relative rounded-xl overflow-hidden aspect-video bg-[#0A0A0A] border border-white/10 group">
                    <img
                      src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=700&auto=format&fit=crop&q=80"
                      alt="Course Preview"
                      className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition duration-500"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#D4AF37] to-[#B8860B] text-white flex items-center justify-center shadow-lg shadow-[#D4AF37]/40 group-hover:scale-110 transition">
                        <PlayCircle className="w-7 h-7 fill-white text-[#B8860B]" />
                      </div>
                    </div>
                    <div className="absolute bottom-2 right-2 left-2 px-2.5 py-1.5 rounded-lg bg-[#0F0F0F]/90 backdrop-blur text-[11px] text-gray-200 flex justify-between border border-white/5">
                      <span className="font-semibold">
                        {isAr ? "الدرس الأول: مقدمة وتطبيق عملي" : "Lesson 1: Introduction"}
                      </span>
                      <span className="text-[#D4AF37] font-mono font-bold">15:30</span>
                    </div>
                  </div>

                  {/* AI Assistant Chat Preview inside Hero */}
                  <div className="p-3.5 rounded-xl bg-[#1A1A1A] border border-white/5 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs text-[#D4AF37] font-bold">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{isAr ? "مساعد اتعلم ببساطة AI:" : "AI Assistant:"}</span>
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      {isAr
                        ? "«تم تلخيص المفاهيم المعقدة في 3 نقاط بسيطة مع تمرين تطبيقي عملي!»"
                        : "Concepts simplified into 3 actionable steps with real code!"}
                    </p>
                  </div>

                  {/* Stat Counters Grid */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-2">
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <p className="text-base font-bold text-[#D4AF37] font-mono">+2,500</p>
                      <p className="text-[10px] text-gray-400 font-medium">
                        {isAr ? "طالب متعلم" : "Students"}
                      </p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <p className="text-base font-bold text-emerald-400 font-mono">4.9 / 5</p>
                      <p className="text-[10px] text-gray-400 font-medium">
                        {isAr ? "تقييم الدورات" : "Rating"}
                      </p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <p className="text-base font-bold text-blue-400 font-mono">100%</p>
                      <p className="text-[10px] text-gray-400 font-medium">
                        {isAr ? "تطبيق عملي" : "Practical"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating Small Badge */}
              <div className="absolute -bottom-4 -left-4 p-3.5 rounded-2xl bg-[#1A1A1A] border border-white/10 shadow-xl flex items-center gap-3 hidden sm:flex">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">
                    {isAr ? "شهادة إتمام معتمدة" : "Course Certificate"}
                  </p>
                  <p className="text-[10px] text-gray-400">
                    {isAr ? "لكل كورس تنهيه بنجاح" : "Upon full completion"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
