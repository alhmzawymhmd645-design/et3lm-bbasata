export type UserRole = 'student' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  phone?: string;
  createdAt: string;
  updatedAt?: string;
}

export type CourseLevel = string;

export interface CourseCategory {
  id: string;
  name: string; // e.g. "طلاب", "ثانوي", "كيمياء", "برمجة الويب"
  nameEn?: string; // e.g. "Students", "Secondary", "Chemistry", "Web Development"
  description?: string;
  icon?: string; // e.g. "Globe", "Bot", "Terminal", "Palette", "Shield", "Database", "Smartphone", "Cpu", "Layers", "BookOpen", "GraduationCap", "Flame", "Atom", "Calculator"
  active: boolean;
  order: number;
  parentId?: string | null; // null or undefined for Root/Main categories, parent category id for subcategories and subjects
  depth?: number; // 0 for Main, 1 for Subcategory, 2 for Subject/Level
  color?: string; // Optional accent color code/class
  createdAt: string;
  updatedAt?: string;
}

export interface HierarchicalCategoryNode extends CourseCategory {
  children?: HierarchicalCategoryNode[];
  courseCount?: number;
  path?: string[];
}

export interface CourseLevelItem {
  id: string;
  name: string; // e.g. "مبتدئ", "متوسط", "متقدم"
  nameEn?: string; // e.g. "Beginner", "Intermediate", "Advanced"
  description?: string;
  active: boolean;
  order: number;
  createdAt: string;
  updatedAt?: string;
}

export interface Course {
  id: string;
  title: string;
  titleEn?: string;
  description: string;
  descriptionEn?: string;
  thumbnail: string;
  price: number; // in EGP (جنيه مصري)
  originalPrice?: number;
  level: CourseLevel;
  levelId?: string;
  category: string; // Name of the primary/leaf or main category (backward compatible)
  categoryId?: string; // ID of the assigned category in the hierarchy
  categoryIds?: string[]; // Array of category IDs in the branch (e.g. [mainId, subId, subjectId])
  categoryPath?: string[]; // Array of category names (e.g. ["طلاب", "ثانوي", "كيمياء"])
  subCategory?: string; // Optional direct subcategory name
  duration: string; // e.g. "12 ساعة"
  lessonCount: number;
  published: boolean;
  featured?: boolean;
  rating?: number;
  studentsCount?: number;
  requirements?: string[];
  whatYouWillLearn?: string[];
  createdAt: string;
  updatedAt?: string;
}

export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  titleEn?: string;
  description: string;
  videoUrl: string; // YouTube embed, Vimeo, or direct MP4 URL
  duration: string; // e.g. "15:30"
  order: number;
  isFreePreview: boolean;
  published: boolean;
  homeworkFileUrl?: string;
  homeworkFileName?: string;
  interactiveBoardUrl?: string; // e.g. whiteboard or interactive tool
  lessonImages?: string[];
  attachments?: {
    title: string;
    url: string;
  }[];
  createdAt: string;
  updatedAt?: string;
}

export type PaymentStatus = 'pending' | 'approved' | 'rejected';

export interface PaymentRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  userPhone?: string;
  courseId: string;
  courseTitle: string;
  amount: number; // in EGP
  senderPhone: string; // student's Etisalat Cash number
  walletNumber: string; // platform's Etisalat Cash wallet paid to
  receiptUrl: string; // image base64 data url or storage url
  status: PaymentStatus;
  adminNotes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Enrollment {
  id: string; // e.g. `${userId}_${courseId}`
  userId: string;
  userEmail: string;
  courseId: string;
  courseTitle: string;
  paymentId: string;
  enrolledAt: string;
  progress: number; // 0 to 100
  completedLessons: string[]; // lesson ids
  lastAccessedLessonId?: string;
  lastAccessedAt?: string;
}

export interface PlatformSettings {
  platformName: string;
  platformNameEn: string;
  logoUrl?: string;
  etisalatCashNumber: string; // Live editable wallet number
  description: string;
  descriptionEn?: string;
  contactEmail: string;
  contactPhone?: string;
  primaryColor?: string;
  announcement?: string;
  aiAutoReplyEnabled?: boolean; // Toggle for AI automated support replies
  platformBackground?: string; // Platform background image URL
  mainBackgroundUrl?: string;
  mainBackgroundPreset?: "default" | "neural_grid" | "deep_space" | "warm_gold" | "cyber_slate";
  walletBackgroundUrl?: string;
  walletTheme?: "gold" | "emerald" | "carbon" | "sapphire" | "gold_luxury" | "emerald_modern" | "dark_carbon";
  updatedAt?: string;
}

export type TicketCategory =
  | "payment" // الدفع والاشتراكات ومحفظة اتصالات كاش
  | "courses" // الكورسات والمحتوى والمشاهدة
  | "account" // الحساب وتسجيل الدخول
  | "technical" // مشاكل تقنية ومشغل الفيديو
  | "general"; // استفسارات عامة

export type TicketStatus =
  | "open" // تذكرة مفتوحة
  | "needs_admin" // تحتاج تدخل فريق الدعم
  | "in_progress" // قيد المتابعة
  | "resolved" // تم حل المشكلة
  | "closed"; // مغلقة

export interface SupportMessage {
  id: string;
  sender: "student" | "ai" | "admin";
  senderName: string;
  text: string;
  attachmentUrl?: string;
  createdAt: string;
  isEscalationTrigger?: boolean;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone?: string;
  category: TicketCategory;
  subject: string;
  status: TicketStatus;
  priority?: "normal" | "urgent";
  attachmentUrl?: string;
  messages: SupportMessage[];
  createdAt: string;
  updatedAt: string;
  lastMessageText: string;
  lastSender: "student" | "ai" | "admin";
  aiHandled: boolean;
  needsAdminAttention: boolean;
  adminNotes?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  comment: string;
  rating: number;
  avatar: string;
  courseTitle: string;
  createdAt: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export type MessengerMode = 'ai' | 'human' | 'hybrid' | 'direct';
export type MessengerConversationStatus = 'new' | 'open' | 'pending' | 'resolved' | 'archived';

export interface MessengerUserSummary {
  uid: string;
  displayName: string;
  email?: string;
  role: 'student' | 'admin' | 'instructor' | 'support';
  photoURL?: string;
  phone?: string;
  isOnline?: boolean;
  lastSeen?: string;
}

export interface MessengerNote {
  id: string;
  authorName: string;
  text: string;
  createdAt: string;
}

export interface MessengerConversation {
  id: string;
  senderId: string;
  senderName?: string;
  senderEmail?: string;
  profilePic?: string;
  mode: MessengerMode;
  status: MessengerConversationStatus;
  pinned?: boolean;
  tags?: string[];
  unreadCount?: number;
  createdAt: string;
  updatedAt: string;
  lastMessageAt: string;
  lastMessageText: string;
  lastSender: 'student' | 'ai' | 'admin';
  messageCount: number;
  ticketId?: string;
  notes?: string;
  notesList?: MessengerNote[];
  assignedAdmin?: string;
  studentPhone?: string;
  enrolledCourseId?: string;
  userRole?: 'student' | 'instructor' | 'admin' | 'visitor';
  participantIds?: string[];
  participants?: Record<string, MessengerUserSummary>;
  unreadCounts?: Record<string, number>;
}

export interface MessengerMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName?: string;
  senderPhotoURL?: string;
  role: 'student' | 'ai' | 'admin' | 'instructor';
  source: 'internal_chat' | 'ai' | 'admin' | 'messenger';
  text: string;
  createdAt: string;
  attachmentUrl?: string;
  attachmentType?: 'image' | 'file';
  isEcho?: boolean;
  status?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed' | 'pending';
  readBy?: string[];
}

export interface MessengerAiSettings {
  enabled: boolean;
  model: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  fallbackMessage: string;
  humanHandoffEnabled: boolean;
  handoffKeywords: string[];
}

export interface InternalSystemDiagnosticResult {
  success: boolean;
  timestamp: string;
  checks: {
    name: string;
    status: 'success' | 'failed' | 'warning' | 'pending';
    message: string;
    details?: string;
  }[];
  error?: string;
}

// Backward compatibility alias
export type MetaConnectionTestResult = InternalSystemDiagnosticResult;

export interface MessengerAutoReplySettings {
  autoReplyEnabled: boolean;
  welcomeMessage: string;
  welcomeMessageEnabled: boolean;
  awayMessage: string;
  awayMessageEnabled: boolean;
  aiEducationalEnabled: boolean;
  businessHoursStart?: string;
  businessHoursEnd?: string;
}

export interface MessengerSettingsConfig {
  systemName: string;
  connectionStatus: 'connected' | 'disconnected' | 'needs_setup';
  connectionStatusAr: 'متصل' | 'غير متصل' | 'يحتاج إلى إعداد';
  lastConnectionAt: string | null;
  autoReplies: MessengerAutoReplySettings;
}

export interface MessengerBotStats {
  totalConversations: number;
  totalMessages: number;
  activeWithAi: number;
  humanSupportCount: number;
  hybridCount?: number;
  todayMessagesCount?: number;
  unreadCount?: number;
  isBotGloballyEnabled: boolean;
  webhookConfigured?: boolean;
  geminiConfigured?: boolean;
  avgResponseTimeSec?: number;
  connectionStatus?: 'connected' | 'disconnected' | 'needs_setup';
  connectionStatusAr?: string;
  lastConnectionAt?: string | null;
}

export interface MessengerPermissionsConfig {
  globalMessengerEnabled: boolean;
  studentToStudentEnabled: boolean;
  studentToAdminEnabled: boolean;
  studentToInstructorEnabled: boolean;
  instructorToStudentEnabled: boolean;
  instructorToInstructorEnabled: boolean;
  adminToAllEnabled: boolean;
  updatedAt?: string;
}

export interface UserMessengerPermissions {
  userId: string;
  messengerAccess: boolean; // Enabled / Disabled
  canSend: boolean;
  canReceive: boolean;
  allowedUserIds?: string[];
  blockedUserIds?: string[];
  customNote?: string;
  updatedAt?: string;
}

export interface MessengerUserSummary {
  uid: string;
  id?: string;
  displayName: string;
  email?: string;
  role: "student" | "admin" | "instructor" | "support";
  photoURL?: string;
  phone?: string;
  isOnline?: boolean;
  lastSeen?: string;
}



