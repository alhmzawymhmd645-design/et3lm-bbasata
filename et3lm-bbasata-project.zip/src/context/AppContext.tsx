import React, { createContext, useContext, useState, useEffect } from "react";
import {
  auth,
  db,
  googleProvider,
  syncUserProfile,
  SUPER_ADMIN_EMAIL,
  isSuperAdminEmail,
  handleFirestoreError,
  OperationType,
  testConnection,
} from "../lib/firebase";
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from "firebase/auth";
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  onSnapshot,
  query,
  where,
  orderBy,
  deleteDoc,
  getDocs,
} from "firebase/firestore";
import {
  UserProfile,
  Course,
  Lesson,
  PaymentRequest,
  Enrollment,
  PlatformSettings,
  Testimonial,
  SupportTicket,
  SupportMessage,
  TicketCategory,
  TicketStatus,
  CourseCategory,
  CourseLevelItem,
} from "../types";
import {
  DEFAULT_SETTINGS,
  INITIAL_CATEGORIES,
  INITIAL_LEVELS,
  initializePlatformData,
} from "../lib/seedData";
import confetti from "canvas-confetti";

interface AppContextType {
  user: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  authLoading: boolean;
  isAdmin: boolean;
  settings: PlatformSettings;
  updateSettings: (newSettings: Partial<PlatformSettings>) => Promise<void>;
  courses: Course[];
  categories: CourseCategory[];
  levels: CourseLevelItem[];
  addCategory: (cat: Omit<CourseCategory, "id" | "createdAt">) => Promise<string>;
  updateCategory: (
    id: string,
    data: Partial<CourseCategory>,
    oldName?: string
  ) => Promise<void>;
  deleteCategory: (
    id: string,
    replacementCategoryName?: string
  ) => Promise<void>;
  toggleCategoryActive: (id: string, active: boolean) => Promise<void>;
  reorderCategories: (orderedIds: string[]) => Promise<void>;
  seedDefaultCategories: () => Promise<void>;
  addLevel: (lvl: Omit<CourseLevelItem, "id" | "createdAt">) => Promise<string>;
  updateLevel: (
    id: string,
    data: Partial<CourseLevelItem>,
    oldName?: string
  ) => Promise<void>;
  deleteLevel: (
    id: string,
    replacementLevelName?: string
  ) => Promise<void>;
  toggleLevelActive: (id: string, active: boolean) => Promise<void>;
  reorderLevels: (orderedIds: string[]) => Promise<void>;
  testimonials: Testimonial[];
  enrollments: Enrollment[];
  myPayments: PaymentRequest[];
  allPayments: PaymentRequest[];
  allStudents: UserProfile[];
  myTickets: SupportTicket[];
  allTickets: SupportTicket[];
  isSupportModalOpen: boolean;
  setIsSupportModalOpen: (open: boolean) => void;
  selectedTicket: SupportTicket | null;
  setSelectedTicket: (ticket: SupportTicket | null) => void;
  createSupportTicket: (
    category: TicketCategory,
    subject: string,
    initialMessage: string,
    attachmentUrl?: string,
    courseId?: string,
    courseTitle?: string
  ) => Promise<string>;
  sendTicketMessage: (
    ticketId: string,
    messageText: string,
    attachmentUrl?: string
  ) => Promise<void>;
  adminReplyToTicket: (
    ticketId: string,
    replyText: string,
    newStatus?: TicketStatus
  ) => Promise<void>;
  updateTicketStatus: (
    ticketId: string,
    status: TicketStatus,
    adminNotes?: string
  ) => Promise<void>;
  closeTicket: (ticketId: string) => Promise<void>;
  toggleAiAutoReply: (enabled: boolean) => Promise<void>;
  language: "ar" | "en";
  setLanguage: (lang: "ar" | "en") => void;
  activeView:
    | "home"
    | "courses"
    | "course-details"
    | "player"
    | "student-dashboard"
    | "admin-dashboard"
    | "ai-assistant"
    | "support"
    | "messenger";
  setActiveView: (
    view:
      | "home"
      | "courses"
      | "course-details"
      | "player"
      | "student-dashboard"
      | "admin-dashboard"
      | "ai-assistant"
      | "support"
      | "messenger"
  ) => void;
  unreadMessengerCount: number;
  setUnreadMessengerCount: (count: number) => void;
  activeMessengerTargetUser: { uid: string; displayName: string; role?: string; photoURL?: string; email?: string } | null;
  setActiveMessengerTargetUser: (user: { uid: string; displayName: string; role?: string; photoURL?: string; email?: string } | null) => void;
  startDirectChat: (targetUser: { uid: string; displayName: string; role?: string; photoURL?: string; email?: string }) => void;
  selectedCourse: Course | null;
  setSelectedCourse: (course: Course | null) => void;
  selectedLesson: Lesson | null;
  setSelectedLesson: (lesson: Lesson | null) => void;
  isEtisalatModalOpen: boolean;
  setIsEtisalatModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: "login" | "register";
  setAuthModalMode: (mode: "login" | "register") => void;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (
    email: string,
    pass: string,
    name: string,
    phone?: string
  ) => Promise<void>;
  logout: () => Promise<void>;
  submitEtisalatPayment: (
    course: Course,
    senderPhone: string,
    receiptBase64: string
  ) => Promise<string>;
  approvePayment: (payment: PaymentRequest) => Promise<void>;
  rejectPayment: (paymentId: string, notes?: string) => Promise<void>;
  markLessonCompleted: (courseId: string, lessonId: string) => Promise<void>;
  deleteCourse: (courseId: string) => Promise<void>;
  isEnrolledInCourse: (courseId: string) => boolean;
  refreshData: () => Promise<void>;
  demoLoginAsAdmin: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [settings, setSettings] = useState<PlatformSettings>(DEFAULT_SETTINGS);
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<CourseCategory[]>(INITIAL_CATEGORIES);
  const [levels, setLevels] = useState<CourseLevelItem[]>(INITIAL_LEVELS);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [myPayments, setMyPayments] = useState<PaymentRequest[]>([]);
  const [allPayments, setAllPayments] = useState<PaymentRequest[]>([]);
  const [allStudents, setAllStudents] = useState<UserProfile[]>([]);
  const [myTickets, setMyTickets] = useState<SupportTicket[]>([]);
  const [allTickets, setAllTickets] = useState<SupportTicket[]>([]);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);

  const [language, setLanguage] = useState<"ar" | "en">("ar");
  const [activeView, setActiveView] = useState<
    | "home"
    | "courses"
    | "course-details"
    | "player"
    | "student-dashboard"
    | "admin-dashboard"
    | "ai-assistant"
    | "support"
    | "messenger"
  >("home");
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [isEtisalatModalOpen, setIsEtisalatModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<"login" | "register">(
    "login"
  );

  const [unreadMessengerCount, setUnreadMessengerCount] = useState<number>(0);
  const [activeMessengerTargetUser, setActiveMessengerTargetUser] = useState<{
    uid: string;
    displayName: string;
    role?: string;
    photoURL?: string;
    email?: string;
  } | null>(null);

  const startDirectChat = (targetUser: {
    uid: string;
    displayName: string;
    role?: string;
    photoURL?: string;
    email?: string;
  }) => {
    setActiveMessengerTargetUser(targetUser);
    setActiveView("messenger");
  };

  // Poll for messenger unread notifications periodically
  useEffect(() => {
    if (!user) {
      setUnreadMessengerCount(0);
      return;
    }

    const checkUnread = async () => {
      try {
        const res = await fetch(`/api/messenger/unread-total?userId=${encodeURIComponent(user.uid)}`);
        if (res.ok) {
          const data = await res.json();
          if (typeof data.unreadCount === "number") {
            setUnreadMessengerCount(data.unreadCount);
          }
        }
      } catch {
        // quiet fallback
      }
    };

    checkUnread();
    const timer = setInterval(checkUnread, 6000);
    return () => clearInterval(timer);
  }, [user]);

  const isAdmin =
    user?.role === "admin" ||
    isSuperAdminEmail(user?.email) ||
    isSuperAdminEmail(firebaseUser?.email);

  // Initialize DB and test connection
  useEffect(() => {
    async function init() {
      await testConnection();
      await initializePlatformData();
    }
    init();
  }, []);

  // Listen to platform settings
  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, "settings", "general"),
      (snap) => {
        if (snap.exists()) {
          setSettings(snap.data() as PlatformSettings);
        }
      },
      (error) => {
        console.error("Settings listener error:", error);
      }
    );
    return () => unsub();
  }, []);

  // Listen to Courses
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, "courses"),
      (snap) => {
        const list: Course[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as Course);
        });
        setCourses(list);
      },
      (error) => {
        console.error("Courses listener error:", error);
      }
    );
    return () => unsub();
  }, []);

  // Listen to Categories
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, "categories"),
      (snap) => {
        if (!snap.empty) {
          const list: CourseCategory[] = [];
          snap.forEach((d) => {
            list.push({ ...d.data(), id: d.id } as CourseCategory);
          });
          list.sort((a, b) => (a.order || 0) - (b.order || 0));
          setCategories(list);
        } else {
          setCategories(INITIAL_CATEGORIES);
        }
      },
      (error) => {
        console.error("Categories listener error:", error);
      }
    );
    return () => unsub();
  }, []);

  // Listen to Course Levels
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, "course_levels"),
      (snap) => {
        if (!snap.empty) {
          const list: CourseLevelItem[] = [];
          snap.forEach((d) => {
            list.push({ ...d.data(), id: d.id } as CourseLevelItem);
          });
          list.sort((a, b) => (a.order || 0) - (b.order || 0));
          setLevels(list);
        } else {
          setLevels(INITIAL_LEVELS);
        }
      },
      (error) => {
        console.error("Course levels listener error:", error);
      }
    );
    return () => unsub();
  }, []);

  // Listen to Testimonials
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, "testimonials"),
      (snap) => {
        const list: Testimonial[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as Testimonial);
        });
        setTestimonials(list);
      },
      (error) => {
        console.error("Testimonials listener error:", error);
      }
    );
    return () => unsub();
  }, []);

  // Auth State Listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fUser) => {
      setFirebaseUser(fUser);
      if (fUser) {
        try {
          const profile = await syncUserProfile(fUser);
          setUser(profile);
        } catch (err) {
          console.error("Failed to sync profile:", err);
        }
      } else {
        setUser(null);
      }
      setAuthLoading(false);
    });
    return () => unsub();
  }, []);

  // Listen to User Enrollments and Payments
  useEffect(() => {
    if (!user) {
      setEnrollments([]);
      setMyPayments([]);
      return;
    }

    // Enrollments
    const qEnroll = query(
      collection(db, "enrollments"),
      where("userId", "==", user.uid)
    );
    const unsubEnroll = onSnapshot(
      qEnroll,
      (snap) => {
        const list: Enrollment[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as Enrollment);
        });
        setEnrollments(list);
      },
      (error) => {
        console.error("Enrollments listener error:", error);
      }
    );

    // Payments for current student
    const qPay = query(
      collection(db, "payments"),
      where("userId", "==", user.uid)
    );
    const unsubPay = onSnapshot(
      qPay,
      (snap) => {
        const list: PaymentRequest[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as PaymentRequest);
        });
        // Sort descending by createdAt
        list.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setMyPayments(list);
      },
      (error) => {
        console.error("Payments listener error:", error);
      }
    );

    // Support tickets for current student
    const qTickets = query(
      collection(db, "support_tickets"),
      where("userId", "==", user.uid)
    );
    const unsubTickets = onSnapshot(
      qTickets,
      (snap) => {
        const list: SupportTicket[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as SupportTicket);
        });
        list.sort(
          (a, b) =>
            new Date(b.updatedAt || b.createdAt).getTime() -
            new Date(a.updatedAt || a.createdAt).getTime()
        );
        setMyTickets(list);
      },
      (error) => {
        console.error("Student tickets listener error:", error);
      }
    );

    return () => {
      unsubEnroll();
      unsubPay();
      unsubTickets();
    };
  }, [user]);

  // Admin: Listen to all payments, students, and support tickets
  useEffect(() => {
    if (!isAdmin) {
      setAllPayments([]);
      setAllStudents([]);
      setAllTickets([]);
      return;
    }

    // All payments
    const unsubAllPay = onSnapshot(
      collection(db, "payments"),
      (snap) => {
        const list: PaymentRequest[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as PaymentRequest);
        });
        list.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setAllPayments(list);
      },
      (error) => {
        console.error("Admin payments listener error:", error);
      }
    );

    // All students
    const unsubUsers = onSnapshot(
      collection(db, "users"),
      (snap) => {
        const list: UserProfile[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), uid: d.id } as UserProfile);
        });
        setAllStudents(list);
      },
      (error) => {
        console.error("Admin students listener error:", error);
      }
    );

    // All support tickets
    const unsubAllTickets = onSnapshot(
      collection(db, "support_tickets"),
      (snap) => {
        const list: SupportTicket[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as SupportTicket);
        });
        list.sort(
          (a, b) =>
            new Date(b.updatedAt || b.createdAt).getTime() -
            new Date(a.updatedAt || a.createdAt).getTime()
        );
        setAllTickets(list);
      },
      (error) => {
        console.error("Admin tickets listener error:", error);
      }
    );

    return () => {
      unsubAllPay();
      unsubUsers();
      unsubAllTickets();
    };
  }, [isAdmin]);

  // Auth Methods
  const loginWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      const profile = await syncUserProfile(res.user);
      setUser(profile);
      setFirebaseUser(res.user);
      setIsAuthModalOpen(false);
      const isUserAdmin = profile.role === "admin" || isSuperAdminEmail(profile.email);
      setActiveView(isUserAdmin ? "admin-dashboard" : "student-dashboard");
    } catch (err: any) {
      console.error("Google sign in error:", err);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      const res = await signInWithEmailAndPassword(auth, email.trim(), pass);
      const profile = await syncUserProfile(res.user);
      setUser(profile);
      setFirebaseUser(res.user);
      setIsAuthModalOpen(false);
      const isUserAdmin = profile.role === "admin" || isSuperAdminEmail(profile.email);
      setActiveView(isUserAdmin ? "admin-dashboard" : "student-dashboard");
    } catch (err: any) {
      console.error("Email sign in error:", err);
      throw err;
    }
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    name: string,
    phone?: string
  ) => {
    try {
      const cleanEmail = email.trim();
      const cleanName = name.trim();
      const cleanPhone = phone?.trim() || "";
      const res = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
      
      try {
        await updateProfile(res.user, { displayName: cleanName });
      } catch (profErr) {
        console.warn("Could not update auth display name:", profErr);
      }

      const isAdminEmail = isSuperAdminEmail(cleanEmail);
      const profile = await syncUserProfile(res.user, {
        displayName: cleanName,
        phone: cleanPhone,
        role: isAdminEmail ? "admin" : "student",
      });

      setUser(profile);
      setFirebaseUser(res.user);
      setIsAuthModalOpen(false);
      setActiveView(isAdminEmail ? "admin-dashboard" : "student-dashboard");
    } catch (err: any) {
      console.error("Registration error:", err);
      throw err;
    }
  };

  const logout = async () => {
    await signOut(auth);
    setUser(null);
    setFirebaseUser(null);
    setActiveView("home");
  };

  const demoLoginAsAdmin = () => {
    const demoAdmin: UserProfile = {
      uid: "admin-master-user",
      email: SUPER_ADMIN_EMAIL,
      displayName: "الأستاذ المشرف (Admin)",
      role: "admin",
      phone: "01157783934",
      createdAt: new Date().toISOString(),
    };
    setUser(demoAdmin);
    setActiveView("admin-dashboard");
  };

  // Submit Etisalat Cash Payment
  const submitEtisalatPayment = async (
    course: Course,
    senderPhone: string,
    receiptBase64: string
  ): Promise<string> => {
    if (!user) throw new Error("يجب تسجيل الدخول أولاً لإتمام طلب الاشتراك");

    const paymentId = `pay_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    const paymentRecord: PaymentRequest = {
      id: paymentId,
      userId: user.uid,
      userEmail: user.email,
      userName: user.displayName || "طالب",
      userPhone: user.phone || senderPhone,
      courseId: course.id,
      courseTitle: course.title,
      amount: course.price,
      senderPhone: senderPhone.trim(),
      walletNumber: settings.etisalatCashNumber || "01157783934",
      receiptUrl: receiptBase64,
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    const payRef = doc(db, "payments", paymentId);
    await setDoc(payRef, paymentRecord);
    return paymentId;
  };

  // Admin: Approve Payment
  const approvePayment = async (payment: PaymentRequest) => {
    if (!isAdmin) throw new Error("غير مصرح لك بتنفيذ هذه العملية الإدارية");

    // 1. Update Payment status to 'approved'
    const payRef = doc(db, "payments", payment.id);
    await updateDoc(payRef, {
      status: "approved",
      updatedAt: new Date().toISOString(),
    });

    // 2. Create or update Enrollment for student
    const enrollmentId = `${payment.userId}_${payment.courseId}`;
    const enrollRef = doc(db, "enrollments", enrollmentId);
    const existingSnap = await getDoc(enrollRef);

    if (!existingSnap.exists()) {
      const newEnrollment: Enrollment = {
        id: enrollmentId,
        userId: payment.userId,
        userEmail: payment.userEmail,
        courseId: payment.courseId,
        courseTitle: payment.courseTitle,
        paymentId: payment.id,
        enrolledAt: new Date().toISOString(),
        progress: 0,
        completedLessons: [],
      };
      await setDoc(enrollRef, newEnrollment);
    }

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#F59E0B", "#10B981", "#3B82F6"],
      });
    } catch {
      // ignore
    }
  };

  // Admin: Reject Payment
  const rejectPayment = async (paymentId: string, notes?: string) => {
    if (!isAdmin) throw new Error("غير مصرح لك بتنفيذ هذه العملية الإدارية");
    const payRef = doc(db, "payments", paymentId);
    await updateDoc(payRef, {
      status: "rejected",
      adminNotes: notes || "تم رفض الطلب، يرجى مراجعة إيصال التحويل ورقم المحفظة.",
      updatedAt: new Date().toISOString(),
    });
  };

  // Student: Mark Lesson as completed
  const markLessonCompleted = async (courseId: string, lessonId: string) => {
    if (!user) return;
    const enrollmentId = `${user.uid}_${courseId}`;
    const enrollRef = doc(db, "enrollments", enrollmentId);
    const enrollSnap = await getDoc(enrollRef);

    if (enrollSnap.exists()) {
      const data = enrollSnap.data() as Enrollment;
      const completed = new Set(data.completedLessons || []);
      completed.add(lessonId);
      const completedArray = Array.from(completed);

      // Find total lessons in this course
      const courseObj = courses.find((c) => c.id === courseId);
      const totalLessons = courseObj?.lessonCount || Math.max(1, completedArray.length);
      const progressPercent = Math.min(
        100,
        Math.round((completedArray.length / totalLessons) * 100)
      );

      await updateDoc(enrollRef, {
        completedLessons: completedArray,
        progress: progressPercent,
        lastAccessedLessonId: lessonId,
        lastAccessedAt: new Date().toISOString(),
      });

      if (progressPercent === 100) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
          colors: ["#F59E0B", "#FBBF24", "#38BDF8"],
        });
      }
    }
  };

  // Delete Course (Admins only) with cascading lessons cleanup
  const deleteCourse = async (courseId: string): Promise<void> => {
    if (!isAdmin) {
      throw new Error("غير مصرح لك بتنفيذ هذه العملية الإدارية. مطلوب صلاحيات المشرف.");
    }
    if (!courseId || typeof courseId !== "string") {
      throw new Error("معرّف الكورس غير صالح");
    }

    try {
      // 1. Delete associated lessons for this course from 'lessons' collection
      try {
        const lessonsQuery = query(
          collection(db, "lessons"),
          where("courseId", "==", courseId)
        );
        const lessonsSnap = await getDocs(lessonsQuery);
        const deletePromises = lessonsSnap.docs.map((lessonDoc) =>
          deleteDoc(doc(db, "lessons", lessonDoc.id))
        );
        await Promise.all(deletePromises);
      } catch (lessonErr) {
        console.warn("Could not delete associated lessons:", lessonErr);
      }

      // 2. Delete the course document from 'courses' collection
      const courseDocRef = doc(db, "courses", courseId);
      await deleteDoc(courseDocRef);

      // 3. Immediately update local courses state (optimistic update + onSnapshot sync)
      setCourses((prev) => prev.filter((c) => c.id !== courseId));
    } catch (error) {
      console.error("Firestore Delete Course Error:", error);
      throw error;
    }
  };

  // Check if enrolled
  const isEnrolledInCourse = (courseId: string): boolean => {
    if (isAdmin) return true; // Admins have master access
    return enrollments.some((e) => e.courseId === courseId);
  };

  // Update Settings
  const updateSettings = async (newSettings: Partial<PlatformSettings>) => {
    if (!isAdmin) throw new Error("غير مصرح بتعديل الإعدادات. تقتصر هذه الصلاحية على مدير المنصة فقط.");
    const ref = doc(db, "settings", "general");

    // Synchronize platform background and main background url
    const resolvedBg =
      newSettings.platformBackground !== undefined
        ? newSettings.platformBackground
        : newSettings.mainBackgroundUrl !== undefined
        ? newSettings.mainBackgroundUrl
        : settings.platformBackground || settings.mainBackgroundUrl || "";

    const resolvedPreset =
      newSettings.mainBackgroundPreset !== undefined
        ? newSettings.mainBackgroundPreset
        : settings.mainBackgroundPreset || "default";

    const resolvedWalletBg =
      newSettings.walletBackgroundUrl !== undefined
        ? newSettings.walletBackgroundUrl
        : settings.walletBackgroundUrl || "";

    const resolvedWalletTheme =
      newSettings.walletTheme !== undefined
        ? newSettings.walletTheme
        : settings.walletTheme || "gold";

    const updated: PlatformSettings = {
      ...settings,
      ...newSettings,
      platformBackground: resolvedBg,
      mainBackgroundUrl: resolvedBg,
      mainBackgroundPreset: resolvedPreset as any,
      walletBackgroundUrl: resolvedWalletBg,
      walletTheme: resolvedWalletTheme as any,
      updatedAt: new Date().toISOString(),
    };

    // Clean all undefined values to ensure Firestore setDoc never rejects the payload
    const sanitized: Record<string, any> = {};
    for (const [key, value] of Object.entries(updated)) {
      if (value !== undefined) {
        sanitized[key] = value;
      }
    }

    try {
      await setDoc(ref, sanitized, { merge: true });
      setSettings(updated);
    } catch (err: any) {
      console.error("Firestore updateSettings error:", err);
      throw handleFirestoreError(err, OperationType.WRITE, "settings/general");
    }
  };

  // Support System Methods
  const createSupportTicket = async (
    category: TicketCategory,
    subject: string,
    initialMessage: string,
    attachmentUrl?: string,
    courseId?: string,
    courseTitle?: string
  ): Promise<string> => {
    if (!user) throw new Error("يجب تسجيل الدخول لإنشاء تذكرة دعم فني");

    const ticketId = `ticket_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    // Create initial student message cleanly without undefined properties
    const studentMsg: SupportMessage = {
      id: `msg_${Date.now()}_1`,
      sender: "student",
      senderName: user.displayName || user.email || "الطالب",
      text: initialMessage.trim(),
      createdAt: new Date().toISOString(),
      ...(attachmentUrl ? { attachmentUrl } : {}),
    };

    // Create ticket record cleanly without undefined properties
    const newTicket: SupportTicket = {
      id: ticketId,
      userId: user.uid,
      userName: user.displayName || user.email || "الطالب",
      userEmail: user.email,
      userPhone: user.phone || "",
      category,
      subject: subject.trim(),
      status: "open",
      messages: [studentMsg],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastMessageText: initialMessage.trim() || (attachmentUrl ? "مرفق صورة" : ""),
      lastSender: "student",
      aiHandled: false,
      needsAdminAttention: false,
      priority: "normal",
      ...(attachmentUrl ? { attachmentUrl } : {}),
      ...(courseId ? { courseId } : {}),
      ...(courseTitle ? { courseTitle } : {}),
    };

    const ticketRef = doc(db, "support_tickets", ticketId);
    await setDoc(ticketRef, newTicket);

    // Optimistically update local tickets
    setMyTickets((prev) => {
      const exists = prev.some((t) => t.id === ticketId);
      if (exists) return prev;
      return [newTicket, ...prev];
    });

    // AI Auto-Reply Logic
    const isAiEnabled = settings.aiAutoReplyEnabled !== false;
    if (isAiEnabled) {
      try {
        const response = await fetch("/api/support-ai", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            studentMessage: initialMessage,
            subject,
            category,
            studentName: user.displayName || user.email || "الطالب",
            conversationHistory: [studentMsg],
            platformSettings: settings,
          }),
        });
        if (response.ok) {
          const data = await response.json();
          if (data.success && data.reply) {
            const aiMsg: SupportMessage = {
              id: `msg_${Date.now()}_2`,
              sender: "ai",
              senderName: "المساعد الذكي (Gemini AI)",
              text: data.reply,
              createdAt: new Date().toISOString(),
              isEscalationTrigger: Boolean(data.needsAdmin),
            };

            const updatedMessages = [studentMsg, aiMsg];
            const newStatus: TicketStatus = data.needsAdmin ? "needs_admin" : "open";

            await updateDoc(ticketRef, {
              messages: updatedMessages,
              status: newStatus,
              aiHandled: true,
              needsAdminAttention: Boolean(data.needsAdmin),
              lastMessageText: data.reply,
              lastSender: "ai",
              updatedAt: new Date().toISOString(),
            });
          }
        }
      } catch (aiErr) {
        console.warn("AI Auto-reply warning (ticket created successfully):", aiErr);
      }
    } else {
      // Direct routing to human support
      try {
        await updateDoc(ticketRef, {
          status: "needs_admin",
          needsAdminAttention: true,
          updatedAt: new Date().toISOString(),
        });
      } catch (e) {
        console.warn("Update ticket status error:", e);
      }
    }

    return ticketId;
  };

  const sendTicketMessage = async (
    ticketId: string,
    messageText: string,
    attachmentUrl?: string
  ) => {
    if (!user || (!messageText.trim() && !attachmentUrl)) return;

    const ticketRef = doc(db, "support_tickets", ticketId);
    const snap = await getDoc(ticketRef);
    if (!snap.exists()) return;

    const ticket = snap.data() as SupportTicket;
    const studentMsg: SupportMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      sender: "student",
      senderName: user.displayName || user.email || "الطالب",
      text: messageText.trim(),
      createdAt: new Date().toISOString(),
      ...(attachmentUrl ? { attachmentUrl } : {}),
    };

    const updatedMessages = [...(ticket.messages || []), studentMsg];
    await updateDoc(ticketRef, {
      messages: updatedMessages,
      lastMessageText: messageText.trim() || (attachmentUrl ? "مرفق صورة" : ""),
      lastSender: "student",
      updatedAt: new Date().toISOString(),
      status: ticket.status === "resolved" || ticket.status === "closed" ? "open" : ticket.status,
    });

    // AI Auto-reply
    const isAiEnabled = settings.aiAutoReplyEnabled !== false;
    if (isAiEnabled) {
      try {
        const response = await fetch("/api/support-ai", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            studentMessage: messageText,
            subject: ticket.subject,
            category: ticket.category,
            studentName: user.displayName || user.email || "الطالب",
            conversationHistory: updatedMessages,
            platformSettings: settings,
          }),
        });
        if (response.ok) {
          const data = await response.json();
          if (data.success && data.reply) {
            const aiMsg: SupportMessage = {
              id: `msg_${Date.now()}_ai`,
              sender: "ai",
              senderName: "المساعد الذكي (Gemini AI)",
              text: data.reply,
              createdAt: new Date().toISOString(),
              isEscalationTrigger: Boolean(data.needsAdmin),
            };

            const finalMessages = [...updatedMessages, aiMsg];
            const newStatus: TicketStatus = data.needsAdmin ? "needs_admin" : ticket.status;

            await updateDoc(ticketRef, {
              messages: finalMessages,
              status: newStatus,
              needsAdminAttention: Boolean(data.needsAdmin) || ticket.needsAdminAttention,
              lastMessageText: data.reply,
              lastSender: "ai",
              updatedAt: new Date().toISOString(),
            });
          }
        }
      } catch (err) {
        console.warn("AI response error:", err);
      }
    }
  };

  const adminReplyToTicket = async (
    ticketId: string,
    replyText: string,
    newStatus: TicketStatus = "in_progress"
  ) => {
    if (!isAdmin || !replyText.trim()) return;

    const ticketRef = doc(db, "support_tickets", ticketId);
    const snap = await getDoc(ticketRef);
    if (!snap.exists()) return;

    const ticket = snap.data() as SupportTicket;
    const adminMsg: SupportMessage = {
      id: `msg_${Date.now()}_admin`,
      sender: "admin",
      senderName: user?.displayName || "فريق الدعم الفني",
      text: replyText.trim(),
      createdAt: new Date().toISOString(),
    };

    const updatedMessages = [...(ticket.messages || []), adminMsg];
    await updateDoc(ticketRef, {
      messages: updatedMessages,
      status: newStatus,
      needsAdminAttention: false,
      lastMessageText: replyText.trim(),
      lastSender: "admin",
      updatedAt: new Date().toISOString(),
    });
  };

  const updateTicketStatus = async (
    ticketId: string,
    status: TicketStatus,
    adminNotes?: string
  ) => {
    if (!isAdmin) return;
    const ticketRef = doc(db, "support_tickets", ticketId);
    const payload: any = {
      status,
      updatedAt: new Date().toISOString(),
    };
    if (status === "resolved" || status === "closed") {
      payload.needsAdminAttention = false;
    }
    if (typeof adminNotes === "string" && adminNotes.trim() !== "") {
      payload.adminNotes = adminNotes.trim();
    }
    await updateDoc(ticketRef, payload);
  };

  const closeTicket = async (ticketId: string) => {
    if (!user) return;
    const ticketRef = doc(db, "support_tickets", ticketId);
    await updateDoc(ticketRef, {
      status: "closed",
      needsAdminAttention: false,
      updatedAt: new Date().toISOString(),
    });
  };

  const toggleAiAutoReply = async (enabled: boolean) => {
    await updateSettings({ aiAutoReplyEnabled: enabled });
  };

  // Category Management Methods
  const addCategory = async (
    cat: Omit<CourseCategory, "id" | "createdAt">
  ): Promise<string> => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const id = `cat-${Date.now()}`;
    
    // Determine depth
    let depth = 0;
    if (cat.parentId) {
      const parentCat = categories.find((c) => c.id === cat.parentId);
      if (parentCat) {
        depth = (parentCat.depth ?? 0) + 1;
      }
    }

    const newCategory: CourseCategory = {
      ...cat,
      id,
      depth,
      order: typeof cat.order === "number" ? cat.order : categories.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, "categories", id), newCategory);
    return id;
  };

  const updateCategory = async (
    id: string,
    data: Partial<CourseCategory>,
    oldName?: string
  ): Promise<void> => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const catRef = doc(db, "categories", id);

    // If parentId changed, recalculate depth
    let updatedData = { ...data };
    if (data.parentId !== undefined) {
      if (data.parentId) {
        const parentCat = categories.find((c) => c.id === data.parentId);
        updatedData.depth = parentCat ? (parentCat.depth ?? 0) + 1 : 0;
      } else {
        updatedData.depth = 0;
      }
    }

    await updateDoc(catRef, {
      ...updatedData,
      updatedAt: new Date().toISOString(),
    });

    // Cascade rename to courses if name changed
    if (data.name && oldName && data.name !== oldName) {
      const qCourses = query(
        collection(db, "courses"),
        where("category", "==", oldName)
      );
      const snap = await getDocs(qCourses);
      const batchPromises = snap.docs.map((d) =>
        updateDoc(doc(db, "courses", d.id), {
          category: data.name,
          updatedAt: new Date().toISOString(),
        })
      );
      await Promise.all(batchPromises);
    }
  };

  const deleteCategory = async (
    id: string,
    replacementCategoryName?: string
  ): Promise<void> => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const catDoc = categories.find((c) => c.id === id);
    const catName = catDoc?.name;

    // 1. Reassign child categories to parent of deleted category or root
    const directChildren = categories.filter((c) => c.parentId === id);
    if (directChildren.length > 0) {
      const parentOfDeleted = catDoc?.parentId || null;
      const childPromises = directChildren.map((child) =>
        updateDoc(doc(db, "categories", child.id), {
          parentId: parentOfDeleted,
          depth: parentOfDeleted ? 1 : 0,
          updatedAt: new Date().toISOString(),
        })
      );
      await Promise.all(childPromises);
    }

    // 2. Reassign courses if replacement is provided
    if (catName && replacementCategoryName) {
      const qCourses = query(
        collection(db, "courses"),
        where("category", "==", catName)
      );
      const snap = await getDocs(qCourses);
      const batchPromises = snap.docs.map((d) =>
        updateDoc(doc(db, "courses", d.id), {
          category: replacementCategoryName,
          updatedAt: new Date().toISOString(),
        })
      );
      await Promise.all(batchPromises);
    }

    await deleteDoc(doc(db, "categories", id));
  };

  const toggleCategoryActive = async (id: string, active: boolean) => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    await updateDoc(doc(db, "categories", id), {
      active,
      updatedAt: new Date().toISOString(),
    });
  };

  const reorderCategories = async (orderedIds: string[]) => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const promises = orderedIds.map((id, index) =>
      updateDoc(doc(db, "categories", id), {
        order: index + 1,
        updatedAt: new Date().toISOString(),
      })
    );
    await Promise.all(promises);
  };

  const seedDefaultCategories = async () => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    for (const cat of INITIAL_CATEGORIES) {
      await setDoc(doc(db, "categories", cat.id), cat, { merge: true });
    }
  };

  // Level Management Methods
  const addLevel = async (
    lvl: Omit<CourseLevelItem, "id" | "createdAt">
  ): Promise<string> => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const id = `lvl-${Date.now()}`;
    const newLevel: CourseLevelItem = {
      ...lvl,
      id,
      order: typeof lvl.order === "number" ? lvl.order : levels.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, "course_levels", id), newLevel);
    return id;
  };

  const updateLevel = async (
    id: string,
    data: Partial<CourseLevelItem>,
    oldName?: string
  ): Promise<void> => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    await updateDoc(doc(db, "course_levels", id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });

    // Cascade rename to courses if level name changed
    if (data.name && oldName && data.name !== oldName) {
      const qCourses = query(
        collection(db, "courses"),
        where("level", "==", oldName)
      );
      const snap = await getDocs(qCourses);
      const batchPromises = snap.docs.map((d) =>
        updateDoc(doc(db, "courses", d.id), {
          level: data.name,
          updatedAt: new Date().toISOString(),
        })
      );
      await Promise.all(batchPromises);
    }
  };

  const deleteLevel = async (
    id: string,
    replacementLevelName?: string
  ): Promise<void> => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const lvlDoc = levels.find((l) => l.id === id);
    const lvlName = lvlDoc?.name;

    if (lvlName && replacementLevelName) {
      const qCourses = query(
        collection(db, "courses"),
        where("level", "==", lvlName)
      );
      const snap = await getDocs(qCourses);
      const batchPromises = snap.docs.map((d) =>
        updateDoc(doc(db, "courses", d.id), {
          level: replacementLevelName,
          updatedAt: new Date().toISOString(),
        })
      );
      await Promise.all(batchPromises);
    }

    await deleteDoc(doc(db, "course_levels", id));
  };

  const toggleLevelActive = async (id: string, active: boolean) => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    await updateDoc(doc(db, "course_levels", id), {
      active,
      updatedAt: new Date().toISOString(),
    });
  };

  const reorderLevels = async (orderedIds: string[]) => {
    if (!isAdmin) throw new Error("Unauthorized: Admin privileges required");
    const promises = orderedIds.map((id, index) =>
      updateDoc(doc(db, "course_levels", id), {
        order: index + 1,
        updatedAt: new Date().toISOString(),
      })
    );
    await Promise.all(promises);
  };

  const refreshData = async () => {
    await initializePlatformData();
  };

  return (
    <AppContext.Provider
      value={{
        user,
        firebaseUser,
        authLoading,
        isAdmin,
        settings,
        updateSettings,
        courses,
        categories,
        levels,
        addCategory,
        updateCategory,
        deleteCategory,
        toggleCategoryActive,
        reorderCategories,
        seedDefaultCategories,
        addLevel,
        updateLevel,
        deleteLevel,
        toggleLevelActive,
        reorderLevels,
        testimonials,
        enrollments,
        myPayments,
        allPayments,
        allStudents,
        myTickets,
        allTickets,
        isSupportModalOpen,
        setIsSupportModalOpen,
        selectedTicket,
        setSelectedTicket,
        createSupportTicket,
        sendTicketMessage,
        adminReplyToTicket,
        updateTicketStatus,
        closeTicket,
        toggleAiAutoReply,
        language,
        setLanguage,
        activeView,
        setActiveView,
        unreadMessengerCount,
        setUnreadMessengerCount,
        activeMessengerTargetUser,
        setActiveMessengerTargetUser,
        startDirectChat,
        selectedCourse,
        setSelectedCourse,
        selectedLesson,
        setSelectedLesson,
        isEtisalatModalOpen,
        setIsEtisalatModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalMode,
        setAuthModalMode,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        logout,
        submitEtisalatPayment,
        approvePayment,
        rejectPayment,
        markLessonCompleted,
        deleteCourse,
        isEnrolledInCourse,
        refreshData,
        demoLoginAsAdmin,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
