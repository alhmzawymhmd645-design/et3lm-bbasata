import React, { useState } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { FeaturedCourses } from "./components/FeaturedCourses";
import { WhyChooseUs } from "./components/WhyChooseUs";
import { Testimonials } from "./components/Testimonials";
import { Footer } from "./components/Footer";
import { AuthModal } from "./components/AuthModal";
import { EtisalatCashModal } from "./components/EtisalatCashModal";
import { CourseDetailsModal } from "./components/CourseDetailsModal";
import { LessonPlayer } from "./components/LessonPlayer";
import { StudentDashboard } from "./components/StudentDashboard";
import { AdminDashboard } from "./components/AdminDashboard";
import { AiAssistantModal } from "./components/AiAssistantModal";
import { SupportChat } from "./components/SupportChat";
import { MessengerView } from "./components/MessengerView";
import { InternalMessengerWidget } from "./components/InternalMessengerWidget";
import { ContentProtection } from "./components/ContentProtection";
import { Course } from "./types";
import siteBackground from "./assets/images/site_background_1787091303127.jpg";

const MainContent: React.FC = () => {
  const {
    activeView,
    setActiveView,
    isEtisalatModalOpen,
    setIsEtisalatModalOpen,
    language,
    settings,
  } = useApp();

  const isAr = language === "ar";
  const [selectedCourseForDetails, setSelectedCourseForDetails] = useState<Course | null>(null);
  const [selectedCourseForEnroll, setSelectedCourseForEnroll] = useState<Course | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const handleOpenDetails = (course: Course) => {
    setSelectedCourseForDetails(course);
    setIsDetailsOpen(true);
  };

  const handleOpenEnroll = (course: Course) => {
    setSelectedCourseForEnroll(course);
    setIsEtisalatModalOpen(true);
  };

  const currentBg =
    (settings?.platformBackground && settings.platformBackground.trim() !== "")
      ? settings.platformBackground
      : (settings?.mainBackgroundUrl && settings.mainBackgroundUrl.trim() !== "")
      ? settings.mainBackgroundUrl
      : siteBackground;

  return (
    <div
      dir={isAr ? "rtl" : "ltr"}
      className="min-h-screen bg-[#0A0A0A] text-white selection:bg-[#D4AF37] selection:text-white font-sans relative overflow-x-hidden flex flex-col"
    >
      {/* Ambient Website Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <img
          src={currentBg}
          alt=""
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-25 mix-blend-lighten filter saturate-150 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A0A]/70 via-[#0A0A0A]/90 to-[#0A0A0A]" />
      </div>

      <div className="relative z-10 flex flex-col flex-grow">
        <Navbar />

        <main className="flex-grow">
          {activeView === "home" && (
            <>
              <Hero />
              <FeaturedCourses
                title={isAr ? "الكورسات والمسارات المميزة" : "Featured Tracks"}
                subtitle={
                  isAr
                    ? "اختر من بين أقوى الدورات العملية المصممة لتأهيلك لسوق العمل مع الدفع المباشر عبر Etisalat Cash."
                    : "Handcrafted masterclasses designed for real-world employment."
                }
                onOpenDetails={handleOpenDetails}
                onOpenEnroll={handleOpenEnroll}
              />
              <WhyChooseUs />
              <Testimonials />
            </>
          )}

          {activeView === "courses" && (
            <div className="py-8">
              <FeaturedCourses
                onOpenDetails={handleOpenDetails}
                onOpenEnroll={handleOpenEnroll}
              />
            </div>
          )}

          {activeView === "player" && <LessonPlayer />}

          {activeView === "student-dashboard" && <StudentDashboard />}

          {activeView === "admin-dashboard" && <AdminDashboard />}

          {activeView === "ai-assistant" && <AiAssistantModal />}

          {activeView === "support" && <SupportChat />}

          {activeView === "messenger" && <MessengerView />}
        </main>

        <Footer />
      </div>

      {/* DRM & Anti-Screen Capture Protection Layer */}
      <ContentProtection />

      {/* Internal Realtime Messenger & AI Tutor Floating Widget */}
      <InternalMessengerWidget />

      {/* Global Modals */}
      <AuthModal />

      <EtisalatCashModal
        course={selectedCourseForEnroll}
        isOpen={isEtisalatModalOpen}
        onClose={() => {
          setIsEtisalatModalOpen(false);
          setSelectedCourseForEnroll(null);
        }}
      />

      <CourseDetailsModal
        course={selectedCourseForDetails}
        isOpen={isDetailsOpen}
        onClose={() => {
          setIsDetailsOpen(false);
          setSelectedCourseForDetails(null);
        }}
        onEnroll={(course) => {
          setIsDetailsOpen(false);
          handleOpenEnroll(course);
        }}
      />
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

export default App;
